import type { Message } from "../../types/Community";

export function AuthorBanner({ message }: { message: Message }) {
  return message.tier === "Svip" && message.has_background ? <img alt="" loading="lazy"
    className={"author-banner" + (message.background_mime === "image/gif" ? " profile-gif" : "")}
    src={"/api/extra/profile/" + message.author_id + "/background"} onError={event=>{event.currentTarget.hidden=true;}}/> : null;
}
