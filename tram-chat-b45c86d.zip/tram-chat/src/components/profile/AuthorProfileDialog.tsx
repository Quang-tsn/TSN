import type { Message } from "../../types/Community";
import { Dialog } from "../primitives/Dialog";
import { TierBadge } from "../extra/TierBadge";
import { AuthorAvatar } from "./AuthorAvatar";
import { AuthorBanner } from "./AuthorBanner";

export function AuthorProfileDialog({ author,onClose }: { author: Message; onClose: () => void }) {
  return <Dialog title="Hồ sơ người gửi" onClose={onClose}>
    <div className="author-profile-card">
      <div className="author-profile-cover"><AuthorBanner message={author}/></div>
      <div className="author-profile-identity">
        <AuthorAvatar message={author}/>
        <div><div className="author-profile-name"><strong>{author.display_name}</strong><TierBadge tier={author.tier}/></div>
          <p>@{author.username}</p></div>
      </div>
    </div>
  </Dialog>;
}
