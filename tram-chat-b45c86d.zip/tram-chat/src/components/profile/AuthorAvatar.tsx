import type { Message } from "../../types/Community";

export function AuthorAvatar({ message }: { message: Message }) {
  const canShow = message.has_avatar && message.tier && (message.avatar_mime !== "image/gif" || message.tier === "Svip");
  return <span className="author-avatar" aria-hidden="true">
    {message.username[0].toUpperCase()}
    {canShow ? <img className={message.avatar_mime === "image/gif" ? "profile-gif" : ""} alt="" loading="lazy"
      src={"/api/extra/profile/"+message.author_id+"/avatar"} onError={event=>{event.currentTarget.hidden=true;}}/> : null}
  </span>;
}
