import { createContext } from "react";
import type { ExtraState } from "../../types/Extra";
export const ExtraContext = createContext<ExtraState | null>(null);
