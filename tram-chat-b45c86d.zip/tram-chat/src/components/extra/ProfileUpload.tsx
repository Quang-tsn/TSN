import { useState } from "react";
import { api } from "../../services/community/api";
import type { ExtraState } from "../../types/Extra";
export function ProfileUpload({ extra, reload }: { extra: ExtraState; reload: () => Promise<void> }) {
  const [error,setError]=useState(""), [busy,setBusy]=useState(false), [version,setVersion]=useState(0);
  if (!extra.status?.tier || !extra.user) return null;
  const svip = extra.status.tier === "Svip";
  const kinds = svip ? ["avatar","background"] : ["avatar"];
  const name = (kind: string) => kind === "avatar" ? "Ảnh đại diện" : "Hình nền";
  async function upload(kind: string,file: File) {
    setBusy(true);setError("");
    const body=new FormData();
    body.set("image",file);
    try { await api("extra/profile/" + extra.user!.id + "/" + kind,body);setVersion(v=>v+1);await reload(); }
    catch (cause) { setError((cause as Error).message); }
    finally { setBusy(false); }
  }
  return <div><p>{svip ? "PNG, JPEG hoặc GIF, tối đa 4 MB." : "PNG hoặc JPEG, tối đa 4 MB. Svip có thêm GIF và ảnh nền hồ sơ."}</p>
    {kinds.map(kind => <div className="extra-upload" key={kind}>
      {extra.images?.some(a => a.kind === kind) && <img alt={name(kind)}
        src={`/api/extra/profile/${extra.user!.id}/${kind}?v=${version}`} loading="lazy"/>}
      <label>{name(kind)}<input type="file" accept={svip ? "image/png,image/jpeg,image/gif" : "image/png,image/jpeg"} disabled={busy}
        onChange={e=>{const file=e.target.files?.[0];e.target.value="";if(file)void upload(kind,file);}}/></label>
    </div>)}
    <p role="alert" className="error">{error}</p>
  </div>;
}
