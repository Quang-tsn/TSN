import { UpgradeArt } from "./UpgradeArt";
export function UpgradePromo() {
  return <section className="upgrade-promo" aria-label="Giới thiệu ExtraAccount">
    <UpgradeArt/>
    <div><h2>Thêm tài khoản với ExtraAccount</h2>
      <p>Avip và Svip cho bạn thêm tài khoản để đổi nhanh ngay trong chat.</p>
      <div className="upgrade-perks"><span>GIF và sticker</span><span>Tin nhắn đã lưu</span>
        <span>Ảnh đại diện riêng</span><span>Huy hiệu VIP</span></div>
      <a href="/extraaccount#extra-plans" className="landing-button">Xem các gói</a>
    </div>
  </section>;
}
