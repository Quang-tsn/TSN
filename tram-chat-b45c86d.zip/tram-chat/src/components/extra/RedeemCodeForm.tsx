import { useState, type FormEvent } from "react";
import { api } from "../../services/community/api";
import { isExtraCode } from "../../shared/isExtraCode";
import { normalizeExtraCode } from "../../shared/normalizeExtraCode";
import type { PaidTier } from "../../shared/extraPlans";
import type { ExtraState } from "../../types/Extra";

export function RedeemCodeForm({ tier,onActivated }: { tier: PaidTier; onActivated: (status: ExtraState["status"]) => void }) {
  const [busy,setBusy] = useState(false);
  const [success,setSuccess] = useState("");
  const [error,setError] = useState<{ text: string; status?: number } | null>(null);
  async function redeem(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (busy) return;
    const form = event.currentTarget;
    const input = form.elements.namedItem("code") as HTMLInputElement;
    const code = normalizeExtraCode(input.value);
    input.value = code;
    setSuccess("");setError(null);
    if (!isExtraCode(code)) {
      setError({ status:400,text:"Kiểm tra lại mã. Mã gồm 12 ký tự, có cả chữ và số." });
      input.focus();
      return;
    }
    setBusy(true);
    try {
      const grant = await api<{ tier: PaidTier; expiresAt: number; status: ExtraState["status"] }>("extra/redeem",{code,tier});
      onActivated(grant.status);
      form.reset();
      setSuccess(`Đã kích hoạt ${grant.tier}. Gói có hiệu lực đến ${new Date(grant.expiresAt).toLocaleString("vi-VN")}.`);
    } catch (cause) {
      const problem = cause as Error & { status?: number };
      setError({ status:problem.status,text:problem.status ? problem.message : "Chưa kiểm tra được mã. Thử lại nhé." });
    }
    finally { setBusy(false); }
  }
  return <form className="settings-redeem" onSubmit={redeem}>
    <label htmlFor="extra-code">Mã kích hoạt</label>
    <p id="activation-hint">Dán hoặc gõ mã 12 ký tự bạn nhận được.</p>
    <div className="settings-code-fields">
      <input id="extra-code" name="code" type="text" autoCapitalize="characters" data-dialog-focus
        autoComplete="off" autoCorrect="off" spellCheck={false} required disabled={busy}
        aria-describedby={error ? "activation-hint activation-error" : "activation-hint"}
        aria-invalid={!!error?.status && [400,404,409].includes(error.status)} onChange={()=>setError(null)}
        onPaste={event=>{
          const code = normalizeExtraCode(event.clipboardData.getData("text/plain"));
          if (!isExtraCode(code)) return;
          event.preventDefault();
          event.currentTarget.value = code;
          setError(null);
        }}/>
      <button className="landing-button landing-button-primary" type="submit" disabled={busy}>
        {busy ? "Đang kích hoạt…" : "Kích hoạt"}
      </button>
    </div>
    {error && <p id="activation-error" className="error" role="alert">{error.text}
      {error.status === 401 && <> <a href={"/login?next=extraaccount#ma-" + tier.toLowerCase()}>Đăng nhập</a></>}
    </p>}
    {success && <p className="settings-success" role="status">{success} <a href="/settings">Mở Cài đặt</a></p>}
  </form>;
}
