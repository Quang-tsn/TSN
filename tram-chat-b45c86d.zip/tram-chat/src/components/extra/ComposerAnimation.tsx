import { useContext,useState } from "react";
import type { Animation } from "../../types/Extra";
import { ExtraContext } from "./ExtraContext";
import { GiphyPicker } from "./GiphyPicker";
export function ComposerAnimation({ selection, onSelect, disabled }: {
  selection: Animation | null; onSelect: (value: Animation | null) => void; disabled: boolean;
}) {
  const [open,setOpen] = useState(false);
  const extra = useContext(ExtraContext);
  if (!extra?.status?.tier) return null;
  return <>
    <button className="icon-button giphy-trigger" disabled={disabled} type="button"
      onClick={()=>setOpen(true)} aria-label="Chọn GIF hoặc sticker">
      {selection ? "Đổi ảnh động" : "GIF"}
    </button>
    {selection && <button type="button" disabled={disabled} className="icon-button"
      onClick={()=>onSelect(null)} aria-label="Bỏ ảnh động">×</button>}
    {open && <GiphyPicker apiKey={extra.giphyKey} onClose={()=>setOpen(false)}
      onChoose={value=>{onSelect(value);setOpen(false);}}/>}
  </>;
}
