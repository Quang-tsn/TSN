import { useState, type FormEvent } from "react";
import type { Animation } from "../../types/Extra";
import { Dialog } from "../primitives/Dialog";
import { searchGiphy, type GiphyResult } from "../../services/giphy/searchGiphy";
import { parseGiphyLink } from "../../services/giphy/parseGiphyLink";
export function GiphyPicker({ apiKey,onClose,onChoose }: { apiKey: string | null;
  onClose: () => void; onChoose: (value: Animation) => void }) {
  const [kind,setKind]=useState<Animation["kind"]>("gif");
  const [results,setResults]=useState<GiphyResult[]>([]);
  const [busy,setBusy]=useState(false),[error,setError]=useState("");
  async function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();setError("");
    const value = String(new FormData(e.currentTarget).get("query")).trim();
    const id = parseGiphyLink(value);
    if(id){onChoose({id,kind});return;}
    if(!apiKey || value.startsWith("http")) {setError("Dán đường dẫn GIF hoặc sticker từ GIPHY.");return;}
    setBusy(true);
    try { const items=await searchGiphy(apiKey,kind,value);setResults(items);
      if(!items.length)setError("Không tìm thấy ảnh động phù hợp."); }
    catch(cause){setError((cause as Error).message);}
    finally {setBusy(false);}
  }
  return <Dialog title="GIF và sticker" onClose={onClose}>
    <div className="plan-period">
      <button type="button" aria-pressed={kind==="gif"} disabled={busy}
        onClick={()=>{setKind("gif");setResults([]);}}>GIF</button>
      <button type="button" aria-pressed={kind==="sticker"} disabled={busy}
        onClick={()=>{setKind("sticker");setResults([]);}}>Sticker</button>
    </div>
    <form onSubmit={submit}>
      <label>{apiKey ? "Tìm hoặc dán liên kết GIPHY" : "Dán liên kết GIPHY"}
        <input name="query" maxLength={200} required defaultValue=""/></label>
      <button className="secondary" disabled={busy}>{apiKey ? "Tìm hoặc chọn" : "Chọn ảnh động"}</button>
    </form>
    <div className="giphy-grid">{results.map(item => <button key={item.id} type="button"
      onClick={()=>onChoose({id:item.id,kind})}>
      <img src={item.images.fixed_width_small.url} alt={item.title} loading="lazy"/>
    </button>)}</div>
    <a href="https://giphy.com/" target="_blank" rel="noopener noreferrer">Powered by GIPHY ↗</a>
    <p role="alert" className="error">{error}</p>
  </Dialog>;
}
