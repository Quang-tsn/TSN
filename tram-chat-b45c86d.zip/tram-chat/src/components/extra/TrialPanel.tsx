import { useTrialClock } from "../../hooks/useTrialClock";
export function TrialPanel({ ready, busy, claim }: { ready: number | null; busy: boolean; claim: () => void }) {
  const remaining = useTrialClock(ready);
  if (remaining === null) return null;
  return <section className="extra-card" aria-label="Trial Bvip">
    <h2>Dùng thử Bvip</h2>
    <p>Sau khi đủ 90 giây kể từ lúc mở Lunor, quay lại nhận 12 giờ Bvip.</p>
    <a href="https://lunor.wtf/" target="_blank" rel="noopener noreferrer">Mở quảng cáo Lunor</a>
    <p>{remaining ? "Thời gian còn lại: " + remaining + " giây" : "Đã đủ 90 giây."}</p>
    <button className="secondary" disabled={busy || remaining > 0} onClick={claim}>Nhận Bvip</button>
  </section>;
}
