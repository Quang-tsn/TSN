import { useExtra } from "../../hooks/useExtra";
import { BrandLogo } from "../icons/BrandLogo";
import { ExtraPage } from "./ExtraPage";

export function PlansPage() {
  const { extra,error,reload,updateStatus } = useExtra();
  return <main className="landing extra-page plans-page">
    <header className="landing-width extra-nav">
      <a href="/" className="landing-brand"><BrandLogo/>Trạm</a>
      <nav aria-label="Điều hướng gói">
        <a className="landing-button" href="/coins">Tamper Coins</a>
        <a className="landing-button" href={extra?.user ? "/settings" : "/login"}>
          {extra?.user ? "Cài đặt" : "Đăng nhập"}
        </a>
        <a className="landing-button" href="/login">Mở chat</a>
      </nav>
    </header>
    <div className="landing-width">
      <ExtraPage extra={extra} error={error} reload={reload} onActivated={status=>{
        updateStatus(status);
        void reload();
      }}/>
    </div>
  </main>;
}
