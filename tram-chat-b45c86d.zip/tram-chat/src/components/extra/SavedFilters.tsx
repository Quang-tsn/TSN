import type { SavedCatalog,SavedFilters as Filters,SavedOption,SavedSort } from "../../types/SavedLibrary";

export function SavedFilters({ values,catalog,update }: {
  values: Filters; catalog: SavedCatalog; update: <K extends keyof Filters>(key: K,value: Filters[K])=>void;
}) {
  const selections: { key:"folder"|"author"|"server"; label:string; all:string; options:SavedOption[] }[] = [
    {key:"folder",label:"Thư mục",all:"Tất cả thư mục",options:[{id:"unfiled",name:"Chưa phân loại"},...catalog.folders]},
    {key:"author",label:"Người gửi",all:"Tất cả người gửi",options:catalog.authors},
    {key:"server",label:"Nhóm / server",all:"Tất cả nhóm",options:catalog.servers},
  ];
  return <div className="saved-filters" aria-label="Lọc tin đã lưu">
    <label className="saved-search">Tìm tin nhắn<input type="search" value={values.q} maxLength={120}
      placeholder="Tìm chữ, người gửi hoặc kênh" onChange={event=>update("q",event.target.value)}/></label>
    <label>Sắp xếp<select value={values.sort} onChange={event=>update("sort",event.target.value as SavedSort)}>
      <option value="newest">Thời điểm lưu · Gần nhất</option><option value="oldest">Thời điểm lưu · Lâu nhất</option>
      <option value="az">Nội dung · A–Z</option><option value="za">Nội dung · Z–A</option>
    </select></label>
    {selections.map(({key,label,all,options})=><label key={key}>{label}
      <select value={values[key]} onChange={event=>update(key,event.target.value)}>
        <option value="">{all}</option>{options.map(option=><option key={option.id} value={option.id}>{option.name}</option>)}
      </select></label>)}
  </div>;
}
