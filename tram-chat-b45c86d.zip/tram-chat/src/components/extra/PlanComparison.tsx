import { useState } from "react";
import { extraPlans, type PaidTier } from "../../shared/extraPlans";
import { TierBadge } from "./TierBadge";
import { formatStorage } from "../../utils/formatStorage";
type Period = "week" | "month";
export function PlanComparison({ busy, eligible, signedIn, onTrialOpen, onEnterCode }: {
  busy: boolean; eligible: boolean; signedIn: boolean; onTrialOpen: () => void; onEnterCode: (tier: PaidTier) => void;
}) {
  const [period,setPeriod] = useState<Period>("week");
  const rows = [
    ["Thời gian dùng", "12 giờ", period === "week" ? "7 ngày" : "30 ngày", period === "week" ? "7 ngày" : "30 ngày"],
    ["Quảng cáo trong Trạm", "Có", "Ẩn quảng cáo", "Ẩn quảng cáo"],
    ["GIF và sticker động", "Có", "Có", "Có"],
    ["Ảnh đại diện riêng", "PNG, JPEG", "PNG, JPEG", "PNG, JPEG, GIF"],
    ["Hình nền hồ sơ", "—", "—", "PNG, JPEG, GIF"],
    ["Dung lượng Tin đã lưu", ...Object.values(extraPlans).map(plan=>formatStorage(plan.storage))],
    ["Số tài khoản tối đa", "1", "3", "10"],
    ["Huy hiệu trong chat", "Màu cố định", "Cầu vồng tĩnh", "Cầu vồng đổi màu"],
  ];
  return <section className="plan-comparison" aria-labelledby="extra-plans">
    <div className="plan-top"><h2 id="extra-plans">So sánh gói</h2>
      <div className="plan-period" aria-label="Kỳ hạn gói trả phí">
        <button aria-pressed={period === "week"} onClick={() => setPeriod("week")}>7 ngày</button>
        <button aria-pressed={period === "month"} onClick={() => setPeriod("month")}>1 tháng</button>
      </div>
    </div>
    <div className="plan-table-scroll" tabIndex={0} aria-label="Bảng quyền lợi, có thể cuộn ngang">
      <table className="plan-table">
        <thead><tr><th scope="col">Quyền lợi</th>
          <th scope="col"><TierBadge tier="Bvip"/><strong>Miễn phí</strong><small>Xem quảng cáo 90 giây</small>
            {!busy && !signedIn ? <a href="/login?next=extraaccount#extra-plans">Đăng nhập để thử</a>
              : busy || !eligible ? <button disabled>Bắt đầu dùng thử</button>
              : <form action="/api/extra/trial-open" method="post" target="_blank"
                  rel="noopener" onSubmit={onTrialOpen}>
                <button type="submit">Mở quảng cáo</button></form>}</th>
          {(["Avip","Svip"] as const).map(tier => <th scope="col" key={tier}>
            <TierBadge tier={tier}/><strong>{"$" + extraPlans[tier][period]}</strong>
            <small>{period === "week" ? "/ 7 ngày" : "/ 1 tháng (30 ngày)"}</small>
            <button type="button" disabled={busy} aria-label={"Nhập mã " + tier} onClick={()=>onEnterCode(tier)}>Nhập mã</button>
          </th>)}
        </tr></thead>
        <tbody>{rows.map(([label,...values]) => <tr key={label}><th scope="row">{label}</th>
          {values.map((value,index) => <td key={index}>{value}</td>)}</tr>)}</tbody>
      </table>
    </div>
  </section>;
}
