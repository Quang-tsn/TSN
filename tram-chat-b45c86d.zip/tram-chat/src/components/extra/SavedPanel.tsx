import { useState } from "react";
import { api } from "../../services/community/api";
import { useSavedLibrary } from "../../hooks/useSavedLibrary";
import type { SavedMessage } from "../../types/SavedMessage";
import { formatStorage } from "../../utils/formatStorage";
import { PlusIcon } from "../icons/PlusIcon";
import { SavedFilters } from "./SavedFilters";
import { SavedFolderDialog } from "./SavedFolderDialog";
import { SavedLocationDialog } from "./SavedLocationDialog";
import { SavedMessageItem } from "./SavedMessageItem";

export function SavedPanel({ limit }: { limit: number }) {
  const library = useSavedLibrary();
  const {data,busy,filters,catalog} = library;
  const [creating,setCreating] = useState(false);
  const [moving,setMoving] = useState<SavedMessage | null>(null);
  const [error,setError] = useState("");
  async function remove(id: string) {
    setError("");
    try { await api("extra/unsave",{id}); library.refresh(); }
    catch(cause){setError((cause as Error).message);}
  }
  const filtered = !!(filters.q || filters.folder || filters.author || filters.server);
  return <section className="extra-card saved-library">
    <div className="saved-library-heading"><h2>Kho tin đã lưu</h2>
      <button className="settings-action" onClick={()=>setCreating(true)}><PlusIcon/> Tạo thư mục</button></div>
    <p>{formatStorage(data?.used ?? 0)} / {formatStorage(data?.limit ?? limit)} của tài khoản này.</p>
    {data && <progress max={data.limit} value={data.used} aria-label="Dung lượng đã dùng"/>}
    <SavedFilters values={filters} catalog={catalog} update={library.update}/>
    {busy && <p className="saved-loading" role="status">Đang tải tin đã lưu…</p>}
    {!busy && data?.saved.length === 0 && <p>{filtered ? "Không tìm thấy tin phù hợp." : "Chưa có tin đã lưu."}</p>}
    <ul className="saved-list" aria-busy={busy}>{data?.saved.map(row=><SavedMessageItem key={row.id} message={row}
      folder={catalog.folders.find(folder=>folder.id===row.folder_id)?.name} onMove={setMoving} onRemove={remove}/>)}</ul>
    {(library.before || data?.next) && <div className="saved-item-actions">
      {library.before && <button className="secondary" disabled={busy} onClick={()=>library.setBefore(null)}>Trang đầu</button>}
      {data?.next && <button className="secondary" disabled={busy} onClick={()=>library.setBefore(data.next)}>Trang sau</button>}
    </div>}
    {(error || library.error) && <p role="alert" className="error">{error || library.error}</p>}
    {creating && <SavedFolderDialog onClose={()=>setCreating(false)} onCreated={folder=>{
      library.addFolder(folder);setCreating(false);
    }}/>}
    {moving && <SavedLocationDialog id={moving.id} folderId={moving.folder_id} existing
      onClose={()=>setMoving(null)} onDone={()=>{setMoving(null);library.refresh();}}/>}
  </section>;
}
