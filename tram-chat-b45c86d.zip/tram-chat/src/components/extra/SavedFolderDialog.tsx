import { useState,type FormEvent } from "react";
import type { SavedOption } from "../../types/SavedLibrary";
import { api } from "../../services/community/api";
import { Dialog } from "../primitives/Dialog";

export function SavedFolderDialog({ onClose,onCreated }: { onClose: ()=>void; onCreated: (folder: SavedOption)=>void }) {
  const [busy,setBusy] = useState(false);
  const [error,setError] = useState("");
  async function create(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (busy) return;
    const name = new FormData(event.currentTarget).get("name");
    setBusy(true);setError("");
    try { onCreated(await api<SavedOption>("extra/saved-folders",{name})); }
    catch (cause) { setError((cause as Error).message); }
    finally { setBusy(false); }
  }
  return <Dialog title="Tạo thư mục" onClose={onClose}>
    <form onSubmit={create}>
      <label>Tên thư mục<input name="name" required maxLength={64} placeholder="Ví dụ: Kỷ niệm" data-dialog-focus/></label>
      {error && <p className="error" role="alert">{error}</p>}
      <button type="submit" className="primary" disabled={busy}>{busy ? "Đang tạo…" : "Tạo thư mục"}</button>
    </form>
  </Dialog>;
}
