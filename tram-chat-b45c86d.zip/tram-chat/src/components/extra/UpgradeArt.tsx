import { TierBadge } from "./TierBadge";
export function UpgradeArt() {
  return <div className="upgrade-art" aria-hidden="true">
    <div className="upgrade-tile upgrade-left"><b>B</b><TierBadge tier="Bvip"/></div>
    <div className="upgrade-tile upgrade-right"><b>S</b><TierBadge tier="Svip"/></div>
    <div className="upgrade-tile upgrade-front"><b>A</b><TierBadge tier="Avip"/></div>
  </div>;
}
