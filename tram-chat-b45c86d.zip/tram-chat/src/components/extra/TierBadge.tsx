import type { Tier } from "../../shared/extraPlans";
export function TierBadge({ tier }: { tier: Tier | null | undefined }) {
  if (!tier) return null;
  return <span className={"tier-badge tier-" + tier.toLowerCase()}>{tier}</span>;
}
