import type { SavedMessage } from "../../types/SavedMessage";
import { MessageImage } from "../discord/chat-area/MessageImage";
import { AnimatedMessage } from "./AnimatedMessage";

export function SavedMessageItem({ message,folder,onMove,onRemove }: {
  message: SavedMessage; folder?: string; onMove: (message: SavedMessage)=>void; onRemove: (id: string)=>void;
}) {
  return <li>
    <strong>{message.display_name}</strong>
    <p className="saved-source">{message.server_name} · #{message.room_name}{folder ? " · " + folder : ""}</p>
    {message.content && <p>{message.content}</p>}
    <MessageImage room={message.room_id} message={message}/>
    {message.giphy_id && <AnimatedMessage id={message.giphy_id} kind={message.animation_kind || "gif"} playOnLoad={false}/>}
    <div className="saved-item-actions"><button className="secondary" onClick={()=>onMove(message)}>Chuyển thư mục</button>
      <button className="secondary" onClick={()=>onRemove(message.id)}>Bỏ lưu</button></div>
  </li>;
}
