import googlePay from "../../assets/payment/google-pay.svg";
import applePay from "../../assets/payment/apple-pay.svg";
import momo from "../../assets/payment/momo.svg";

const providers = [
  { name:"Google Pay",mark:googlePay },{ name:"Apple Pay",mark:applePay },{ name:"MoMo",mark:momo },
];

export function UpcomingPayments() {
  return <section className="extra-card" aria-labelledby="upcoming-payments">
    <h3 id="upcoming-payments">Phương thức thanh toán</h3>
    <ul className="settings-payments">
      {providers.map(provider => <li key={provider.name}>
        <img className="payment-mark" src={provider.mark} alt="" width="64" height="40"/>
        <span>{provider.name}</span><small lang="en">Coming soon</small>
      </li>)}
    </ul>
  </section>;
}
