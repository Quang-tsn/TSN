import { useEffect,useState, type FormEvent } from "react";
import type { SavedOption } from "../../types/SavedLibrary";
import { api } from "../../services/community/api";
import { Dialog } from "../primitives/Dialog";

export function SavedLocationDialog({ id,existing,folderId,onClose,onDone }: {
  id: string; existing: boolean; folderId?: string | null; onClose: () => void; onDone: () => void;
}) {
  const [folders,setFolders] = useState<SavedOption[] | null>(null);
  const [folder,setFolder] = useState(folderId ?? "");
  const [busy,setBusy] = useState(false);
  const [error,setError] = useState("");
  useEffect(()=>{
    const controller = new AbortController();
    api<{folders:SavedOption[]}>("extra/saved-folders",undefined,"GET",controller.signal)
      .then(data=>{if(!controller.signal.aborted) setFolders(data.folders);})
      .catch(cause=>{if(!controller.signal.aborted) setError(cause.message);});
    return ()=>controller.abort();
  },[]);
  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (busy || !folders) return;
    setBusy(true);setError("");
    try { await api(existing ? "extra/saved-move" : "extra/save",{id,folderId:folder || null}); onDone(); }
    catch (cause) { setError((cause as Error).message); }
    finally { setBusy(false); }
  }
  return <Dialog title={existing ? "Chuyển thư mục" : "Lưu tin này"} onClose={onClose}>
    <form className="saved-location-dialog" onSubmit={submit}>
      <label>Thư mục<select value={folder} disabled={!folders || busy} onChange={event=>setFolder(event.target.value)}>
        <option value="">Chưa phân loại</option>
        {folders?.map(item=><option key={item.id} value={item.id}>{item.name}</option>)}
      </select></label>
      {!existing && folders?.length === 0 && <p>Bạn có thể tạo thư mục trong <a href="/settings#tin-da-luu">Tin đã lưu</a>.</p>}
      {error && <p className="error" role="alert">{error}</p>}
      <button className="primary" disabled={busy || !folders}>{busy ? "Đang lưu…" : existing ? "Chuyển tin" : "Lưu"}</button>
    </form>
  </Dialog>;
}
