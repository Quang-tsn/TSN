import type { Tier } from "../../shared/extraPlans";
import { UpgradeArt } from "./UpgradeArt";
export function UpgradeLink({ tier, compact = false }: { tier?: Tier | null; compact?: boolean }) {
  const paid = tier === "Avip" || tier === "Svip";
  return <a href="/extraaccount" className={"extra-link" + (compact ? " extra-link-compact" : "") +
    (paid ? "" : " extra-link-promo")}>
    {!paid && <UpgradeArt/>}
    <span>{paid ? "Quản lý ExtraAccount" : "ExtraAccount"}
      {!paid && !compact && <small>Ảnh động, hồ sơ riêng và kho lưu tin</small>}</span>
  </a>;
}
