import { useState } from "react";
export function AnimatedMessage({ id,kind,playOnLoad=true }: { id: string; kind: string; playOnLoad?: boolean }) {
  const reduce=typeof window!=="undefined" && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const [playing,setPlaying]=useState(playOnLoad && !reduce);
  const name=kind==="sticker"?"Sticker động":"GIF động";
  return <div className="animated-message">
    {playing ? <iframe src={"https://giphy.com/embed/"+id} title={name}
      loading="lazy" allowFullScreen referrerPolicy="no-referrer"/>
      : <button className="secondary" onClick={()=>setPlaying(true)}>Phát {name}</button>}
    <a href={"https://giphy.com/gifs/"+id} target="_blank" rel="noopener noreferrer">Powered by GIPHY</a>
  </div>;
}
