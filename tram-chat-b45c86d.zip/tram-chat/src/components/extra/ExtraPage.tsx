import { useEffect, useState } from "react";
import { api } from "../../services/community/api";
import type { ExtraState } from "../../types/Extra";
import { TierBadge } from "./TierBadge";
import { PlanComparison } from "./PlanComparison";
import { TrialPanel } from "./TrialPanel";
import { RedeemCodeForm } from "./RedeemCodeForm";
import { UpcomingPayments } from "./UpcomingPayments";
import { Dialog } from "../primitives/Dialog";
import type { PaidTier } from "../../shared/extraPlans";

export function ExtraPage({ extra,error,reload,onActivated }: {
  extra: ExtraState | null; error: string; reload: () => Promise<void>; onActivated: (status: ExtraState["status"]) => void;
}) {
  const [busy,setBusy] = useState(false), [problem,setProblem] = useState("");
  const [chosen,setChosen] = useState<PaidTier | null>(null);
  const status = extra?.status;
  const signedIn = !!extra?.user;
  const ready = !!extra || !!error;
  useEffect(()=>{
    if (!signedIn) return;
    const tier = location.hash === "#ma-avip" ? "Avip" : location.hash === "#ma-svip" ? "Svip" : null;
    if (tier) {
      setChosen(tier);
      history.replaceState(null,"",location.pathname + location.search);
    }
  },[signedIn]);
  function choose(tier: PaidTier) {
    if (signedIn) setChosen(tier);
    else location.assign("/login?next=extraaccount#ma-" + tier.toLowerCase());
  }
  async function claim() {
    setBusy(true);setProblem("");
    try {
      await api("extra/trial-claim",{});
      await reload();
    } catch (cause) { setProblem((cause as Error).message); }
    finally { setBusy(false); }
  }
  return <section id="extraaccount" aria-labelledby="extra-title">
    <div className="extra-heading"><h1 id="extra-title">Gói ExtraAccount</h1>
      <p>So sánh quyền lợi và kích hoạt gói bằng mã.</p></div>
    <div className="extra-status" aria-live="polite" aria-label="Gói đang dùng">
      {status?.tier ? <><TierBadge tier={status.tier}/> Dùng đến {new Date(status.expiresAt!).toLocaleString("vi-VN")}</>
        : status?.allowed === false ? "Gói của tài khoản chính đã hết. Kích hoạt gói riêng hoặc chuyển về tài khoản chính."
          : signedIn ? "Bạn đang dùng gói cơ bản." : ready ? "Đăng nhập để kích hoạt gói." : "Đang tải trạng thái gói…"}
    </div>
    {(error || problem) && <p role="alert" className="error">{problem || error}</p>}
    <PlanComparison busy={busy || !ready} eligible={!!status?.allowed && !status.tier} signedIn={signedIn}
      onEnterCode={choose}
      onTrialOpen={()=>window.setTimeout(()=>void reload(),1000)}/>
    <TrialPanel ready={status?.tier ? null : extra?.trialReadyAt ?? null} busy={busy}
      claim={claim}/>
    <UpcomingPayments/>
    {chosen && <Dialog title={"Nhập mã " + chosen} onClose={()=>setChosen(null)}>
      <RedeemCodeForm tier={chosen} onActivated={onActivated}/>
    </Dialog>}
  </section>;
}
