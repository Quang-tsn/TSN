import { useContext } from "react";
import { ExtraContext } from "./ExtraContext";
import { UpgradeLink } from "./UpgradeLink";
import { TierBadge } from "./TierBadge";
export function AccountPromo() {
  const extra = useContext(ExtraContext);
  if (!extra) return null;
  return <div className="chat-extra">
    <UpgradeLink tier={extra.status?.tier} compact/>
    <TierBadge tier={extra.status?.tier}/>
  </div>;
}
