import { useContext,useState } from "react";
import type { Account } from "../../../types/Account";
import { requestAuth } from "../../../services/auth/requestAuth";
import { LogoutIcon } from "../../icons/LogoutIcon";
import { ExtraContext } from "../../extra/ExtraContext";
import { AccountPromo } from "../../extra/AccountPromo";
import { CoinBalanceLink } from "../../coins/CoinBalanceLink";
export function UserPanel({ user, onLogout }: { user: Account; onLogout: () => void }) {
  const extra = useContext(ExtraContext);
  const [error, setError] = useState(""), [busy, setBusy] = useState(false);
  async function logout() {
    setBusy(true);
    try { await requestAuth("logout", {}); onLogout(); }
    catch (cause) { setError((cause as Error).message); setBusy(false); }
  }
  return <><AccountPromo/><CoinBalanceLink/><footer className="user-panel">
    <a className="user-settings-link" href="/settings" aria-label="Mở cài đặt tài khoản" title="Cài đặt">
    <div className="mini-avatar">
    {extra?.status?.tier && extra.images?.some(item=>item.kind==="avatar")
      ? <img className="vip-avatar" alt="" src={"/api/extra/profile/"+user.id+"/avatar"}/>
      : user.username[0].toUpperCase()}</div>
    <div className="user-label"><strong>{user.display_name}</strong><small>@{user.username}</small></div>
    </a>
    <button className="icon-button" disabled={busy} title="Đăng xuất" aria-label="Đăng xuất"
      onClick={logout}><LogoutIcon/></button>
    {error && <small className="user-settings-error" role="alert">{error}</small>}
  </footer></>;
}
