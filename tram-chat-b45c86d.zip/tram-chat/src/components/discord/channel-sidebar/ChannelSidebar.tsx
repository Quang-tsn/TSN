import type { Account } from "../../../types/Account";
import type { Channel, Detail } from "../../../types/Community";
import { HashIcon } from "../../icons/HashIcon";
import { PlusIcon } from "../../icons/PlusIcon";
import { EditIcon } from "../../icons/EditIcon";
import { UserPlusIcon } from "../../icons/UserPlusIcon";
import { UserPanel } from "./UserPanel";
import { VerifiedCommunityIcon } from "../../icons/VerifiedCommunityIcon";
export function ChannelSidebar({ detail, roomId, user, onSelect, onCreate, onEdit, onInvite, onLogout, onVisibility }: {
  detail: Detail | null; roomId: string | null; user: Account; onSelect: (id: string) => void;
  onCreate: () => void; onEdit: (channel: Channel) => void; onInvite: () => void; onLogout: () => void;
  onVisibility: () => void;
}) {
  const manage = detail && ["owner", "admin"].includes(detail.role);
  return <aside className="channel-sidebar">
    <header className="server-title"><strong className="server-title-name">{detail?.server.name || "Trạm của bạn"}
      {!!detail?.server.verified && <VerifiedCommunityIcon/>}</strong>
      {detail?.role === "owner" && !detail.server.verified && <button className="icon-button"
        title="Quyền tham gia server" aria-label="Quyền tham gia server" onClick={onVisibility}><EditIcon/></button>}
      {manage && <button className="icon-button" title="Mời bạn" aria-label="Mời bạn" onClick={onInvite}>
        <UserPlusIcon/></button>}</header>
    <div className="channel-nav"><div className="category-label"><span>KÊNH CHỮ</span>
      {manage && <button className="icon-button" title="Tạo kênh" aria-label="Tạo kênh" onClick={onCreate}>
        <PlusIcon/></button>}</div>
      {detail?.channels.map((channel) => <div key={channel.id}
        className={"channel-row " + (channel.id === roomId ? "selected" : "")}>
        <button className="channel-select" onClick={() => onSelect(channel.id)}
          aria-current={channel.id === roomId ? "page" : undefined}>
          <HashIcon/><span>{channel.name}</span></button>
        {manage && <button className="icon-button channel-edit" title={"Cài đặt #" + channel.name}
          aria-label={"Cài đặt #" + channel.name} onClick={() => onEdit(channel)}><EditIcon/></button>}
      </div>)}
      {!detail && <p className="sidebar-note">Chọn một server hoặc tạo chỗ hẹn mới cho hội bạn.</p>}
    </div><UserPanel user={user} onLogout={onLogout}/>
  </aside>;
}
