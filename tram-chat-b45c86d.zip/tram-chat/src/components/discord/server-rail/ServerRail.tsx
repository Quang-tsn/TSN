import type { Server } from "../../../types/Community";
import { BrandLogo } from "../../icons/BrandLogo";
import { PlusIcon } from "../../icons/PlusIcon";
import { JoinServerIcon } from "../../icons/JoinServerIcon";
import { DiscoverIcon } from "../../icons/DiscoverIcon";
import { VerifiedCommunityIcon } from "../../icons/VerifiedCommunityIcon";
export function ServerRail({ servers, selected, onSelect, onCreate, onJoin, onDiscover }: {
  servers: Server[]; selected: string | null; onSelect: (id: string | null) => void;
  onCreate: () => void; onJoin: () => void; onDiscover: () => void;
}) {
  return <nav className="server-rail" aria-label="Server">
    <button className={"rail-button home " + (!selected ? "active" : "")}
      title="Trang chủ" aria-label="Trang chủ Trạm" onClick={() => onSelect(null)}><BrandLogo/> Trạm</button>
    <div className="rail-divider"/>
    <div className="server-stack">{servers.map((server) =>
      <button key={server.id} className={"rail-button " + (selected === server.id ? "active" : "")}
        aria-label={server.name + (server.verified ? " · Đã xác minh" : "")} title={server.name} aria-pressed={selected === server.id}
        onClick={() => onSelect(server.id)}>{server.name.slice(0, 2).toUpperCase()}
        {!!server.verified && <VerifiedCommunityIcon/>}</button>)}</div>
    <button className="rail-button rail-action" title="Khám phá cộng đồng" aria-label="Khám phá cộng đồng"
      onClick={onDiscover}><DiscoverIcon/></button>
    <button className="rail-button rail-action" title="Tạo server" aria-label="Tạo server"
      onClick={onCreate}><PlusIcon/></button>
    <button className="rail-button rail-action" title="Nhập mã mời" aria-label="Nhập mã mời"
      onClick={onJoin}><JoinServerIcon/></button>
  </nav>;
}
