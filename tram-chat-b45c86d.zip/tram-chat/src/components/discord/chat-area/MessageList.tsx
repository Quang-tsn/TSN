import { useLayoutEffect,useRef,useState } from "react";
import type { Message } from "../../../types/Community";
import { MessageRow } from "./MessageRow";
import type { LinkPreview } from "../../../types/LinkPreview";
export function MessageList({ messages, name, hasMore, history, loading, onOlder, onLatest, room, onReply, onProfile, onSave,onPreview }: {
  messages: Message[]; name: string; hasMore: boolean; history: boolean; loading: boolean;
  onOlder: () => void; onLatest: () => void;
  room?: string; onReply?: (message: Message) => void; onProfile?: (message: Message) => void;
  onSave?: (message: Message)=>void;
  onPreview?: (preview:LinkPreview)=>void;
}) {
  const list = useRef<HTMLDivElement>(null), bottom = useRef(true);
  const [active,setActive] = useState<string | null>(null);
  const last = messages[messages.length - 1]?.id;
  useLayoutEffect(() => {
    if (bottom.current && list.current) list.current.scrollTop = list.current.scrollHeight;
  }, [last]);
  return <div className="message-scroll" ref={list} onScroll={() => {
    const el = list.current!;
    bottom.current = el.scrollHeight - el.scrollTop - el.clientHeight < 100;
  }}>
    {!messages.length && !loading && <div className="channel-intro"><h2>{name}</h2>
      <p>Chưa có tin nhắn. Viết vài dòng hoặc dán một tấm ảnh.</p></div>}
    <div className="history-actions">
      {hasMore && <button disabled={loading} className="text-button" onClick={onOlder}>Xem 50 tin trước</button>}
      {history && <button className="text-button" onClick={() => {
        bottom.current = true; onLatest();
      }}>Về tin mới nhất</button>}
    </div>
    {loading && !messages.length && <p className="chat-notice" role="status">Đang tải tin nhắn…</p>}
    {history && <p className="chat-notice">Bạn đang xem tin nhắn cũ.</p>}
    <div className="message-items" role="log" aria-label={"Tin nhắn #" + name} aria-live="off">
      {messages.slice(-50).map((message) => <MessageRow key={message.id} message={message}
        room={room || ""} onReply={onReply} onProfile={onProfile} onSave={onSave} actionsOpen={message.id===active} onPreview={onPreview}
        onToggle={onReply || onSave ? ()=>setActive(current=>current === message.id ? null : message.id) : undefined}/>)}
    </div>
  </div>;
}
