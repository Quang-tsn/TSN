import { HashIcon } from "../../icons/HashIcon";
import { MenuIcon } from "../../icons/MenuIcon";
import { UsersIcon } from "../../icons/UsersIcon";
import type { Channel } from "../../../types/Community";
import { ChatSoundButton } from "./ChatSoundButton";
export function ChatHeader({ channel, onMenu, onMembers, showingMembers }: {
  channel: Channel; onMenu: () => void; onMembers: () => void; showingMembers: boolean;
}) {
  return <header className="chat-header">
    <button className="icon-button mobile-menu" aria-label="Mở danh sách kênh" onClick={onMenu}><MenuIcon/></button>
    <HashIcon/><strong>{channel.name}</strong>
    {channel.topic && <span className="channel-topic">{channel.topic}</span>}
    <button className="icon-button members-toggle" title="Thành viên" aria-label="Thành viên"
      aria-expanded={showingMembers} onClick={onMembers}><UsersIcon/></button>
    <ChatSoundButton/>
  </header>;
}
