import { useContext } from "react";
import { BellIcon } from "../../icons/BellIcon";
import { ChatAlertsContext } from "../shell/ChatAlertsContext";

export function ChatSoundButton() {
  const sound = useContext(ChatAlertsContext);
  if (!sound) return null;
  return <button type="button" className="icon-button chat-sound" aria-label="Âm báo chat"
    aria-pressed={sound.enabled} title={sound.enabled ? "Tắt âm báo chat" : "Bật âm báo chat"}
    onClick={sound.toggle}><BellIcon muted={!sound.enabled}/></button>;
}
