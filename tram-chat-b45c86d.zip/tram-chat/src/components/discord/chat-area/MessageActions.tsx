import { useContext } from "react";
import type { Message } from "../../../types/Community";
import { ReplyIcon } from "../../icons/ReplyIcon";
import { BookmarkIcon } from "../../icons/BookmarkIcon";
import { ExtraContext } from "../../extra/ExtraContext";

export function MessageActions({ message,onReply,onSave }: {
  message: Message; onReply?: (message: Message)=>void; onSave?: (message: Message)=>void;
}) {
  const status = useContext(ExtraContext)?.status;
  const canSave = !!(status?.tier && onSave && (message.content || message.image_id || message.giphy_id));
  const label = message.is_saved ? "Chuyển thư mục tin đã lưu" : message.content ? "Lưu tin nhắn"
    : message.image_id ? "Lưu ảnh" : message.animation_kind === "sticker" ? "Lưu sticker" : "Lưu GIF";
  if (!canSave && !onReply) return null;
  return <div className="message-actions" aria-label="Thao tác tin nhắn">
    {canSave && <button className="icon-button" type="button" title={label} aria-label={label}
      onClick={()=>onSave?.(message)}><BookmarkIcon filled={!!message.is_saved}/></button>}
    {onReply && <button className="icon-button" type="button" title="Trả lời"
      aria-label={"Trả lời " + message.display_name} onClick={()=>onReply(message)}><ReplyIcon/></button>}
  </div>;
}
