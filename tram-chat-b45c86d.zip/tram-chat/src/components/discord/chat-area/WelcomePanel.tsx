import { BrandLogo } from "../../icons/BrandLogo";
export function WelcomePanel({ onCreate, onJoin, onDiscover }: { onCreate: () => void; onJoin: () => void; onDiscover: () => void }) {
  return <section className="welcome-panel"><div className="welcome-mark"><BrandLogo/></div>
    <span className="eyebrow">TRẠM / CỘNG ĐỒNG</span><h1>Hội bạn hẹn ở đâu?</h1>
    <p>Tạo server cho nhóm của bạn, hoặc nhập mã mời để tham gia.</p>
    <div className="welcome-actions"><button className="primary" onClick={onCreate}>Tạo server</button>
      <button className="secondary" onClick={onJoin}>Nhập mã mời</button>
      <button className="secondary" onClick={onDiscover}>Khám phá cộng đồng</button></div>
    <p className="hint">Mỗi server có kênh riêng. Chỉ thành viên mới đọc được tin nhắn.</p>
  </section>;
}
