import type { Message } from "../../../types/Community";
export function MessageImage({ room, message }: { room: string; message: Pick<Message,"image_id"|"image_width"|"image_height"> }) {
  if (!message.image_id) return null;
  const url = "/api/rooms/" + room + "/images/" + message.image_id;
  const width = message.image_width || 1, height = message.image_height || 1;
  return <a className="message-image" href={url} target="_blank" rel="noopener"
    aria-label="Mở ảnh gốc trong thẻ mới">
    <img src={url} alt="Ảnh đính kèm" loading="lazy" decoding="async"
      width={width} height={height}/>
  </a>;
}
