import { useState } from "react";
import type { LinkPreview } from "../../../types/LinkPreview";
import { Dialog } from "../../primitives/Dialog";

export function LinkPreviewDialog({preview,onClose}: {preview:LinkPreview;onClose:()=>void}) {
  const [failed,setFailed] = useState(false);
  return <Dialog title={preview.kind==="web" ? "Xem trước trang web" : preview.title}
    className="chat-preview-dialog" onClose={onClose}>
    <div className="chat-link-preview">
      <div className="chat-preview-source"><span>{preview.host}</span>
        <a href={preview.url} target="_blank" rel="noopener noreferrer">Mở trang gốc</a></div>
      {preview.kind==="video" ? failed ?
        <p role="status">Trình duyệt không phát được tệp này. Bạn có thể mở video ở trang gốc.</p>
        : <video src={preview.source} aria-label={preview.title} controls playsInline preload="metadata"
          onError={()=>setFailed(true)}/>
        : preview.kind==="provider" ? <iframe src={preview.source} title={preview.title} allowFullScreen
          sandbox="allow-scripts allow-same-origin allow-presentation" referrerPolicy="strict-origin-when-cross-origin"
          allow="fullscreen; encrypted-media; picture-in-picture"/>
        : <iframe src={preview.source} title={"Xem trước "+preview.host} sandbox="" referrerPolicy="no-referrer"/>}
      {preview.kind==="web" && <p>Nếu trang chặn xem trước, chọn Mở trang gốc.</p>}
    </div>
  </Dialog>;
}
