import type { useMentionSuggestions } from "../../../hooks/chat/useMentionSuggestions";

export function MentionSuggestions({mentions}: {mentions:ReturnType<typeof useMentionSuggestions>}) {
  if (!mentions.choices.length) return null;
  return <div className="mention-suggestions" id={mentions.listId} role="listbox" aria-label="Người có thể nhắc">
    {mentions.choices.map((option,index)=><div className="mention-option" key={option.id}
      id={mentions.listId+"-"+index} role="option" aria-selected={mentions.selected===index}
      onPointerDown={event=>event.preventDefault()} onClick={()=>mentions.choose(option.username)}>
      <strong>@{option.username}</strong><span>{option.display_name}</span>
    </div>)}
  </div>;
}
