import type { Message } from "../../../types/Community";
import { MessageImage } from "./MessageImage";
import { AnimatedMessage } from "../../extra/AnimatedMessage";
import { AuthorAvatar } from "../../profile/AuthorAvatar";
import { MessageAuthor } from "./MessageAuthor";
import { MessageActions } from "./MessageActions";
import { MessageText } from "./MessageText";
import type { LinkPreview } from "../../../types/LinkPreview";
export function MessageRow({ message,room,onReply,onProfile,onSave,actionsOpen,onToggle,onPreview }: {
  message: Message; room: string; onReply?: (message: Message) => void;
  onProfile?: (message: Message) => void;
  onSave?: (message: Message) => void; actionsOpen?: boolean; onToggle?: () => void;
  onPreview?: (preview:LinkPreview)=>void;
}) {
  return <article className={"message-row" + (actionsOpen ? " actions-open" : "")} tabIndex={onToggle ? 0 : undefined}
    onClick={onToggle && (event=>{
      if (event.target instanceof Element && !event.target.closest("button,a,input,iframe") && !window.getSelection()?.toString()) onToggle();
    })}>
    {onProfile ? <button className="message-avatar author-avatar-button" type="button"
      aria-label={"Xem hồ sơ " + message.display_name} onClick={()=>onProfile(message)}><AuthorAvatar message={message}/></button>
      : <div className="message-avatar"><AuthorAvatar message={message}/></div>}
    <div className="message-body">
      {message.reply_id && <blockquote className="reply-quote">
        <strong>{message.reply_author || "Tin nhắn đã xóa"}</strong>
        {message.reply_author && <span>{message.reply_content || "Ảnh đính kèm"}</span>}
      </blockquote>}
      <MessageAuthor message={message}/>{message.content && <MessageText content={message.content} onPreview={onPreview}/>}
      <MessageImage room={room} message={message}/>
      {message.giphy_id && <AnimatedMessage id={message.giphy_id} kind={message.animation_kind || "gif"}/>}</div>
    <MessageActions message={message} onReply={onReply} onSave={onSave}/>
  </article>;
}
