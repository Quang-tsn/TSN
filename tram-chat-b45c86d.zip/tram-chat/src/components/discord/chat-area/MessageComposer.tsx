import { useContext, useRef, useState, type FormEvent } from "react";
import { SendIcon } from "../../icons/SendIcon";
import { ImageIcon } from "../../icons/ImageIcon";
import { useComposerShortcut } from "../../../hooks/chat/useComposerShortcut";
import { useImageDraft } from "../../../hooks/chat/useImageDraft";
import { postMessage } from "../../../services/community/postMessage";
import { ComposerContext } from "./ComposerContext";
import type { Member,Message } from "../../../types/Community";
import type { Animation } from "../../../types/Extra";
import { ComposerAnimation } from "../../extra/ComposerAnimation";
import { useMentionSuggestions } from "../../../hooks/chat/useMentionSuggestions";
import { MentionSuggestions } from "./MentionSuggestions";
import { ExtraContext } from "../../extra/ExtraContext";
import { extraChatImage,freeChatImage } from "../../../shared/chatImageLimits";
export function MessageComposer({ roomId, name, onSent, reply, onClearReply, input,members }: {
  roomId: string; name: string; onSent: () => void; reply: Message | null;
  onClearReply: () => void; input: React.RefObject<HTMLTextAreaElement | null>;
  members: Member[];
}) {
  const [content, setContent] = useState(""), [pending, setPending] = useState(false);
  const mentions = useMentionSuggestions(input,content,setContent,members);
  const [error, setError] = useState("");
  const limits = useContext(ExtraContext)?.status?.tier ? extraChatImage : freeChatImage;
  const image = useImageDraft(setError,limits.megabytes);
  const [animation,setAnimation] = useState<Animation | null>(null);
  const picker = useRef<HTMLInputElement>(null);
  const attempt = useRef<{ key: string; file: File | null; nonce: string } | null>(null);
  useComposerShortcut(input);
  async function submit(e?: FormEvent) {
    e?.preventDefault();
    const text = content.trim();
    const selectedAnimation = image.file ? null : animation;
    if ((!text && !image.file && !selectedAnimation) || pending) return;
    const key = JSON.stringify([text, reply?.id, selectedAnimation]);
    if (attempt.current?.key !== key || attempt.current.file !== image.file) {
      attempt.current = { key, file: image.file,
      nonce: crypto.randomUUID ? crypto.randomUUID() : Array.from(crypto.getRandomValues(new Uint8Array(16)),
        (n) => n.toString(16).padStart(2, "0")).join("") };
    }
    setPending(true); setError("");
    try {
      await postMessage(roomId, text, attempt.current.nonce, reply?.id, image.file,selectedAnimation);
      setContent(""); mentions.close(); attempt.current = null; image.clear(); setAnimation(null); onClearReply(); onSent();
    } catch (cause) { setError((cause as Error).message); }
    finally { setPending(false); }
  }
  return <div className="composer-wrap"><p className="error" role="alert">{error}</p>
    <div className="compose-panel">
    <form onSubmit={submit} onPaste={(e) => { if (!pending) image.paste(e); }}>
      <ComposerContext reply={reply} preview={image.preview} onClearReply={onClearReply}
        onClearImage={image.clear} disabled={pending}/>
      <div className="composer" onClick={(e) => { if (e.target === e.currentTarget) input.current?.focus(); }}>
      <MentionSuggestions mentions={mentions}/>
      <input type="file" hidden ref={picker} accept="image/png,image/jpeg" onChange={(e) => {
        image.select(e.target.files?.[0]); e.target.value = "";
      }}/>
      <button className="icon-button" aria-label="Thêm ảnh" title="Thêm ảnh" type="button"
        disabled={pending} onClick={() => picker.current?.click()}><ImageIcon/></button>
      <textarea ref={input} aria-keyshortcuts="/" aria-label={"Nhập tin nhắn tới #" + name} placeholder={"Nhắn vào " + name}
        aria-autocomplete="list" aria-controls={mentions.choices.length ? mentions.listId : undefined}
        aria-activedescendant={mentions.choices.length ? mentions.listId+"-"+mentions.selected : undefined}
        value={content} onChange={e=>{setContent(e.target.value);mentions.position(e.target);}} maxLength={4000}
        onSelect={e=>mentions.position(e.currentTarget)} onBlur={mentions.close}
        rows={1} disabled={pending} onKeyDown={(e) => {
          if (mentions.keydown(e)) return;
          if (e.key === "Enter" && !e.shiftKey && !e.nativeEvent.isComposing) {
            e.preventDefault(); void submit();
          }
        }}/>
      <button className="icon-button send-button" aria-label="Gửi tin nhắn" type="submit"
        disabled={pending || (!content.trim() && !image.file && !animation)}><SendIcon/></button>
      </div>
    </form>
    {!image.file && <ComposerAnimation selection={animation} onSelect={setAnimation} disabled={pending}/>}
    </div><div className="composer-hint"><kbd>/</kbd> Soạn tin · <kbd>@</kbd> Nhắc người · Enter để gửi</div>
  </div>;
}
