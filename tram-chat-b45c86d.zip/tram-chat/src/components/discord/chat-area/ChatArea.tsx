import { useState, useRef } from "react";
import type { Channel, Member, Message } from "../../../types/Community";
import { useMessages } from "../../../hooks/chat/useMessages";
import { ChatHeader } from "./ChatHeader";
import { MemberList } from "./MemberList";
import { MessageList } from "./MessageList";
import { MessageComposer } from "./MessageComposer";
import { AuthorProfileDialog } from "../../profile/AuthorProfileDialog";
import { SavedLocationDialog } from "../../extra/SavedLocationDialog";
import { LinkPreviewDialog } from "./LinkPreviewDialog";
import type { LinkPreview } from "../../../types/LinkPreview";
export function ChatArea({ channel, members, userId,onMenu }: {
  channel: Channel; members: Member[]; userId:string; onMenu: () => void;
}) {
  const [showMembers, setShowMembers] = useState(false);
  const feed = useMessages(channel.id);
  const [reply, setReply] = useState<Message | null>(null);
  const [profile, setProfile] = useState<Message | null>(null);
  const [bookmark,setBookmark] = useState<Message | null>(null);
  const [preview,setPreview] = useState<LinkPreview | null>(null);
  const input = useRef<HTMLTextAreaElement>(null);
  return <section className="chat-area">
    <ChatHeader channel={channel} onMenu={onMenu} showingMembers={showMembers}
      onMembers={() => setShowMembers(!showMembers)}/>
    {showMembers && <MemberList members={members}/>}
    {feed.error && <p className="feed-error" role="alert">{feed.error}
      <button className="text-button" onClick={feed.refresh}>Thử lại</button></p>}
    <MessageList messages={feed.messages} name={channel.name} loading={feed.loading}
      hasMore={feed.hasMore} history={feed.history} onOlder={feed.older} onLatest={feed.refresh}
      room={channel.id} onProfile={setProfile} onSave={setBookmark} onPreview={setPreview}
      onReply={(message) => { setReply(message); input.current?.focus(); }}/>
    <MessageComposer roomId={channel.id} name={channel.name} onSent={feed.refresh}
      input={input} reply={reply} members={members.filter(member=>member.id!==userId)} onClearReply={() => setReply(null)}/>
    {preview && <LinkPreviewDialog preview={preview} onClose={()=>setPreview(null)}/>}
    {profile && <AuthorProfileDialog author={profile} onClose={()=>setProfile(null)}/>}
    {bookmark && <SavedLocationDialog id={bookmark.id} existing={!!bookmark.is_saved} folderId={bookmark.saved_folder_id}
      onClose={()=>setBookmark(null)} onDone={()=>{setBookmark(null);feed.reloadPage();}}/>}
  </section>;
}
