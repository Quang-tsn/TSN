import { memo } from "react";
import { chatLinks } from "../../../shared/chatLinks";
import { chatMentions } from "../../../shared/chatMentions";
import { linkPreview } from "../../../utils/linkPreview";
import type { LinkPreview } from "../../../types/LinkPreview";
import { MessageLinkCard } from "./MessageLinkCard";

export const MessageText = memo(function MessageText({content,onPreview}:{
  content:string;onPreview?:(preview:LinkPreview)=>void;
}) {
  const links = chatLinks(content);
  const fragments = [
    ...links.map(link=>({...link,element:<a className="chat-link" href={link.url.href}
      target="_blank" rel="noopener noreferrer">{link.label}</a>})),
    ...chatMentions(content,links).map(mention=>({...mention,element:<span className="mention-token">
      {content.slice(mention.start,mention.end)}</span>})),
  ].sort((a,b)=>a.start-b.start);
  let offset = 0;
  const cards = [...new Map(links.map(link=>[link.url.href,link.url])).values()].slice(0,3);
  return <>
    <p>{fragments.map(fragment=>{
      const text = content.slice(offset,fragment.start);
      offset = fragment.end;
      return <span key={fragment.start}>{text}{fragment.element}</span>;
    })}{content.slice(offset)}</p>
    {onPreview && cards.map(url=><MessageLinkCard key={url.href} preview={linkPreview(url)} onOpen={onPreview}/>)}
  </>;
});
