import { CloseIcon } from "../../icons/CloseIcon";
import type { Message } from "../../../types/Community";
export function ComposerContext({ reply, preview, onClearReply, onClearImage, disabled }: {
  reply: Message | null; preview: string; onClearReply: () => void;
  onClearImage: () => void; disabled: boolean;
}) {
  return <>
    {reply && <div className="draft-context"><span>Trả lời <strong>{reply.display_name}</strong>
      <small>{reply.content || "Ảnh đính kèm"}</small></span>
      <button type="button" className="icon-button" disabled={disabled} aria-label="Hủy trả lời"
        onClick={onClearReply}><CloseIcon/></button></div>}
    {preview && <div className="draft-context"><img src={preview} alt="Ảnh xem trước"/>
      <span>Ảnh đính kèm</span><button type="button" className="icon-button" disabled={disabled}
        aria-label="Bỏ ảnh" onClick={onClearImage}><CloseIcon/></button></div>}
  </>;
}
