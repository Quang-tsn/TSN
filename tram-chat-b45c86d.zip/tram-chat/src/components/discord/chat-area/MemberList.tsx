import type { Member } from "../../../types/Community";
export function MemberList({ members }: { members: Member[] }) {
  return <aside className="member-popover" aria-label="Thành viên">
    <h3>Thành viên · {members.length}</h3>
    {members.map((member) => <div className="member-row" key={member.id}>
      <div className="mini-avatar">{member.username[0].toUpperCase()}</div>
      <div><strong>{member.display_name}</strong>
        <small>{member.role === "owner" ? "Chủ server" : member.role === "admin" ? "Quản trị" : "Thành viên"}</small>
      </div></div>)}
    <p className="hint">Chưa hiển thị trạng thái online.</p>
  </aside>;
}
