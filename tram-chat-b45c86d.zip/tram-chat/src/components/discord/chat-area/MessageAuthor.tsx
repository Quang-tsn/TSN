import type { Message } from "../../../types/Community";
import { TierBadge } from "../../extra/TierBadge";
import { AuthorBanner } from "../../profile/AuthorBanner";

export function MessageAuthor({ message }: { message: Message }) {
  return <div className="message-meta">
    <span className={"message-name-card" + (message.tier === "Svip" && message.has_background ? " has-banner" : "")}>
      <AuthorBanner message={message}/><strong>{message.display_name}</strong><TierBadge tier={message.tier}/>
    </span>
    <time dateTime={new Date(message.created_at).toISOString()} title={new Date(message.created_at).toLocaleString("vi-VN")}>
      {new Date(message.created_at).toLocaleTimeString("vi-VN",{ hour:"2-digit",minute:"2-digit" })}
    </time>
  </div>;
}
