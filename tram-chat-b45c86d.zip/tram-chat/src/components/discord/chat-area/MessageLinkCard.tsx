import { LinkIcon } from "../../icons/LinkIcon";
import type { LinkPreview } from "../../../types/LinkPreview";

export function MessageLinkCard({preview,onOpen}: {
  preview:LinkPreview; onOpen:(preview:LinkPreview)=>void;
}) {
  return <div className="message-link-card">
    <div className="message-link-icon"><LinkIcon/></div>
    <div className="message-link-label"><strong>{preview.title}</strong><small>{preview.host}</small></div>
    {preview.kind==="external" ?
      <a href={preview.url} target="_blank" rel="noopener noreferrer">Mở liên kết</a> :
      <button type="button" onClick={()=>onOpen(preview)}>
        {preview.kind==="web" ? "Xem trước web" : "Xem video"}
      </button>}
  </div>;
}
