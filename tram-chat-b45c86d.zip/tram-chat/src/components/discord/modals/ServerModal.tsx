import { useState, type FormEvent } from "react";
import { Dialog } from "../../primitives/Dialog";
import { api } from "../../../services/community/api";
export function ServerModal({ join, onClose, onDone }: {
  join: boolean; onClose: () => void; onDone: (id: string) => Promise<void>;
}) {
  const [error, setError] = useState(""), [pending, setPending] = useState(false);
  async function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault(); setPending(true); setError("");
    const fields = new FormData(e.currentTarget);
    const value = fields.get("value");
    try {
      const result = await api<{ id: string }>(join ? "servers/join" : "servers",
        join ? { code: value } : { name: value, isPublic:fields.has("public") });
      await onDone(result.id);
    } catch (cause) { setError((cause as Error).message); }
    finally { setPending(false); }
  }
  return <Dialog title={join ? "Vào server" : "Tạo server"} onClose={onClose}>
    <p>{join ? "Dán mã mời mà hội bạn đã gửi." : "Đặt một cái tên cho chỗ hẹn của hội bạn."}</p>
    <form onSubmit={submit}><fieldset disabled={pending}>
      <label>{join ? "Mã mời" : "Tên server"}<input name="value" required
        maxLength={join ? 32 : 100} autoComplete="off"
        placeholder={join ? "Dán mã mời ở đây" : "Ví dụ: Hội chơi tối nay"}/></label>
      {!join && <label className="community-public"><input type="checkbox" name="public"/> Công khai trong Khám phá</label>}
      <p className="error" role="alert">{error}</p>
      <button className="primary">{pending ? "Đang xử lý…" : join ? "Tham gia" : "Tạo server"}</button>
    </fieldset></form>
  </Dialog>;
}
