import { useState, type FormEvent } from "react";
import type { Channel } from "../../../types/Community";
import { Dialog } from "../../primitives/Dialog";
import { api } from "../../../services/community/api";
export function ChannelModal({ serverId, channel, onClose, onDone }: {
  serverId: string; channel?: Channel; onClose: () => void; onDone: () => void;
}) {
  const [error, setError] = useState(""), [pending, setPending] = useState(false);
  const [confirm, setConfirm] = useState(false);
  async function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault(); setPending(true); setError("");
    const values = Object.fromEntries(new FormData(e.currentTarget).entries());
    try {
      await api(channel ? "rooms/" + channel.id : "servers/" + serverId + "/channels",
        values, channel ? "PATCH" : "POST");
      onDone();
    } catch (cause) { setError((cause as Error).message); }
    finally { setPending(false); }
  }
  async function remove() {
    if (!confirm) { setConfirm(true); return; }
    setPending(true);
    try { await api("rooms/" + channel!.id, {}, "DELETE"); onDone(); }
    catch (cause) { setError((cause as Error).message); setPending(false); }
  }
  return <Dialog title={channel ? "Cài đặt kênh" : "Tạo kênh chữ"} onClose={onClose}>
    <form onSubmit={submit}><fieldset disabled={pending}>
      <label>Tên kênh<input name="name" required maxLength={60} defaultValue={channel?.name}
        placeholder="Ví dụ: hoi-choi-game"/></label>
      {channel && <label>Chủ đề<input name="topic" maxLength={1000} defaultValue={channel.topic}/></label>}
      <p role="alert" className="error">{error}</p>
      <button className="primary">{pending ? "Đang lưu…" : channel ? "Lưu thay đổi" : "Tạo kênh"}</button>
      {channel && <button type="button" className="danger" onClick={remove}>
        {confirm ? "Xác nhận xóa kênh và toàn bộ tin nhắn" : "Xóa kênh"}</button>}
    </fieldset></form>
  </Dialog>;
}
