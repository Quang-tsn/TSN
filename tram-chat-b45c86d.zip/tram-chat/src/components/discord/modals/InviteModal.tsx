import { useState } from "react";
import { Dialog } from "../../primitives/Dialog";
import { api } from "../../../services/community/api";
export function InviteModal({ serverId, onClose }: { serverId: string; onClose: () => void }) {
  const [code, setCode] = useState(""), [error, setError] = useState("");
  const [pending, setPending] = useState(false), [copied, setCopied] = useState(false);
  async function generate() {
    setPending(true); setError("");
    try { setCode((await api<{ code: string }>("servers/" + serverId + "/invites", {})).code); }
    catch (cause) { setError((cause as Error).message); }
    finally { setPending(false); }
  }
  async function copy() {
    try { await navigator.clipboard.writeText(code); setCopied(true); }
    catch { setError("Chọn mã bên dưới rồi sao chép thủ công nhé."); }
  }
  return <Dialog title="Mời bạn vào server" onClose={onClose}>
    <p>Mã dùng trong 7 ngày. Gửi cho người bạn muốn mời.</p>
    {code ? <><label>Mã mời<input readOnly value={code} onFocus={(e) => e.target.select()}/></label>
      <button className="primary" onClick={copy}>{copied ? "Đã sao chép" : "Sao chép mã mời"}</button></>
      : <button className="primary" disabled={pending} onClick={generate}>
        {pending ? "Đang tạo…" : "Tạo mã mời"}</button>}
    <p role="alert" className="error">{error}</p>
  </Dialog>;
}
