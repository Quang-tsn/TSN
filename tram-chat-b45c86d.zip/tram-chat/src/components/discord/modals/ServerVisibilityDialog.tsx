import { useState, type FormEvent } from "react";
import type { Server } from "../../../types/Community";
import { api } from "../../../services/community/api";
import { Dialog } from "../../primitives/Dialog";

export function ServerVisibilityDialog({ server,onClose,onSaved }: {
  server: Server; onClose: () => void; onSaved: () => void;
}) {
  const [visible,setVisible] = useState(!!server.is_public);
  const [busy,setBusy] = useState(false);
  const [error,setError] = useState("");
  async function save(event: FormEvent) {
    event.preventDefault();setBusy(true);setError("");
    try { await api("servers/"+server.id+"/visibility",{isPublic:visible}); onSaved(); }
    catch (cause) { setError((cause as Error).message); }
    finally { setBusy(false); }
  }
  return <Dialog title="Quyền tham gia server" onClose={onClose}>
    <form onSubmit={save}><label className="community-public"><input type="checkbox" checked={visible}
      onChange={event=>setVisible(event.target.checked)} disabled={busy}/> Công khai trong Khám phá</label>
      <p>Người dùng có thể tìm và tham gia ngay. Khi tham gia, họ có thể xem tin nhắn đã có trong các kênh.</p>
      {error && <p className="error" role="alert">{error}</p>}
      <button className="primary" disabled={busy || visible === !!server.is_public}>Lưu quyền tham gia</button>
    </form>
  </Dialog>;
}
