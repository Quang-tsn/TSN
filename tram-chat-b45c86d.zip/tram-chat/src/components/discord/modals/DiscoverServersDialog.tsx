import { useEffect,useState, type FormEvent } from "react";
import { Dialog } from "../../primitives/Dialog";
import { VerifiedCommunityIcon } from "../../icons/VerifiedCommunityIcon";
import { api } from "../../../services/community/api";
import type { PublicServer } from "../../../types/Community";

export function DiscoverServersDialog({ onClose,onDone }: { onClose: () => void; onDone: (id: string)=>Promise<void> }) {
  const [query,setQuery] = useState("");
  const [search,setSearch] = useState("");
  const [servers,setServers] = useState<PublicServer[] | null>(null);
  const [busy,setBusy] = useState("");
  const [error,setError] = useState("");
  useEffect(()=>{
    const controller=new AbortController();
    setServers(null);setError("");
    api<{servers: PublicServer[]}>("servers/discover?q=" + encodeURIComponent(search),undefined,"GET",controller.signal)
      .then(result=>{ if (!controller.signal.aborted) setServers(result.servers); })
      .catch(cause=>{ if (!controller.signal.aborted) setError(cause.message); });
    return ()=>controller.abort();
  },[search]);
  function submit(event: FormEvent) { event.preventDefault(); setSearch(query.trim()); }
  async function join(server: PublicServer) {
    setBusy(server.id);setError("");
    try {
      if (!server.joined) await api("servers/"+server.id+"/join-public",{});
      await onDone(server.id);
    } catch (cause) { setError((cause as Error).message); }
    finally { setBusy(""); }
  }
  return <Dialog title="Khám phá cộng đồng" onClose={onClose}>
    <form className="community-search" onSubmit={submit}>
      <label>Tên server<input type="search" value={query} maxLength={100} onChange={event=>setQuery(event.target.value)}/></label>
      <button className="primary" type="submit">Tìm</button>
    </form>
    <h3>{search ? "Kết quả tìm kiếm" : "Gợi ý cho bạn"}</h3>
    {error && <p className="error" role="alert">{error}</p>}
    {!servers && !error && <p role="status">Đang tìm cộng đồng…</p>}
    {servers?.length === 0 && <p>Chưa thấy server nào. Thử tìm bằng tên khác.</p>}
    <ul className="community-results">{servers?.map(server=><li key={server.id}>
      <div><strong>{server.name}{!!server.verified && <VerifiedCommunityIcon/>}</strong>
        {server.description && <p>{server.description}</p>}</div>
      <button className="secondary" disabled={!!busy} onClick={()=>void join(server)}>
        {busy === server.id ? "Đang mở…" : server.joined ? "Mở server" : "Tham gia"}</button>
    </li>)}</ul>
  </Dialog>;
}
