import { createContext } from "react";
import type { useChatAlerts } from "../../../hooks/chat/useChatAlerts";

export const ChatAlertsContext = createContext<ReturnType<typeof useChatAlerts> | null>(null);
