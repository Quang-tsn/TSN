import { useContext,useEffect,useState } from "react";
import type { Account } from "../../../types/Account";
import type { Channel } from "../../../types/Community";
import { useServerDetail } from "../../../hooks/community/useServerDetail";
import { ChannelSidebar } from "../channel-sidebar/ChannelSidebar";
import { ChatArea } from "../chat-area/ChatArea";
import { WelcomePanel } from "../chat-area/WelcomePanel";
import { ChannelModal } from "../modals/ChannelModal";
import { InviteModal } from "../modals/InviteModal";
import { MenuIcon } from "../../icons/MenuIcon";
import { ServerVisibilityDialog } from "../modals/ServerVisibilityDialog";
import { ChatAlertsContext } from "./ChatAlertsContext";
export function ServerView({ serverId, user, onLogout, onCreate, onJoin, onDiscover }: {
  serverId: string | null; user: Account; onLogout: () => void; onCreate: () => void; onJoin: () => void;
  onDiscover: () => void;
}) {
  const [version, setVersion] = useState(0), [room, setRoom] = useState<string | null>(null);
  const [mobile, setMobile] = useState(false);
  const [modal, setModal] = useState<"create" | "invite" | "visibility" | Channel | null>(null);
  const { detail, error } = useServerDetail(serverId, version);
  const channel = detail?.channels.find((c) => c.id === room) || detail?.channels[0];
  const setAlertRoom = useContext(ChatAlertsContext)?.setRoom;
  useEffect(()=>{
    setAlertRoom?.(channel?.id ?? null);
    return ()=>setAlertRoom?.(null);
  },[channel?.id,setAlertRoom]);
  return <div className={"server-view " + (mobile ? "navigation-open" : "")}>
    {mobile && <button className="drawer-backdrop" aria-label="Đóng danh sách kênh" onClick={() => setMobile(false)}/>}
    <ChannelSidebar detail={detail} roomId={channel?.id || null} user={user}
      onSelect={(id) => { setRoom(id); setMobile(false); }} onCreate={() => setModal("create")}
      onEdit={setModal} onInvite={() => setModal("invite")} onLogout={onLogout} onVisibility={()=>setModal("visibility")}/>
    {error ? <div className="main-state" role="alert">{error}
      <button className="secondary" onClick={() => setVersion((v) => v + 1)}>Thử lại</button></div>
      : serverId && !detail ? <div className="main-state" role="status">Đang tải server…</div>
      : channel ? <ChatArea key={channel.id} channel={channel} members={detail!.members}
        userId={user.id} onMenu={() => setMobile(true)}/> : <div className="home-area">
        <button className="icon-button mobile-menu home-menu" aria-label="Mở danh sách kênh"
          onClick={() => setMobile(true)}><MenuIcon/></button>
        <WelcomePanel onCreate={onCreate} onJoin={onJoin} onDiscover={onDiscover}/></div>}
    {modal === "invite" && serverId && <InviteModal serverId={serverId} onClose={() => setModal(null)}/>}
    {modal === "visibility" && detail && <ServerVisibilityDialog server={detail.server} onClose={()=>setModal(null)}
      onSaved={()=>{setModal(null);setVersion(v=>v+1);}}/>}
    {(modal === "create" || modal && typeof modal === "object") && serverId && <ChannelModal serverId={serverId}
      channel={typeof modal === "object" ? modal : undefined} onClose={() => setModal(null)}
      onDone={() => { setModal(null); setVersion((v) => v + 1); }}/>}
  </div>;
}
