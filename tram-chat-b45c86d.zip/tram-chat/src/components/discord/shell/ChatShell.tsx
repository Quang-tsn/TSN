import { useState } from "react";
import type { Account } from "../../../types/Account";
import { useWorkspace } from "../../../hooks/community/useWorkspace";
import { ServerRail } from "../server-rail/ServerRail";
import { ServerView } from "./ServerView";
import { ServerModal } from "../modals/ServerModal";
import { useExtra } from "../../../hooks/useExtra";
import { ExtraContext } from "../../extra/ExtraContext";
import { DiscoverServersDialog } from "../modals/DiscoverServersDialog";
import { useChatAlerts } from "../../../hooks/chat/useChatAlerts";
import { ChatAlertsContext } from "./ChatAlertsContext";
export function ChatShell({ user, onLogout }: { user: Account; onLogout: () => void }) {
  const workspace = useWorkspace();
  const alerts = useChatAlerts(user.id);
  const { extra } = useExtra();
  const [modal, setModal] = useState<"create" | "join" | "discover" | null>(null);
  async function openServer(id: string) {
    await workspace.reload(); workspace.setSelected(id); setModal(null);
  }
  return <ChatAlertsContext.Provider value={alerts}>
  <ExtraContext.Provider value={extra?.user?.id === user.id ? extra : null}><main className="discord-shell">
    <ServerRail servers={workspace.servers} selected={workspace.selected}
      onSelect={workspace.setSelected} onCreate={() => setModal("create")} onJoin={() => setModal("join")}
      onDiscover={()=>setModal("discover")}/>
    {workspace.loading ? <div className="main-state" role="status">Đang mở Trạm…</div>
      : workspace.error ? <div className="main-state" role="alert">{workspace.error}
        <button className="secondary" onClick={workspace.reload}>Thử lại</button>
        <button className="text-button" onClick={onLogout}>Về đăng nhập</button></div>
      : <ServerView key={workspace.selected || "home"} serverId={workspace.selected}
        user={user} onLogout={onLogout} onCreate={() => setModal("create")} onJoin={() => setModal("join")}
        onDiscover={()=>setModal("discover")}/>}
    {modal === "discover" && <DiscoverServersDialog onClose={()=>setModal(null)} onDone={openServer}/>}
    {(modal === "create" || modal === "join") && <ServerModal join={modal === "join"}
      onClose={() => setModal(null)} onDone={openServer}/>}
  </main></ExtraContext.Provider></ChatAlertsContext.Provider>;
}
