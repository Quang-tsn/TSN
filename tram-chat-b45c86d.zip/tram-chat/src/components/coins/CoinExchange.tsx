import { coinExchanges } from "../../shared/tamperCoins";
import type { SubmitCoins } from "../../types/Coins";
import { TierBadge } from "../extra/TierBadge";

export function CoinExchange({balance,submit,busy}: {balance:number|null;submit:SubmitCoins;busy:boolean}) {
  return <section className="extra-card coin-section">
    <h2>Đổi gói ExtraAccount</h2>
    <ul className="coin-exchange-grid">{coinExchanges.map(plan=><li key={plan.tier+plan.days}>
      <TierBadge tier={plan.tier}/><strong>{plan.days} ngày</strong>
      <button type="button" className="secondary" disabled={busy||balance===null||balance<plan.coins}
        onClick={()=>void submit("exchange",plan)}
        aria-label={`Đổi ${plan.tier}, ${plan.days} ngày, ${plan.coins} Coins`}>Đổi {plan.coins} Coins</button>
    </li>)}</ul>
  </section>;
}
