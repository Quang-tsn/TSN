import { useState } from "react";
import { api } from "../../services/community/api";
import type { SubmitCoins } from "../../types/Coins";
import { CoinCodeForm } from "./CoinCodeForm";

export function CoinDaily({submit,busy}: {submit:SubmitCoins;busy:boolean}) {
  const [daily,setDaily] = useState<{code:string;claimed:number}|null>(null);
  const [error,setError] = useState("");
  const [loading,setLoading] = useState(false);
  async function load() {
    setLoading(true);setError("");
    try {setDaily(await api("coins/daily-code",{}));}
    catch (cause) {setError((cause as Error).message);}
    finally {setLoading(false);}
  }
  return <section className="extra-card coin-section">
    <h2>Mã hằng ngày</h2><p>Mỗi ngày nhận ngẫu nhiên 1–5 Coins. Mã đổi ngày lúc 00:00 giờ Việt Nam.</p>
    <button type="button" className="secondary" disabled={loading||busy} onClick={load}>
      {loading ? "Đang lấy mã…" : "Lấy mã hôm nay"}</button>
    {daily && <p>{daily.claimed ? "Bạn đã nhận Coins hôm nay." : <>Mã của bạn <code>{daily.code}</code></>}</p>}
    <CoinCodeForm label="Nhập mã hằng ngày" button="Nhận Coins" busy={busy||loading} submit={async code=>{
      if (await submit("daily",{code})) {setDaily(null);return true;}return false;
    }}/>
    {error && <p role="alert" className="error">{error}</p>}
  </section>;
}
