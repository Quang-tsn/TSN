import { useCoinGiftNotices } from "../../hooks/useCoinGiftNotices";
import { TamperCoinIcon } from "../icons/TamperCoinIcon";

export function CoinGiftNotices({userId}: {userId:string}) {
  const {notices,dismiss} = useCoinGiftNotices(userId);
  return <div className="coin-received-notices" aria-live="polite">
    {!!notices.length && <section className="coin-gift-notice" aria-label="Quà tặng Tamper Coins">
      <TamperCoinIcon/>
      <div><strong>Bạn vừa nhận được quà</strong>
        <ul>{notices.map(item=><li key={item.id}>
          {item.username ? "@"+item.username : "Một thành viên"} đã gửi tặng bạn{" "}
          <strong>{item.amount.toLocaleString("vi-VN")} Coins</strong>.
        </li>)}</ul>
      </div>
      <button type="button" className="secondary" onClick={dismiss}>Đã xem</button>
    </section>}
  </div>;
}
