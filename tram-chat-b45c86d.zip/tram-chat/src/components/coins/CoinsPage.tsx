import { useState } from "react";
import { useSession } from "../../hooks/auth/useSession";
import { useCoinBalance } from "../../hooks/useCoinBalance";
import { useCoinAction } from "../../hooks/useCoinAction";
import { BrandLogo } from "../icons/BrandLogo";
import { TamperCoinIcon } from "../icons/TamperCoinIcon";
import { CoinDaily } from "./CoinDaily";
import { CoinExchange } from "./CoinExchange";
import { CoinGift } from "./CoinGift";
import { CoinHistory } from "./CoinHistory";
import { CoinStore } from "./CoinStore";
import { CoinGiftNotices } from "./CoinGiftNotices";

export function CoinsPage() {
  const session = useSession();
  return <main className="landing extra-page plans-page">
    <header className="landing-width extra-nav">
      <a className="landing-brand" href="/"><BrandLogo/>Trạm</a>
      <nav aria-label="Điều hướng Tamper Coins">
        <a className="landing-button" href="/extraaccount">ExtraAccount</a>
        <a className="landing-button" href="/login">Về chat</a>
      </nav>
    </header>
    <div className="landing-width coin-page">
      {session.loading ? <p role="status">Đang mở Tamper Coins…</p> : session.user ?
        <CoinWallet key={session.user.id} userId={session.user.id}/> : <section className="extra-card">
          <h1>Tamper Coins</h1>{session.error && <p role="alert">{session.error}</p>}
          <a className="landing-button" href="/login?next=coins">Đăng nhập</a>
        </section>}
    </div>
  </main>;
}

function CoinWallet({userId}: {userId:string}) {
  const {balance,setBalance,error} = useCoinBalance();
  const [revision,setRevision] = useState(0);
  const action = useCoinAction((result,kind)=>{
    setBalance(result.balance);
    if (kind==="gift") setRevision(value=>value+1);
  });
  const props = {busy:!!action.pending,submit:action.submit};
  return <>
    <div className="coin-wallet-title"><div><h1>Tamper Coins</h1><p>Dùng Coins để đổi gói ExtraAccount hoặc tặng bạn bè.</p></div>
      <div className="coin-wallet-balance"><TamperCoinIcon/><span>Số dư<strong>{balance?.toLocaleString("vi-VN") ?? "…"} Coins</strong></span></div>
    </div>
    <div className="coin-action-status" aria-live="polite">{action.notice || undefined}
      {action.giftThanks && <div className="coin-gift-notice"><TamperCoinIcon/>
        <div><strong>Món quà đã được gửi</strong><p>{action.giftThanks}</p></div>
      </div>}
      {(action.error || error) && <p className="error" role="alert">{action.error || error}</p>}</div>
    <CoinGiftNotices userId={userId}/>
    <div className="coin-layout">
      <CoinExchange {...props} balance={balance}/>
      <CoinDaily {...props}/>
      <CoinGift {...props} balance={balance}/>
      <CoinHistory revision={revision}/>
    </div>
    <CoinStore {...props}/>
  </>;
}
