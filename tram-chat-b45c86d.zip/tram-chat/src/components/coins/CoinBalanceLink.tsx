import { TamperCoinIcon } from "../icons/TamperCoinIcon";
import { useCoinBalance } from "../../hooks/useCoinBalance";

export function CoinBalanceLink() {
  const {balance} = useCoinBalance();
  return <a className="coin-balance-link" href="/coins" aria-label={balance===null ?
    "Tamper Coins" : `Tamper Coins, số dư ${balance}`}>
    <TamperCoinIcon/><span>Tamper Coins</span><strong>{balance?.toLocaleString("vi-VN") ?? "…"}</strong>
  </a>;
}
