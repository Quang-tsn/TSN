import { useState } from "react";
import type { SubmitCoins } from "../../types/Coins";

export function CoinGift({submit,busy,balance}: {submit:SubmitCoins;busy:boolean;balance:number|null}) {
  const [username,setUsername] = useState("");
  const [amount,setAmount] = useState("");
  const valid = /^[a-z0-9_.-]{3,32}$/i.test(username.trim().replace(/^@/,"")) &&
    /^\d+$/.test(amount) && Number(amount)>=1 && Number(amount)<=(balance??0);
  return <section className="extra-card coin-section">
    <h2>Tặng Coins</h2>
    <form className="coin-form" onSubmit={async event=>{
      event.preventDefault();
      if (valid && await submit("gift",{username,amount:Number(amount)})) {setUsername("");setAmount("");}
    }}>
      <label>Tên đăng nhập người nhận<input value={username} onChange={e=>setUsername(e.target.value)}
        placeholder="@ten-dang-nhap" required maxLength={33}/></label>
      <label>Số Coins<input value={amount} onChange={e=>setAmount(e.target.value)} type="number"
        min={1} max={balance ?? undefined} step={1} required/></label>
      <button className="primary" disabled={busy||!valid}>Tặng</button>
    </form>
  </section>;
}
