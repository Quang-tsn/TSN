import { useEffect,useState } from "react";
import type { CoinHistoryPage } from "../../types/Coins";
import { api } from "../../services/community/api";

export function CoinHistory({revision}: {revision:number}) {
  const [q,setQuery] = useState("");
  const [before,setBefore] = useState<string|null>(null);
  const [history,setHistory] = useState<CoinHistoryPage|null>(null);
  const [error,setError] = useState("");
  useEffect(()=>{
    const controller = new AbortController();
    const input = new URLSearchParams({q});
    if (before) input.set("before",before);
    const timer = window.setTimeout(()=>{
      api<CoinHistoryPage>("coins/history?"+input,undefined,"GET",controller.signal)
        .then(result=>{if (!controller.signal.aborted) {setHistory(result);setError("");}})
        .catch(cause=>{if (!controller.signal.aborted) setError(cause.message);});
    },q ? 180 : 0);
    return ()=>{controller.abort();window.clearTimeout(timer);};
  },[q,before,revision]);
  return <section className="extra-card coin-section">
    <h2>Lịch sử tặng và nhận</h2>
    <label>Tìm người gửi hoặc người nhận<input type="search" value={q} maxLength={80}
      onChange={e=>{setQuery(e.target.value);setBefore(null);}} placeholder="Tên đăng nhập hoặc tên hiển thị"/></label>
    {error && <p role="alert" className="error">{error}</p>}
    {history && !history.items.length && <p>{q ? "Không tìm thấy giao dịch." : "Chưa có lượt tặng hoặc nhận."}</p>}
    <ul className="coin-history">{history?.items.map(item=><li key={item.id}>
      <div><strong>{item.sent ? "Tặng" : "Nhận"} {item.username ? "@"+item.username : "Tài khoản đã xóa"}</strong>
        <small>{new Date(item.created_at).toLocaleString("vi-VN")}</small></div>
      <strong className={item.sent ? "coin-out" : "coin-in"}>{item.sent ? "−" : "+"}{item.amount} Coins</strong>
    </li>)}</ul>
    {before && <button type="button" className="secondary" onClick={()=>setBefore(null)}>Trang đầu</button>}
    {history?.next && <button type="button" className="secondary" onClick={()=>setBefore(history.next)}>Trang sau</button>}
  </section>;
}
