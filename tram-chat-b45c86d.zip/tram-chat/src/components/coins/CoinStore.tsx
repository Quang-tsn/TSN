import { coinPacks } from "../../shared/tamperCoins";
import type { SubmitCoins } from "../../types/Coins";
import { CoinCodeForm } from "./CoinCodeForm";
import { UpcomingPayments } from "../extra/UpcomingPayments";

export function CoinStore({submit,busy}: {submit:SubmitCoins;busy:boolean}) {
  return <section className="extra-card coin-section">
    <h2>Gói nạp Coins</h2><p>Nạp bằng mã do quản trị viên cấp sau khi xác nhận giao dịch.</p>
    <ul className="coin-pack-grid">{coinPacks.map(pack=><li key={pack.coins}>
      <strong>{pack.coins.toLocaleString("vi-VN")} Coins</strong><span>{pack.price} US$</span>
    </li>)}</ul>
    <CoinCodeForm label="Mã nạp Coins" button="Nạp Coins" busy={busy}
      submit={async code=>!!await submit("redeem",{code})}/>
    <UpcomingPayments/>
  </section>;
}
