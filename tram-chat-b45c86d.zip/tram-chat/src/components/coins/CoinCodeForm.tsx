import { useState } from "react";
import { isExtraCode } from "../../shared/isExtraCode";
import { normalizeExtraCode } from "../../shared/normalizeExtraCode";

export function CoinCodeForm({label,button,busy,submit}: {
  label:string;button:string;busy:boolean;submit:(code:string)=>Promise<boolean>;
}) {
  const [code,setCode] = useState("");
  const normalized = normalizeExtraCode(code);
  return <form className="coin-form" onSubmit={async event=>{
    event.preventDefault();
    if (isExtraCode(normalized) && await submit(normalized)) setCode("");
  }}>
    <label>{label}<input value={code} onChange={e=>setCode(e.target.value)} maxLength={24}
      placeholder="12 ký tự chữ và số" autoCapitalize="characters" autoComplete="off" spellCheck={false}/></label>
    <button className="primary" disabled={busy||!isExtraCode(normalized)}>{button}</button>
  </form>;
}
