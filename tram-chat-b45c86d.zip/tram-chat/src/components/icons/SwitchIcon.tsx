export function SwitchIcon() {
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75"
    strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    <path d="M3 8h17m-4-4 4 4-4 4m5 4H4m4-4-4 4 4 4"/>
  </svg>;
}
