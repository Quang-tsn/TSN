export function CameraIcon() {
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75"
    strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    <path d="M3 7h5l1.6-2h4.8L16 7h5v12H3z"/>
    <path d="M15 13a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z"/>
  </svg>;
}
