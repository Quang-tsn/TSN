export function LinkIcon() {
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75"
    strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    <path d="M10 13.5l4-4m-6.7 6.7L6 17.5a3.5 3.5 0 0 1-5-5l4-4a3.5 3.5 0 0 1 5 0m3.5 7.5a3.5 3.5 0 0 0 5 0l4-4a3.5 3.5 0 0 0-5-5l-1.3 1.3" transform="translate(.5 0) scale(.96)"/>
  </svg>;
}
