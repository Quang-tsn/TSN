export function DiscoverIcon() {
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    <circle cx="11" cy="11" r="7"/><path d="m16 16 4 4M8 14l1.5-4.5L14 8l-1.5 4.5L8 14Z"/>
  </svg>;
}
