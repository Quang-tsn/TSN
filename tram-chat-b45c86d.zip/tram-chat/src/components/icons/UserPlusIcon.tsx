export function UserPlusIcon() {
  return <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
    <path d="M14 20H3v-2a5 5 0 0 1 10 0M8 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8m10-5v8m-4-4h8" stroke="currentColor" strokeWidth="1.75"
      strokeLinecap="round" strokeLinejoin="round"/>
  </svg>;
}
