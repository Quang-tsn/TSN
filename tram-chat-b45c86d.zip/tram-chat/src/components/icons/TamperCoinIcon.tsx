export function TamperCoinIcon() {
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75"
    strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    <path d="M8 2.5h8l5.5 5.5v8L16 21.5H8L2.5 16V8L8 2.5Z"/>
    <path d="M7.5 8.5h9m-4.5 0v7m-3 0h6M6 12h.01M18 12h.01"/>
  </svg>;
}
