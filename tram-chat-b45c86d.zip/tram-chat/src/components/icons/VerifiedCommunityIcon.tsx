export function VerifiedCommunityIcon() {
  return <svg viewBox="0 0 24 24" className="community-verified" role="img" aria-label="Server đã xác minh">
    <path fill="#53a9f6" d="M12 1.8l3 2.3 3.8.4.9 3.7 2.4 2.8-1.7 3.4-.2 3.8-3.6 1.2-2.9 2.4-3.4-1.4-3.8-.1-1.5-3.5-2.6-2.7 1.1-3.6-.2-3.7 3.5-1.7z"/>
    <path d="m8.2 12.3 2.3 2.3 5.3-5.2" fill="none" stroke="#102339" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>;
}
