export function BrandLogo() {
  return <svg viewBox="0 0 32 32" fill="none" aria-hidden="true">
    <path d="M4 12.5V10a3 3 0 0 1 1.5-2.6l9-5.15a3 3 0 0 1 3 0l9 5.15A3 3 0 0 1 28 10v10a3 3 0 0 1-1.5 2.6l-5.2 3"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
    <path d="M4 17.3V20a3 3 0 0 0 1.5 2.6l9 5.15a3 3 0 0 0 3 0l.2-.1"
      stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
    <path d="M9 12h14M16 12v7.5m-4.1-7.5-3.1 4m11.3-4 3.1 4" stroke="currentColor"
      strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round"/>
    <circle cx="16" cy="22" r="1.65" fill="currentColor"/>
  </svg>;
}
