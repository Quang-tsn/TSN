export function ProfileIcon() {
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75"
    strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    <path d="M20 20H4v-2a5 5 0 0 1 5-5h6a5 5 0 0 1 5 5z"/>
    <path d="M16 7a4 4 0 1 1-8 0 4 4 0 0 1 8 0Z"/>
  </svg>;
}
