export function JoinServerIcon() {
  return <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
    <path d="M14 4h5v16h-5M3 12h12m-4-4 4 4-4 4" stroke="currentColor" strokeWidth="1.75"
      strokeLinecap="round" strokeLinejoin="round"/>
  </svg>;
}
