export function SendIcon() {
  return <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
    <path d="m3 3 18 9-18 9 4-9-4-9Zm4 9h14" stroke="currentColor" strokeWidth="1.75"
      strokeLinecap="round" strokeLinejoin="round"/>
  </svg>;
}
