export function EditIcon() {
  return <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
    <path d="m4 16-1 5 5-1L20 8l-4-4L4 16Zm9-9 4 4" stroke="currentColor" strokeWidth="1.75"
      strokeLinecap="round" strokeLinejoin="round"/>
  </svg>;
}
