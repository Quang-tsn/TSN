export function ReplyIcon() {
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75"
    strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    <path d="m9 6-6 6 6 6m-6-6h11a6 6 0 0 1 6 6"/>
  </svg>;
}
