export function HashIcon() {
  return <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
    <path d="m9 4-2 16m10-16-2 16M4 9h16M3 15h16"
      stroke="currentColor" strokeWidth="1.75" strokeLinecap="round"/>
  </svg>;
}
