export function BellIcon({ muted=false }: { muted?: boolean }) {
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75"
    strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    <path d="M10 20a2 2 0 0 0 4 0"/>
    {muted ? <><path d="M4 4l16 16M6 13c0 2-2 3-2 4h12M10 4a6 6 0 0 1 8 6v2"/></>
      : <path d="M18 9a6 6 0 0 0-12 0c0 6-2 6-2 8h16c0-2-2-2-2-8z"/>}
  </svg>;
}
