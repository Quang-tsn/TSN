export function ShieldIcon() {
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75"
    strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    <path d="M12 3 4 6v5c0 5.2 3.5 8.7 8 10 4.5-1.3 8-4.8 8-10V6z"/>
    <path d="m9 12 2 2 4-4"/>
  </svg>;
}
