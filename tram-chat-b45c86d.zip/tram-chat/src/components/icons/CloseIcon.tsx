export function CloseIcon() {
  return <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
    <path d="m6 6 12 12M18 6 6 18" stroke="currentColor" strokeWidth="1.75"
      strokeLinecap="round" strokeLinejoin="round"/>
  </svg>;
}
