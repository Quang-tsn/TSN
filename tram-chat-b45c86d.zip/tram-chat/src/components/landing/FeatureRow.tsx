import type { ReactNode } from "react";

type Props = {
  title: string;
  description: string;
  details: readonly string[];
  tone: "channels" | "images" | "replies" | "invite";
  children: ReactNode;
};

export function FeatureRow({ title, description, details, tone, children }: Props) {
  return <article className="landing-feature-row" data-reveal>
    <figure className={"feature-figure feature-figure-" + tone}>{children}</figure>
    <div className="feature-copy">
      <h3>{title}</h3>
      <p>{description}</p>
      <ul>{details.map((detail) => <li key={detail}>{detail}</li>)}</ul>
    </div>
  </article>;
}
