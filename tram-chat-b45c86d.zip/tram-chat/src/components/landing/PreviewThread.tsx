import { HashIcon } from "../icons/HashIcon";
import { ImageIcon } from "../icons/ImageIcon";
import { SendIcon } from "../icons/SendIcon";
export function PreviewThread() {
  return <div className="landing-preview-thread">
    <div className="landing-thread-title"><HashIcon/><strong>general</strong></div>
    <div className="landing-thread-messages">
      <div className="landing-sample-message"><span className="landing-avatar">M</span>
        <div><strong>Minh</strong><p>Tối nay tập trung lúc 8 giờ nhé?</p></div>
      </div>
      <div className="landing-sample-message"><span className="landing-avatar">L</span>
        <div><small>Trả lời Minh</small><strong>Linh</strong><p>Ok, mình vào trước một chút.</p></div>
      </div>
    </div>
    <div className="landing-faux-input"><ImageIcon/><span>Nhắn vào general</span><SendIcon/></div>
  </div>;
}
