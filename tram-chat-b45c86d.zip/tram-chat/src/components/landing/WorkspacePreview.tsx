import { BrandLogo } from "../icons/BrandLogo";
import { HashIcon } from "../icons/HashIcon";
import { PreviewThread } from "./PreviewThread";
export function WorkspacePreview() {
  return <figure className="landing-preview" aria-label="Bản minh họa cửa sổ trò chuyện Trạm">
    <div className="landing-preview-top">
      <span className="landing-brand"><BrandLogo/>Trạm</span>
      <span>Hội chơi tối nay</span>
      <span className="landing-preview-label">Giao diện minh họa</span>
    </div>
    <div className="landing-preview-grid">
      <div className="landing-preview-channels">
        <strong>Kênh trò chuyện</strong>
        <span className="chosen"><HashIcon/> general</span>
        <span><HashIcon/> giao-luu</span>
        <span><HashIcon/> thong-bao</span>
      </div>
      <PreviewThread/>
    </div>
  </figure>;
}
