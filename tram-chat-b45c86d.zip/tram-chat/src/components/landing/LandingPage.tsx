import { LandingNav } from "./LandingNav";
import { LandingHero } from "./LandingHero";
import { LandingFeatures } from "./LandingFeatures";
import { LandingFooter } from "./LandingFooter";
import { LandingGuide } from "./LandingGuide";
import { LandingFaq } from "./LandingFaq";
import { LandingExtra } from "./LandingExtra";
import { IntroSection } from "./IntroSection";
export function LandingPage() {
  return <main className="landing">
    <LandingNav/>
    <LandingHero/>
    <IntroSection/>
    <LandingFeatures/>
    <LandingExtra/>
    <LandingGuide/>
    <LandingFaq/>
    <LandingFooter/>
  </main>;
}
