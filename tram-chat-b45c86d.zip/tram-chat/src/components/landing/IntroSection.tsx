import { BrandLogo } from "../icons/BrandLogo";
import { IntroFilm } from "./IntroFilm";
import { useIntroPlayback } from "../../hooks/useIntroPlayback";

export function IntroSection() {
  const intro = useIntroPlayback();
  const active = intro.mode === "playing" || intro.mode === "summary";
  return <section id="intro" className="landing-width intro-section" aria-labelledby="intro-title">
    <h2 id="intro-title">Intro Trạm</h2>
    <div className="intro-film" ref={intro.frame} onKeyDown={event => {
      if (event.key === "Escape" && active) intro.finish();
    }}>
      {intro.mode === "playing" ? <IntroFilm paused={intro.paused} onFinish={intro.finish}/>
        : intro.mode === "summary" ? <p className="intro-summary">Mở server, chọn kênh và nhắn cho hội trên Trạm.</p>
          : <div className="intro-poster" aria-hidden="true"><BrandLogo/>Trạm</div>}
      <button type="button" className="intro-skip" onClick={active ? intro.finish : intro.start}>
        {intro.mode === "playing" ? "Dừng intro" : intro.mode === "summary" ? "Đóng intro"
          : intro.mode === "finished" ? "Phát lại intro" : "Phát intro"}
      </button>
    </div>
  </section>;
}
