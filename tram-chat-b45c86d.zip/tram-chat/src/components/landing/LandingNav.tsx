import { BrandLogo } from "../icons/BrandLogo";
export function LandingNav() {
  return <header className="landing-nav">
    <div className="landing-width landing-nav-inner">
      <a href="/" className="landing-brand" aria-label="Trang chủ Trạm"><BrandLogo/>Trạm</a>
      <nav aria-label="Giới thiệu"><a href="#tinh-nang">Tính năng</a>
        <a href="#bat-dau">Bắt đầu</a><a href="#cau-hoi">Hỏi đáp</a>
        <a href="/extraaccount">ExtraAccount</a></nav>
      <a className="landing-nav-login" href="/login">Đăng nhập</a>
    </div>
  </header>;
}
