import { BrandLogo } from "../icons/BrandLogo";
import { ChannelsArtwork } from "./artwork/ChannelsArtwork";
import { ReplyArtwork } from "./artwork/ReplyArtwork";
import { ImageArtwork } from "./artwork/ImageArtwork";
export function IntroFilm({ paused,onFinish }: { paused: boolean; onFinish: () => void }) {
  return <div className={"intro-film-stage" + (paused ? " is-paused" : "")} aria-hidden="true">
      <div className="intro-beat intro-beat-one">Mở server</div>
      <div className="intro-beat intro-beat-two">Chọn kênh</div>
      <div className="intro-beat intro-film-windows">
        <div><ReplyArtwork/></div><div><ImageArtwork/></div><div><ChannelsArtwork/></div>
      </div>
      <div className="intro-beat intro-beat-four">Nhắn cho hội</div>
      <div className="intro-beat intro-film-brand" onAnimationEnd={onFinish}><BrandLogo/><span>Trạm</span></div>
  </div>;
}
