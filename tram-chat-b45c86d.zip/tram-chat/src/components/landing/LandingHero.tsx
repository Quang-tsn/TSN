import { SignalContours } from "./SignalContours";
import { WorkspacePreview } from "./WorkspacePreview";
export function LandingHero() {
  return <section className="landing-hero">
    <SignalContours/>
    <div className="landing-width landing-hero-inner">
      <div className="landing-hero-copy">
        <h1>Chat với hội bạn</h1>
        <p>Tạo server cho cả nhóm, mở kênh theo chủ đề hoặc nhắn riêng cho bạn bè.</p>
        <div className="landing-actions">
          <a className="landing-button landing-button-primary" href="/login">Vào Trạm</a>
          <a className="landing-button" href="#tinh-nang">Xem tính năng</a>
          <a className="landing-button" href="#intro">Xem intro</a>
        </div>
      </div>
      <WorkspacePreview/>
    </div>
  </section>;
}
