import { useExtra } from "../../hooks/useExtra";
import { UpgradePromo } from "../extra/UpgradePromo";
export function LandingExtra() {
  const { extra } = useExtra();
  if (!extra || extra.status?.tier === "Avip" || extra.status?.tier === "Svip") return null;
  return <div className="landing-width landing-extra"><UpgradePromo/></div>;
}
