import { BrandLogo } from "../icons/BrandLogo";
export function LandingFooter() {
  return <footer className="landing-width landing-footer">
    <div className="landing-footer-cta">
      <h2>Mở server cho hội bạn</h2>
      <a href="/register" className="landing-button landing-button-primary">Tạo tài khoản</a>
    </div>
    <div className="landing-footer-nav">
      <a href="/" className="landing-brand" aria-label="Trang chủ Trạm"><BrandLogo/>Trạm</a>
      <a href="/login">Đăng nhập</a>
    </div>
  </footer>;
}
