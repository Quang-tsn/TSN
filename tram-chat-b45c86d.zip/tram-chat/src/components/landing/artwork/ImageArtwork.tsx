import { PreviewWindow } from "./PreviewWindow";

export function ImageArtwork() {
  return <PreviewWindow title="# giao-luu" label="Giao diện soạn tin Trạm có bản xem trước ảnh và nút gửi">
    <text x="43" y="102" className="art-text" fontSize="16" fontWeight="700">Ảnh đính kèm</text>
    <rect x="42" y="120" width="476" height="166" rx="10" fill="#302d27" stroke="#776044"/>
    <rect x="59" y="136" width="137" height="93" rx="6" fill="#c69a73"/>
    <circle cx="153" cy="159" r="11" fill="#f0d2a4"/>
    <path d="m59 215 42-54 32 40 23-24 40 44v8H59z" fill="#655e49"/>
    <path d="m59 222 56-28 29 18 52-9v26H59z" fill="#515849"/>
    <text x="215" y="165" className="art-text" fontSize="15" fontWeight="700">Ảnh xem trước</text>
    <text x="215" y="190" className="art-muted" fontSize="13">PNG · Đã sẵn sàng gửi</text>
    <path d="m480 145 15 15m0-15-15 15" fill="none" stroke="#bdad98" strokeWidth="2" strokeLinecap="round"/>
    <path d="M42 242h476" stroke="#534a3d"/>
    <text x="59" y="270" className="art-muted" fontSize="14">Ảnh từ buổi đi chơi hôm qua.</text>
    <rect x="446" y="250" width="58" height="28" rx="5" fill="#eac493"/>
    <text x="475" y="269" textAnchor="middle" fill="#251d14" fontSize="13" fontWeight="700">Gửi</text>
  </PreviewWindow>;
}
