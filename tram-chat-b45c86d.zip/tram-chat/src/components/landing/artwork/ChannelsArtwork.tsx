import { PreviewWindow } from "./PreviewWindow";

export function ChannelsArtwork() {
  return <PreviewWindow title="Hội chơi tối nay" label="Giao diện Trạm với danh sách kênh và cuộc trò chuyện ở general">
    <path d="M22 69h166v248H34a12 12 0 0 1-12-12z" fill="#2d2923"/>
    <path d="M188 68v250M188 110h351" stroke="#453e34"/>
    <text x="39" y="94" className="art-muted" fontSize="12" letterSpacing="1">KÊNH TRÒ CHUYỆN</text>
    <rect x="30" y="108" width="149" height="34" rx="5" fill="#433729"/>
    <path d="M31 112v26" stroke="#eac493" strokeWidth="2"/>
    <text x="43" y="130" className="art-gold" fontSize="15">#  general</text>
    <text x="43" y="169" className="art-muted" fontSize="14">#  giao-luu</text>
    <text x="43" y="203" className="art-muted" fontSize="14">#  thong-bao</text>
    <text x="210" y="95" className="art-text" fontSize="16" fontWeight="700"># general</text>
    <rect x="210" y="135" width="32" height="32" rx="7" fill="#584532"/>
    <text x="219" y="156" className="art-gold" fontSize="14">M</text>
    <text x="255" y="148" className="art-text" fontSize="15" fontWeight="700">Minh</text>
    <text x="255" y="171" className="art-muted" fontSize="14">Tối nay tập trung lúc 8 nhé?</text>
    <rect x="210" y="203" width="32" height="32" rx="7" fill="#3b4a40"/>
    <text x="221" y="224" fill="#c4dcbe" fontSize="14">L</text>
    <text x="255" y="216" className="art-text" fontSize="15" fontWeight="700">Linh</text>
    <text x="255" y="239" className="art-muted" fontSize="14">Ok, tới giờ ping mình nha.</text>
    <rect x="208" y="267" width="311" height="34" rx="6" fill="#302d27" stroke="#534a3d"/>
    <text x="223" y="289" className="art-muted" fontSize="13">Nhắn vào general</text>
  </PreviewWindow>;
}
