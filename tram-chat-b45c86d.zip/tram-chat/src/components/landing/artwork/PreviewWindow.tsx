import type { ReactNode } from "react";

export function PreviewWindow({ label, title, children }: {
  label: string; title: string; children: ReactNode;
}) {
  return <svg xmlns="http://www.w3.org/2000/svg" className="feature-art"
    viewBox="0 0 560 342" role="img" aria-label={label}>
    <rect x="21" y="24" width="518" height="294" rx="12" fill="#242320" stroke="#534a3d"/>
    <path d="M21 68h518" stroke="#453e34"/>
    <rect x="37" y="37" width="24" height="19" rx="5" fill="#4c3d2b"/>
    <path d="M43 42h12v7h-7l-4 3v-3h-1z" stroke="#eac493" fill="none" strokeLinejoin="round"/>
    <text x="73" y="51" fill="#f3eadb" fontSize="15" fontWeight="700">Trạm</text>
    <text x="522" y="51" textAnchor="end" fill="#c3b7a5" fontSize="13">{title}</text>
    {children}
  </svg>;
}
