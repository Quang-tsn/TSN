import { PreviewWindow } from "./PreviewWindow";

export function InviteArtwork() {
  return <PreviewWindow title="Hội chơi tối nay" label="Hộp thoại mời bạn trong Trạm có mã mời và nút sao chép">
    <rect x="22" y="69" width="516" height="248" rx="9" fill="#1c1b18"/>
    <rect x="88" y="93" width="384" height="193" rx="10" fill="#302b24" stroke="#695743"/>
    <text x="110" y="125" className="art-text" fontSize="19" fontWeight="700">Mời bạn vào server</text>
    <path d="m437 111 14 14m0-14-14 14" fill="none" stroke="#bdad98" strokeWidth="2" strokeLinecap="round"/>
    <text x="110" y="151" className="art-muted" fontSize="13">Mã dùng trong 7 ngày.</text>
    <text x="110" y="185" className="art-text" fontSize="13" fontWeight="600">Mã mời</text>
    <rect x="110" y="195" width="340" height="32" rx="5" fill="#22201c" stroke="#554838"/>
    <text x="124" y="216" className="art-gold" fontSize="12" fontFamily="monospace">d89c •••• •••• •••• •••• 571a</text>
    <rect x="110" y="240" width="340" height="30" rx="6" fill="#eac493"/>
    <text x="280" y="260" textAnchor="middle" fill="#251d14" fontSize="13" fontWeight="700">Sao chép mã mời</text>
  </PreviewWindow>;
}
