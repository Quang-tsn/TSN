import { PreviewWindow } from "./PreviewWindow";

export function ReplyArtwork() {
  return <PreviewWindow title="# general" label="Giao diện Trạm có một tin nhắn trả lời kèm đoạn trích từ tin gốc">
    <rect x="42" y="97" width="36" height="36" rx="8" fill="#584532"/>
    <text x="53" y="120" className="art-gold" fontSize="15">M</text>
    <text x="95" y="113" className="art-text" fontSize="15" fontWeight="700">Minh</text>
    <text x="139" y="113" className="art-muted" fontSize="11">19:56</text>
    <text x="95" y="138" className="art-muted" fontSize="15">Mọi người vào kênh nào vậy?</text>
    <path d="M43 160h474" stroke="#453e34"/>
    <rect x="42" y="181" width="36" height="36" rx="8" fill="#3c4940"/>
    <text x="56" y="204" fill="#c4dcbe" fontSize="15">L</text>
    <rect x="95" y="181" width="328" height="58" rx="5" fill="#322e27"/>
    <path d="M96 185v50" stroke="#d6a773" strokeWidth="2"/>
    <text x="111" y="202" className="art-gold" fontSize="13" fontWeight="700">Minh</text>
    <text x="111" y="222" className="art-muted" fontSize="13">Mọi người vào kênh nào vậy?</text>
    <text x="95" y="263" className="art-text" fontSize="15" fontWeight="700">Linh</text>
    <text x="95" y="287" className="art-muted" fontSize="15">Vào #giao-luu nha, mình đang đợi.</text>
  </PreviewWindow>;
}
