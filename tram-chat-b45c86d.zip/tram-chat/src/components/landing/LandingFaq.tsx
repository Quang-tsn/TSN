import { useRevealOnScroll } from "../../hooks/useRevealOnScroll";

export function LandingFaq() {
  const section = useRevealOnScroll();
  return <section id="cau-hoi" className="landing-width landing-faq" ref={section}>
    <h2 data-reveal>Câu hỏi thường gặp</h2>
    <div data-reveal>
      <details><summary>Tôi tham gia server bằng cách nào?</summary>
        <p>Đăng nhập, chọn Nhập mã mời rồi dán mã bạn bè gửi. Mã dùng được trong 7 ngày.</p>
      </details>
      <details><summary>Tôi có thể dán loại ảnh nào?</summary>
        <p>Mỗi tin hỗ trợ một ảnh PNG hoặc JPEG tối đa 4 MB. Bạn có thể gửi ảnh riêng hoặc kèm lời nhắn.</p>
      </details>
      <details><summary>Ai đọc được tin nhắn trong kênh?</summary>
        <p>Thành viên của server có thể đọc các kênh chữ trong server đó.</p>
      </details>
      <details><summary>Tôi nhập mã Avip hoặc Svip ở đâu?</summary>
        <p>Mở trang ExtraAccount và chọn Nhập mã ở gói tương ứng.</p>
      </details>
    </div>
  </section>;
}
