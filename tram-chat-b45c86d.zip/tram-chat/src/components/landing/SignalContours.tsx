export function SignalContours() {
  return <svg className="landing-contours" viewBox="0 0 1440 630"
    preserveAspectRatio="xMidYMid slice" aria-hidden="true" fill="none">
    <g stroke="currentColor" strokeWidth=".8">
      {Array.from({ length: 27 }, (_, index) => {
        const y = 70 + index * 16;
        return <path key={index} opacity={0.12 + (index % 7) * 0.035}
          d={`M-150 ${y + 110} C 40 ${y + 132}, 140 ${y - 120}, 405 ${y - 24}
            S 700 ${y + 270}, 940 ${y + 136} S 1212 ${y - 56}, 1580 ${y + 96}`}/>;
      })}
    </g>
  </svg>;
}
