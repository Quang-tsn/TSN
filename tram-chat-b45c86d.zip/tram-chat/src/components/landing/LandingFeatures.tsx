import { useRevealOnScroll } from "../../hooks/useRevealOnScroll";
import { FeatureRow } from "./FeatureRow";
import { ChannelsArtwork } from "./artwork/ChannelsArtwork";
import { ImageArtwork } from "./artwork/ImageArtwork";
import { ReplyArtwork } from "./artwork/ReplyArtwork";
import { InviteArtwork } from "./artwork/InviteArtwork";

export function LandingFeatures() {
  const section = useRevealOnScroll();
  return <section id="tinh-nang" className="landing-width landing-features" ref={section}>
    <h2 className="landing-section-title" data-reveal>Chat nhóm trên Trạm</h2>
    <div className="landing-feature-rows">
      <FeatureRow tone="channels" title="Chia kênh theo chủ đề"
        description="Lên lịch chơi ở #general, tám chuyện ở #giao-luu. Mỗi kênh có lịch sử chat riêng."
        details={["Tạo kênh theo chủ đề", "Xem lại lịch sử"]}><ChannelsArtwork/></FeatureRow>
      <FeatureRow tone="images" title="Dán ảnh vào ô chat"
        description="Vừa chụp màn hình? Dán thẳng vào ô chat, xem lại rồi bấm Gửi."
        details={["PNG và JPEG", "Xem trước khi gửi"]}><ImageArtwork/></FeatureRow>
      <FeatureRow tone="replies" title="Trả lời từng tin nhắn"
        description="Bấm Trả lời trên một tin. Người đọc sẽ thấy đoạn trích ngay trên câu trả lời của bạn."
        details={["Trích tin gốc", "Trả lời cả tin ảnh"]}><ReplyArtwork/></FeatureRow>
      <FeatureRow tone="invite" title="Mời bạn vào server"
        description="Gửi mã mời cho cả hội. Sau khi đăng nhập, bạn bè chỉ cần dán mã để vào server."
        details={["Sao chép mã mời", "Mã dùng trong 7 ngày"]}><InviteArtwork/></FeatureRow>
    </div>
  </section>;
}
