import { useRevealOnScroll } from "../../hooks/useRevealOnScroll";

export function LandingGuide() {
  const section = useRevealOnScroll();
  return <section id="bat-dau" className="landing-width landing-guide" ref={section}>
    <header data-reveal>
      <h2>Cách vào Trạm</h2>
    </header>
    <ol className="landing-guide-steps" data-reveal>
      <li><strong>Tạo tài khoản</strong><p>Chọn tên đăng nhập và đặt mật khẩu.</p></li>
      <li><strong>Chọn server</strong><p>Tạo server của bạn hoặc nhập mã mời.</p></li>
      <li><strong>Mở kênh và nhắn</strong><p>Trên máy tính, nhấn <kbd>/</kbd> để gõ và Enter để gửi.</p></li>
    </ol>
  </section>;
}
