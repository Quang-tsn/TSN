import { useEffect, useRef, type ReactNode } from "react";
import { CloseIcon } from "../icons/CloseIcon";
export function Dialog({ title, onClose, children, className="" }: {
  title: string; onClose: () => void; children: ReactNode; className?:string;
}) {
  const box = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const previous = document.activeElement as HTMLElement | null;
    const first = box.current?.querySelector<HTMLElement>("[data-dialog-focus]") ??
      box.current?.querySelector<HTMLElement>("input,button");
    first?.focus();
    return () => previous?.focus();
  }, []);
  return <div className="modal-overlay" onMouseDown={(e) => {
    if (e.target === e.currentTarget) onClose();
  }}><div className={"dialog " + className} role="dialog" aria-modal="true" aria-label={title}
    ref={box} onKeyDown={(e) => {
      if (e.key === "Escape") onClose();
      if (e.key !== "Tab") return;
      const nodes = box.current?.querySelectorAll<HTMLElement>("input:not(:disabled),button:not(:disabled),textarea:not(:disabled),a[href],select:not(:disabled)");
      if (!nodes?.length) return;
      const first = nodes[0], last = nodes[nodes.length - 1];
      if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
      if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    }}>
    <header><h2>{title}</h2><button className="icon-button" aria-label="Đóng" onClick={onClose}>
      <CloseIcon/></button></header>{children}
  </div></div>;
}
