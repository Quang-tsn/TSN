import { useMemo,useState } from "react";
import type { SettingsDetails } from "../../shared/SettingsDetails";
import { activityCalendar } from "../../utils/activityCalendar";
import { settingsDate } from "../../utils/settingsDate";

const views = ["Hằng ngày","Hằng tuần","Tích lũy"] as const;
export function SettingsActivity({ activity }: { activity: SettingsDetails["activity"] }) {
  const [view,setView] = useState<typeof views[number]>(views[0]);
  const weeks = useMemo(()=>activityCalendar(activity,Date.now()),[activity]);
  const total = weeks[weeks.length-1].cumulative;
  const maximum = Math.max(1,...weeks.map(week=>view === "Hằng tuần" ? week.total : week.cumulative));
  return <section className="settings-activity" aria-labelledby="activity-title">
    <div className="settings-activity-head">
      <div><h2 id="activity-title">Hoạt động</h2><p>Số tin nhắn bạn gửi trong 53 tuần gần đây.</p></div>
      <div className="settings-activity-mode" aria-label="Chế độ hiển thị">
        {views.map(mode=><button key={mode} type="button" aria-pressed={mode===view} onClick={()=>setView(mode)}>{mode}</button>)}
      </div>
    </div>
    <div className="settings-activity-scroll" tabIndex={0} aria-label="Lịch hoạt động, có thể cuộn ngang">
      <div className="settings-activity-chart" role="img" aria-label={`${total} tin nhắn đã gửi. Hiển thị ${view.toLowerCase()}.`}>
        {weeks.map(week=>{
          const count = view === "Hằng tuần" ? week.total : week.cumulative;
          const level = Math.ceil(count/maximum*7);
          return <div className="settings-activity-week" key={week.monday} aria-hidden="true">
            {week.days.map((cell,index)=><span key={cell.day}
              className={view === "Hằng ngày" && cell.future ? "activity-future" : "activity-cell"}
              data-level={view === "Hằng ngày" ? (cell.count ? Math.min(4,Math.ceil(cell.count/3)) : 0)
                : 7-index<=level ? 3 : 0}
              title={view === "Hằng ngày" ? (cell.future ? undefined : `${settingsDate.format(cell.day*86400000)} · ${cell.count} tin`)
                : `Tuần ${settingsDate.format(week.monday*86400000)} · ${count} tin`}/>) }
            <span className="settings-activity-month">{week.month ? `Th ${week.month}` : ""}</span>
          </div>;
        })}
      </div>
    </div>
    <p className="settings-activity-count">{total.toLocaleString("vi-VN")} tin nhắn</p>
  </section>;
}
