import type { ExtraState } from "../../types/Extra";
import { ProfileIcon } from "../icons/ProfileIcon";

export function SettingsAvatar({ extra,revision = 0 }: { extra: ExtraState; revision?: number }) {
  const id = extra.user?.id;
  const image = extra.images?.find(item=>item.kind === "avatar");
  return <span className="settings-avatar" aria-hidden="true">
    {extra.user?.display_name[0]?.toUpperCase() ?? <ProfileIcon/>}
    {image && id && <img key={revision} alt="" src={`/api/extra/profile/${id}/avatar?v=${revision}`}
      onError={event=>{event.currentTarget.hidden=true;}}/>}
  </span>;
}
