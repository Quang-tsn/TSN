import { useState } from "react";
import type { ExtraState } from "../../types/Extra";
import { api } from "../../services/community/api";
import { SwitchAccountDialog } from "../auth/SwitchAccountDialog";

export function SettingsAccounts({ extra }: { extra: ExtraState }) {
  const [chooser,setChooser] = useState(false);
  const [busy,setBusy] = useState(false);
  const [error,setError] = useState("");
  const status = extra.status;
  if (!status) return null;
  async function switchTo(target: string) {
    setBusy(true);setError("");
    try { await api("extra/switch",{target}); location.reload(); }
    catch (cause) { setError((cause as Error).message); setBusy(false); }
  }
  const accounts = extra.accounts ?? [];
  return <section className="extra-card">
    <h2>Tài khoản</h2>
    {extra.canSwitch && status.allowed && status.slots > 1 ? <>
      <p>{accounts.length} / {status.slots} tài khoản, tính cả tài khoản chính.</p>
      <button className="secondary" onClick={()=>setChooser(true)}>Đổi tài khoản</button>
    </> : <p>{status.allowed ? "Avip và Svip hỗ trợ thêm tài khoản từ tài khoản chính." : "Gói đã hết hạn."}</p>}
    {extra.canSwitch && (accounts.length > 1) && <div className="extra-profiles settings-account-list">
      {accounts.map(account => <button key={account.id} className="secondary"
        disabled={busy || account.id === extra.user?.id || !account.selectable}
        onClick={()=>void switchTo(account.id)}>
        {account.display_name}{account.slot === 0 ? " · Chính" : ""}
        {account.id === extra.user?.id ? " · Đang dùng" : ""}
      </button>)}
    </div>}
    {error && <p className="error" role="alert">{error}</p>}
    {chooser && <SwitchAccountDialog onClose={()=>setChooser(false)}/>}
  </section>;
}
