import { useState } from "react";
import { requestAuth } from "../../services/auth/requestAuth";
import { BrandLogo } from "../icons/BrandLogo";
import { LogoutIcon } from "../icons/LogoutIcon";
import { ArrowLeftIcon } from "../icons/ArrowLeftIcon";

export function SettingsHeader({ signedIn }: { signedIn: boolean }) {
  const [busy,setBusy] = useState(false);
  const [error,setError] = useState("");
  async function logout() {
    setBusy(true);setError("");
    try { await requestAuth("logout",{}); location.replace("/login"); }
    catch (cause) { setError((cause as Error).message); setBusy(false); }
  }
  return <header className="settings-header">
    <div className="settings-shell-width settings-header-inner">
      <a className="settings-back-to-chat" href="/login"><ArrowLeftIcon/>Về chat</a>
      <a className="settings-brand" href="/"><BrandLogo/> Trạm</a>
      <span className="settings-breadcrumb">Cài đặt</span>
      <nav className="settings-header-links" aria-label="Trạm">
        <a href="/extraaccount">Gói sử dụng</a>
        {signedIn && <button type="button" disabled={busy} onClick={()=>void logout()}>
          <LogoutIcon/><span>Đăng xuất</span></button>}
      </nav>
    </div>
    {error && <p role="alert" className="error settings-shell-width">{error}</p>}
  </header>;
}
