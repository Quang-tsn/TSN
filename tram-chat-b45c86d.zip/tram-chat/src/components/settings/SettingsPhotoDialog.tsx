import type { ExtraState } from "../../types/Extra";
import { Dialog } from "../primitives/Dialog";
import { ProfileUpload } from "../extra/ProfileUpload";
import { SettingsAvatar } from "./SettingsAvatar";

export function SettingsPhotoDialog({ extra,revision,reload,onClose }: {
  extra: ExtraState; revision: number; reload: () => Promise<void>; onClose: () => void;
}) {
  return <Dialog title="Đổi ảnh hồ sơ" onClose={onClose}>
    <div className="settings-photo-preview"><SettingsAvatar extra={extra} revision={revision}/></div>
    {extra.status?.tier ? <ProfileUpload extra={extra} reload={reload}/>
      : <div className="settings-photo-help"><p>Gói ExtraAccount có tùy chọn tải ảnh đại diện.</p>
        <a className="settings-action" href="/extraaccount">Xem các gói</a></div>}
  </Dialog>;
}
