import type { ReactNode } from "react";

export function SettingsFact({ label,children }: { label: string; children: ReactNode }) {
  return <div className="settings-fact"><dt>{label}</dt><dd>{children}</dd></div>;
}
