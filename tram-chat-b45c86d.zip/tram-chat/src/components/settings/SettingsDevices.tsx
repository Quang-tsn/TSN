import type { SettingsDetails } from "../../shared/SettingsDetails";
import { settingsDateTime } from "../../utils/settingsDate";
import { DeviceIcon } from "../icons/DeviceIcon";
import { SettingsFact } from "./SettingsFact";
import { SettingsHeading } from "./SettingsHeading";

export function SettingsDevices({ details }: { details: SettingsDetails | null }) {
  const current = details?.sessions.find(session=>session.current);
  return <section>
    <SettingsHeading title="Thiết bị" description="Thông tin về trình duyệt bạn đang dùng để mở Trạm."/>
    {current && <>
      <div className="settings-current-device"><span><DeviceIcon/></span>
        <div><h2>{current.device || "Trình duyệt hiện tại"}</h2><p>Thiết bị này</p></div></div>
      <dl className="settings-facts">
        <SettingsFact label="Đăng nhập từ">{settingsDateTime.format(current.createdAt)}</SettingsFact>
        <SettingsFact label="Hoạt động gần nhất">{settingsDateTime.format(current.lastSeen)}</SettingsFact>
        <SettingsFact label="Phiên khác"><a className="settings-action" href="#phien">Xem thiết bị đã đăng nhập</a></SettingsFact>
      </dl>
    </>}
  </section>;
}
