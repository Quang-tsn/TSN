import { useState } from "react";
import type { ExtraState } from "../../types/Extra";
import type { SettingsDetails } from "../../shared/SettingsDetails";
import { settingsDate } from "../../utils/settingsDate";
import { EditIcon } from "../icons/EditIcon";
import { SettingsHeading } from "./SettingsHeading";
import { SettingsFact } from "./SettingsFact";
import { SettingsNameDialog } from "./SettingsNameDialog";

export function SettingsProfile({ extra,details,reload,onEditPhoto }: {
  extra: ExtraState; details: SettingsDetails | null; reload: () => Promise<void>; onEditPhoto: () => void;
}) {
  const [nameOpen,setNameOpen] = useState(false);
  return <section>
    <SettingsHeading title="Thông tin cá nhân" description="Tên và ảnh đại diện là thông tin bạn bè thấy khi trò chuyện."/>
    <dl className="settings-facts">
      <SettingsFact label="Tên hiển thị"><span>{extra.user?.display_name}</span>
        <button className="settings-action" onClick={()=>setNameOpen(true)}><EditIcon/> Sửa tên</button></SettingsFact>
      <SettingsFact label="Tên đăng nhập">@{extra.user?.username}</SettingsFact>
      <SettingsFact label="Email">{details ? details.email ?? "Chưa thêm email" : "—"}</SettingsFact>
      <SettingsFact label="Ảnh hồ sơ"><button className="settings-action" onClick={onEditPhoto}>Đổi ảnh</button></SettingsFact>
      <SettingsFact label="Ngôn ngữ giao diện">Tiếng Việt</SettingsFact>
      <SettingsFact label="Thành viên từ">{details ? settingsDate.format(details.createdAt) : "—"}</SettingsFact>
    </dl>
    {nameOpen && <SettingsNameDialog name={extra.user?.display_name ?? ""} onClose={()=>setNameOpen(false)}
      onSaved={async()=>{await reload();setNameOpen(false);}}/>}
  </section>;
}
