import type { SettingsDetails } from "../../shared/SettingsDetails";
import { SettingsFact } from "./SettingsFact";
import { SettingsHeading } from "./SettingsHeading";

export function SettingsSecurity({ details }: { details: SettingsDetails | null }) {
  return <section>
    <SettingsHeading title="Đăng nhập & bảo mật" description="Xem cách đăng nhập và các phiên còn hoạt động."/>
    <dl className="settings-facts">
      <SettingsFact label="Mật khẩu">{details ? details.passwordSet ? "Đã đặt mật khẩu" : "Đăng nhập qua tài khoản chính" : "—"}</SettingsFact>
      <SettingsFact label="Email đăng nhập">{details ? details.email ?? "Chưa thêm email" : "—"}</SettingsFact>
      <SettingsFact label="Phiên đang mở"><span>{details?.sessions.length ?? "—"}</span>
        <a className="settings-action" href="#phien">Quản lý phiên</a></SettingsFact>
    </dl>
  </section>;
}
