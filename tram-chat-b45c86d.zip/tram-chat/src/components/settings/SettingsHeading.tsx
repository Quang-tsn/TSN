export function SettingsHeading({ title,description }: { title: string; description?: string }) {
  return <header className="settings-heading">
    <h1>{title}</h1>{description && <p>{description}</p>}
  </header>;
}
