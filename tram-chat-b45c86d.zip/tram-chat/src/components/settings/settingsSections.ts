import { OverviewIcon } from "../icons/OverviewIcon";
import { ProfileIcon } from "../icons/ProfileIcon";
import { ShieldIcon } from "../icons/ShieldIcon";
import { BookmarkIcon } from "../icons/BookmarkIcon";
import { DeviceIcon } from "../icons/DeviceIcon";
import { SessionIcon } from "../icons/SessionIcon";
import { HistoryIcon } from "../icons/HistoryIcon";
import { SwitchIcon } from "../icons/SwitchIcon";

export const settingsSections = [
  { id:"tong-quan",label:"Tổng quan",icon:OverviewIcon },
  { id:"ho-so",label:"Thông tin cá nhân",icon:ProfileIcon },
  { id:"bao-mat",label:"Đăng nhập & bảo mật",icon:ShieldIcon },
  { id:"tin-da-luu",label:"Tin đã lưu",icon:BookmarkIcon },
  { id:"thiet-bi",label:"Thiết bị",icon:DeviceIcon },
  { id:"phien",label:"Phiên đăng nhập",icon:SessionIcon },
  { id:"lich-su-ma",label:"Lịch sử mã",icon:HistoryIcon },
  { id:"tai-khoan",label:"Đổi tài khoản",icon:SwitchIcon },
] as const;

export type SettingsSection = typeof settingsSections[number]["id"];
