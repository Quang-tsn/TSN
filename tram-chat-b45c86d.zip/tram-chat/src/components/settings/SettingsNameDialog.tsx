import { useState, type FormEvent } from "react";
import { api } from "../../services/community/api";
import { Dialog } from "../primitives/Dialog";

export function SettingsNameDialog({ name,onClose,onSaved }: {
  name: string; onClose: () => void; onSaved: () => Promise<void>;
}) {
  const [busy,setBusy] = useState(false);
  const [error,setError] = useState("");
  async function save(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();setBusy(true);setError("");
    const displayName = new FormData(event.currentTarget).get("name");
    try { await api("settings/profile",{displayName}); await onSaved(); }
    catch (cause) { setError((cause as Error).message); }
    finally { setBusy(false); }
  }
  return <Dialog title="Sửa tên hiển thị" onClose={onClose}>
    <form onSubmit={save}>
      <label>Tên hiển thị<input name="name" defaultValue={name} maxLength={64} required data-dialog-focus/></label>
      {error && <p role="alert" className="error">{error}</p>}
      <button className="settings-action" disabled={busy}>Lưu tên</button>
    </form>
  </Dialog>;
}
