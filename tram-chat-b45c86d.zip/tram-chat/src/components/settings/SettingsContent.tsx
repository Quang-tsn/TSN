import type { ExtraState } from "../../types/Extra";
import type { SettingsDetails } from "../../shared/SettingsDetails";
import { SavedPanel } from "../extra/SavedPanel";
import { SettingsHeading } from "./SettingsHeading";
import { SettingsOverview } from "./SettingsOverview";
import { SettingsProfile } from "./SettingsProfile";
import { SettingsSecurity } from "./SettingsSecurity";
import { SettingsDevices } from "./SettingsDevices";
import { SettingsSessions } from "./SettingsSessions";
import { SettingsCodeHistory } from "./SettingsCodeHistory";
import { SettingsAccounts } from "./SettingsAccounts";
import type { SettingsSection } from "./settingsSections";

export function SettingsContent({ active,extra,details,revision,reloadAccount,reloadDetails,onEditPhoto }: {
  active: SettingsSection; extra: ExtraState; details: SettingsDetails | null; revision: number;
  reloadAccount: () => Promise<void>; reloadDetails: () => Promise<void>; onEditPhoto: () => void;
}) {
  switch (active) {
    case "ho-so": return <SettingsProfile extra={extra} details={details} reload={reloadAccount} onEditPhoto={onEditPhoto}/>;
    case "bao-mat": return <SettingsSecurity details={details}/>;
    case "thiet-bi": return <SettingsDevices details={details}/>;
    case "phien": return <SettingsSessions details={details} reload={reloadDetails}/>;
    case "lich-su-ma": return <SettingsCodeHistory details={details}/>;
    case "tai-khoan": return <section>
      <SettingsHeading title="Đổi tài khoản" description="Thêm tài khoản vào nhóm hoặc chuyển sang tài khoản đã có."/>
      <SettingsAccounts extra={extra}/>
    </section>;
    case "tin-da-luu": return <section>
      <SettingsHeading title="Tin đã lưu" description="Mở lại tin nhắn, ảnh và GIF bạn đã lưu trong chat."/>
      {extra.status?.tier ? <SavedPanel key={extra.user?.id+":"+extra.status.storage} limit={extra.status.storage}/>
        : <div className="settings-empty">Kho tin đã lưu có trong ExtraAccount. <a href="/extraaccount">Xem các gói</a></div>}
    </section>;
    default: return <SettingsOverview extra={extra} details={details} revision={revision} onEditPhoto={onEditPhoto}/>;
  }
}
