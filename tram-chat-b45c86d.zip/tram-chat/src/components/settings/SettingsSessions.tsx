import { useState } from "react";
import type { SettingsDetails } from "../../shared/SettingsDetails";
import { api } from "../../services/community/api";
import { settingsDateTime } from "../../utils/settingsDate";
import { DeviceIcon } from "../icons/DeviceIcon";
import { SettingsHeading } from "./SettingsHeading";

export function SettingsSessions({ details,reload }: { details: SettingsDetails | null; reload: () => Promise<void> }) {
  const [busy,setBusy] = useState("");
  const [error,setError] = useState("");
  async function revoke(id: string) {
    setBusy(id);setError("");
    try { await api("settings/revoke-session",{id}); await reload(); }
    catch (cause) { setError((cause as Error).message); }
    finally { setBusy(""); }
  }
  return <section>
    <SettingsHeading title="Phiên đăng nhập" description="Xem các trình duyệt đang đăng nhập và đóng những phiên bạn không dùng."/>
    {error && <p className="error" role="alert">{error}</p>}
    {details && <div className="settings-table-scroll" tabIndex={0} aria-label="Bảng phiên đăng nhập">
      <table className="settings-table"><thead><tr>
        <th>Thiết bị</th><th>Đã tạo</th><th>Hoạt động gần nhất</th><th>Thao tác</th>
      </tr></thead><tbody>{details.sessions.map(session=><tr key={session.id}>
        <td><span className="settings-device-name"><DeviceIcon/>{session.device || "Trình duyệt chưa rõ"}
          {session.current && <small>Thiết bị này</small>}</span></td>
        <td>{settingsDateTime.format(session.createdAt)}</td><td>{settingsDateTime.format(session.lastSeen)}</td>
        <td>{!session.current && <button className="settings-action" disabled={!!busy} onClick={()=>void revoke(session.id)}>
          {busy === session.id ? "Đang đóng…" : "Đăng xuất phiên"}</button>}</td>
      </tr>)}</tbody></table>
    </div>}
  </section>;
}
