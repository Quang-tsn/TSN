import { useEffect,useState } from "react";
import { useExtra } from "../../hooks/useExtra";
import { useSettingsDetails } from "../../hooks/useSettingsDetails";
import { useSettingsSection } from "../../hooks/useSettingsSection";
import { SettingsHeader } from "./SettingsHeader";
import { SettingsSidebar } from "./SettingsSidebar";
import { SettingsContent } from "./SettingsContent";
import { SettingsPhotoDialog } from "./SettingsPhotoDialog";

export function SettingsPage() {
  const { extra,error,reload } = useExtra();
  const { details,error:detailsError,reload:reloadDetails } = useSettingsDetails(extra?.user?.id);
  const active = useSettingsSection();
  const [photo,setPhoto] = useState(false);
  const [revision,setRevision] = useState(0);
  const signedIn = !!extra?.user;
  const signedOut = !!extra && !signedIn;
  const oldPlan = ["#activation-code","#extraaccount","#extra-plans"].includes(location.hash);
  useEffect(()=>{
    if (oldPlan) location.replace("/extraaccount#extra-plans");
    else if (signedOut) location.replace("/login?next=settings"+location.hash);
  },[oldPlan,signedOut]);
  async function refreshPhoto() {
    await reload();
    setRevision(value=>value+1);
  }
  return <main className="settings-page">
    <SettingsHeader signedIn={signedIn}/>
    <div className="settings-shell-width settings-layout">
      {extra && signedIn && !oldPlan ? <>
        <SettingsSidebar extra={extra} active={active} revision={revision}/>
        <div className="settings-main">
          {(error || detailsError) && <p role="alert" className="error">{error || detailsError}</p>}
          <SettingsContent active={active} extra={extra} details={details} revision={revision}
            reloadAccount={reload} reloadDetails={reloadDetails} onEditPhoto={()=>setPhoto(true)}/>
          {!details && !detailsError && <p className="settings-loading" role="status">Đang tải dữ liệu tài khoản…</p>}
        </div>
        {photo && <SettingsPhotoDialog extra={extra} revision={revision} reload={refreshPhoto} onClose={()=>setPhoto(false)}/>}
      </> : error ? <p className="error" role="alert">{error}</p>
        : <p className="settings-loading" role="status">{oldPlan ? "Đang mở trang gói…" : signedOut ? "Đang mở đăng nhập…" : "Đang tải cài đặt…"}</p>}
    </div>
  </main>;
}
