import type { SettingsDetails } from "../../shared/SettingsDetails";
import { settingsDateTime } from "../../utils/settingsDate";
import { TierBadge } from "../extra/TierBadge";
import { SettingsHeading } from "./SettingsHeading";

export function SettingsCodeHistory({ details }: { details: SettingsDetails | null }) {
  return <section>
    <SettingsHeading title="Lịch sử mã" description="Các lần kích hoạt gói bằng mã trên tài khoản này."/>
    {details && (details.redemptions.length ? <div className="settings-table-scroll" tabIndex={0} aria-label="Bảng lịch sử mã">
      <table className="settings-table"><thead><tr><th>Gói</th><th>Đã kích hoạt</th><th>Dùng đến</th></tr></thead>
        <tbody>{details.redemptions.map((entry,index)=><tr key={entry.redeemedAt+":"+index}>
          <td><TierBadge tier={entry.tier}/></td><td>{settingsDateTime.format(entry.redeemedAt)}</td>
          <td>{settingsDateTime.format(entry.expiresAt)}</td>
        </tr>)}</tbody></table></div> : <p className="settings-empty">Chưa có mã nào được kích hoạt trên tài khoản này.</p>)}
  </section>;
}
