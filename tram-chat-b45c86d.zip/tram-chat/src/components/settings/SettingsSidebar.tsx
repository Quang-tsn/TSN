import type { ExtraState } from "../../types/Extra";
import { TierBadge } from "../extra/TierBadge";
import { SettingsAvatar } from "./SettingsAvatar";
import { settingsSections, type SettingsSection } from "./settingsSections";

export function SettingsSidebar({ extra,active,revision }: { extra: ExtraState; active: SettingsSection; revision: number }) {
  return <aside className="settings-sidebar">
    <div className="settings-sidebar-account">
      <SettingsAvatar extra={extra} revision={revision}/>
      <div><strong>{extra.user?.display_name}</strong><span>@{extra.user?.username}</span></div>
      <TierBadge tier={extra.status?.tier}/>
    </div>
    <nav className="settings-section-links" aria-label="Mục cài đặt">
      {settingsSections.map(({id,label,icon:Icon})=><a key={id} href={"#"+id}
        aria-current={active === id ? "page" : undefined}><Icon/><span>{label}</span></a>)}
    </nav>
  </aside>;
}
