import type { ExtraState } from "../../types/Extra";
import type { SettingsDetails } from "../../shared/SettingsDetails";
import { settingsDate } from "../../utils/settingsDate";
import { CameraIcon } from "../icons/CameraIcon";
import { TierBadge } from "../extra/TierBadge";
import { SettingsAvatar } from "./SettingsAvatar";
import { SettingsHeading } from "./SettingsHeading";
import { SettingsActivity } from "./SettingsActivity";

export function SettingsOverview({ extra,details,revision,onEditPhoto }: {
  extra: ExtraState; details: SettingsDetails | null; revision: number; onEditPhoto: () => void;
}) {
  const status = extra.status;
  const hours = status?.expiresAt ? Math.max(0,Math.ceil((status.expiresAt-Date.now())/3600000)) : 0;
  const remaining = hours >= 24 ? `${Math.floor(hours/24)} ngày ${hours%24} giờ` : `${hours} giờ`;
  const stats = [
    ["Thành viên từ",details ? settingsDate.format(details.createdAt) : "—"],
    ["Gói hiện tại",status?.tier ?? "Cơ bản"],
    ["Thời hạn còn lại",status?.tier ? remaining : "—"],
    ["Tài khoản trong nhóm",`${extra.accounts?.length ?? 1} / ${status?.slots ?? 1}`],
    ["Phiên đang mở",details?.sessions.length ?? "—"],
  ];
  return <section className="settings-overview">
    <SettingsHeading title="Tổng quan"/>
    <div className="settings-overview-profile">
      <button className="settings-avatar-edit" type="button" aria-label="Đổi ảnh hồ sơ" onClick={onEditPhoto}>
        <SettingsAvatar extra={extra} revision={revision}/><span><CameraIcon/></span>
      </button>
      <div className="settings-overview-name">
        <h2>{extra.user?.display_name}</h2><TierBadge tier={status?.tier}/><p>@{extra.user?.username}</p>
      </div>
    </div>
    <dl className="settings-stats">{stats.map(([label,value])=><div key={label}><dt>{label}</dt><dd>{value}</dd></div>)}</dl>
    {details && <SettingsActivity activity={details.activity}/>}
  </section>;
}
