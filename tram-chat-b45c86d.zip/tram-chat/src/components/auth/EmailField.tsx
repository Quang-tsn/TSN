export function EmailField() {
  return <label>Email <span className="optional">không bắt buộc</span>
    <input name="email" type="email" maxLength={254} autoComplete="email"
      autoCapitalize="none" placeholder="ban@example.com"/>
  </label>;
}
