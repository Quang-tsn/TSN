export function PasswordField({ register }: { register: boolean }) {
  return <label>Mật khẩu
    <input name="password" type="password" required minLength={12} maxLength={128}
      autoComplete={register ? "new-password" : "current-password"}
      placeholder={register ? "Từ 12 ký tự" : "Nhập mật khẩu của bạn"}/>
  </label>;
}
