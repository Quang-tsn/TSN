import { useEffect } from "react";
import { BrandLogo } from "../icons/BrandLogo";
import { AuthForm } from "./AuthForm";
import { AuthIntro } from "./AuthIntro";
import { useSession } from "../../hooks/auth/useSession";
import { ChatShell } from "../discord/shell/ChatShell";
import { UpgradeLink } from "../extra/UpgradeLink";
export function AuthPage({ register = false }: { register?: boolean }) {
  const session = useSession();
  const params = new URLSearchParams(location.search);
  const switching = params.get("switch") === "1";
  const next = params.get("next");
  const destination = next === "settings" ? "/settings" : next === "extraaccount" ? "/extraaccount" :
    next === "coins" ? "/coins" : null;
  useEffect(() => {
    if (session.user && destination) location.replace(destination + location.hash);
  }, [session.user,destination]);
  if (session.user && destination) return <p role="status">Đang mở trang…</p>;
  if (session.user && !switching) return <ChatShell key={session.user.id} user={session.user} onLogout={() => session.setUser(null)}/>;
  return <main className="auth-layout">
    <header className="auth-nav">
      <a className="landing-brand" href="/" aria-label="Trang chủ Trạm"><BrandLogo/>Trạm</a>
      <a className="auth-back" href={switching ? "/settings#tai-khoan" : "/"}>
        {switching ? "Trở lại tài khoản cũ" : "Về trang giới thiệu"}</a>
    </header>
    <div className="auth-stage">
      <AuthIntro/>
      <section className="auth-card" aria-labelledby="auth-title">
        <h1 id="auth-title">{register ? "Tạo tài khoản" : "Đăng nhập"}</h1>
        {destination && <p className="auth-description">{destination === "/extraaccount" ? "Vào tài khoản để dùng ExtraAccount." :
          destination === "/coins" ? "Vào tài khoản để mở Tamper Coins." : "Vào tài khoản để mở Cài đặt."}</p>}
        {session.loading ? <p role="status">Đang kiểm tra phiên đăng nhập…</p> : <>
          <p role="alert" className="error">{session.error}</p>
          {switching && !session.user ? <p>Phiên cũ đã hết. <a href="/login">Đăng nhập lại</a> để đổi tài khoản.</p>
            : <AuthForm register={register} addAccount={switching} onSuccess={user=>{
              if (switching && user) location.replace("/login");
              else session.setUser(user);
            }}/>}
          <p className="auth-switch">{register ? "Đã có tài khoản?" : "Chưa có tài khoản?"}
            {" "}<a href={(register ? "/login" : "/register") + (switching ? "?switch=1" : destination ? "?next=" + next + location.hash : "")}>
              {register ? "Đăng nhập" : "Tạo tài khoản"}</a>
          </p>
        </>}
      </section>
      {!session.loading && <UpgradeLink/>}
    </div>
  </main>;
}
