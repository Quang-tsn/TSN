import { HashIcon } from "../icons/HashIcon";
import { authTypingLength,authTypingScript } from "./authTypingScript";
import { TypedAuthText } from "./TypedAuthText";
import { useAuthTyping } from "../../hooks/auth/useAuthTyping";

export function AuthArtwork() {
  const count = useAuthTyping(authTypingLength);
  const typed = (line: number,part: number) => <TypedAuthText part={authTypingScript[line][part]} count={count}/>;
  return <div className="auth-art" aria-hidden="true">
    <div className="auth-transcript">
      <div className="auth-transcript-title"><HashIcon/><strong>{typed(0,0)}</strong><span>{typed(0,1)}</span></div>
      {[1,2,3].map(line=><div className="auth-transcript-line" key={line}>
        <span>{typed(line,0)}</span><b>{typed(line,1)}</b><div>{typed(line,2)}</div>
      </div>)}
      <div className="auth-transcript-draft"><b>{typed(4,0)}</b> {typed(4,1)}</div>
    </div>
  </div>;
}
