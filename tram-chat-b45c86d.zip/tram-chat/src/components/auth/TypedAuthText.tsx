export function TypedAuthText({ part,count }: { part: {value: string; start: number}; count: number }) {
  const visible = Math.max(0,Math.min(part.value.length,count-part.start));
  const typing = count >= part.start && count < part.start + part.value.length;
  return <>{part.value.slice(0,visible)}{typing && <i className="auth-type-caret"/>}
    <span className="auth-type-rest">{part.value.slice(visible)}</span></>;
}
