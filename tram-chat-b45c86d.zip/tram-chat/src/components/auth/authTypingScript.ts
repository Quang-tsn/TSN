const lines = [
  ["general","Hội chơi tối nay"],
  ["19:56","Minh","Tối nay đánh rank không?"],
  ["19:57","Linh","8h mình vào. Còn slot không?"],
  ["19:58","An","Còn một slot, vào #giao-luu nhé."],
  ["›","Đợi mình mở game…"],
];

let offset = 0;
export const authTypingScript = lines.map(line=>{
  const parts = line.map(value=>{
    const part = { value,start:offset };
    offset += value.length + 1;
    return part;
  });
  offset += 4;
  return parts;
});
export const authTypingLength = offset;
