import { Dialog } from "../primitives/Dialog";

export function SwitchAccountDialog({ onClose }: { onClose: () => void }) {
  return <Dialog title="Đổi tài khoản" onClose={onClose}>
    <p>Dùng tài khoản có sẵn hoặc tạo một tài khoản mới trong nhóm ExtraAccount.</p>
    <div className="account-choice-actions">
      <a className="secondary" href="/login?switch=1">Đăng nhập</a>
      <a className="primary" href="/register?switch=1">Đăng ký</a>
    </div>
  </Dialog>;
}
