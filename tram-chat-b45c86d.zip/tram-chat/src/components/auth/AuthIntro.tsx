import { AuthArtwork } from "./AuthArtwork";

export function AuthIntro() {
  return <div className="auth-intro">
    <AuthArtwork/>
  </div>;
}
