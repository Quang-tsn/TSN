import { useState } from "react";
import type { Account } from "../../types/Account";
import { requestAuth } from "../../services/auth/requestAuth";
export function AccountPanel({ user, onLogout }: {
  user: Account; onLogout: () => void;
}) {
  const [error, setError] = useState("");
  const [pending, setPending] = useState(false);
  async function logout() {
    setPending(true);
    try { await requestAuth("logout", {}); onLogout(); }
    catch { setError("Chưa đăng xuất được. Thử lại nhé."); }
    finally { setPending(false); }
  }
  return <section className="account">
    <div className="avatar" aria-hidden="true">{user.username[0].toUpperCase()}</div>
    <h1>{user.display_name}</h1><p>@{user.username}</p>
    <div className="stage-note">Tài khoản đã sẵn sàng.
      <span>Server, bạn bè và phòng chat sẽ xuất hiện ở cụm triển khai tiếp theo.</span>
    </div>
    <p role="alert" className="error">{error}</p>
    <button className="primary" onClick={logout} disabled={pending}>
      {pending ? "Đang đăng xuất…" : "Đăng xuất"}
    </button>
  </section>;
}
