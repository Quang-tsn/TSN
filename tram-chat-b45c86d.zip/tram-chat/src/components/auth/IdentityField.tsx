export function IdentityField({ register }: { register: boolean }) {
  return <label>{register ? "Tên đăng nhập" : "Tên đăng nhập hoặc email"}
    <input name={register ? "username" : "identity"} required maxLength={register ? 32 : 254}
      autoComplete="username" autoCapitalize="none" spellCheck={false}
      placeholder={register ? "Ví dụ: minh.nguyen" : "Tên bạn dùng ở Trạm"}
      pattern={register ? "[a-zA-Z0-9_.\\-]{3,32}" : undefined}/>
  </label>;
}
