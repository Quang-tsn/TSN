import { useState, type FormEvent } from "react";
import { IdentityField } from "./IdentityField";
import { EmailField } from "./EmailField";
import { PasswordField } from "./PasswordField";
import { requestAuth } from "../../services/auth/requestAuth";
import type { Account } from "../../types/Account";
export function AuthForm({ register, onSuccess, addAccount = false }: {
  register: boolean; onSuccess: (user: Account | null) => void; addAccount?: boolean;
}) {
  const [pending, setPending] = useState(false);
  const [error, setError] = useState("");
  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (pending) return;
    const form = event.currentTarget;
    const data = Object.fromEntries(new FormData(form).entries());
    setPending(true);
    setError("");
    try { onSuccess(await requestAuth(register ? "register" : "login", { ...data,addAccount })); }
    catch (cause) { setError(cause instanceof Error ? cause.message : "Thử lại nhé."); }
    finally { setPending(false); }
  }
  return <form onSubmit={submit}>
    <fieldset disabled={pending}>
      <IdentityField register={register}/>
      {register && <EmailField/>}
      <PasswordField register={register}/>
      {register && <p className="hint">Email chỉ dùng để đăng nhập. Chưa hỗ trợ khôi phục mật khẩu.</p>}
      <p className="error" role="alert">{error}</p>
      <button className="primary" type="submit">
        {pending ? "Đang xử lý…" : register ? "Tạo tài khoản" : "Đăng nhập"}
      </button>
    </fieldset>
  </form>;
}
