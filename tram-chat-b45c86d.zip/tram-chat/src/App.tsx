import { AuthPage } from "./components/auth/AuthPage";
import { LandingPage } from "./components/landing/LandingPage";
import { SettingsPage } from "./components/settings/SettingsPage";
import { PlansPage } from "./components/extra/PlansPage";
import { CoinsPage } from "./components/coins/CoinsPage";
import { useVisualViewport } from "./hooks/useVisualViewport";
export function App() {
  useVisualViewport();
  const path = window.location.pathname;
  if (path === "/settings") return <SettingsPage/>;
  if (path === "/extraaccount") return <PlansPage/>;
  if (path === "/coins") return <CoinsPage/>;
  return path === "/" ? <LandingPage/> : <AuthPage register={path === "/register"}/>;
}
