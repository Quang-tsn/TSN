export function parseGiphyLink(value: string): string | null {
  try {
    const url = new URL(value);
    if (url.protocol !== "https:" || !/(^|\.)giphy\.com$/.test(url.hostname)) return null;
    const [, section, item] = url.pathname.split("/");
    const id = section === "gifs" || section === "stickers" ? item?.split("-").pop()
      : section === "embed" || section === "media" ? item : null;
    return id && /^[a-zA-Z0-9]{1,80}$/.test(id) ? id : null;
  } catch { return null; }
}
