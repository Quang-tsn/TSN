export interface GiphyResult { id: string; title: string; images: { fixed_width_small: { url: string } } }
export async function searchGiphy(key: string, kind: "gif" | "sticker", query: string) {
  const params = new URLSearchParams({ api_key:key,q:query,limit:"12",rating:"pg" });
  const response = await fetch("https://api.giphy.com/v1/" + (kind === "gif" ? "gifs" : "stickers") + "/search?" + params);
  if (!response.ok) throw new Error("Tìm kiếm GIPHY tạm thời không khả dụng.");
  return (await response.json() as { data: GiphyResult[] }).data;
}
