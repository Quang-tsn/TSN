import type { Account } from "../../types/Account";
export async function requestAuth(path: string, data?: Record<string, unknown>) {
  const response = await fetch("/api/auth/" + path, {
    credentials: "same-origin", method: data ? "POST" : "GET",
    headers: data ? { "Content-Type": "application/json", "X-Tram-Request": "1" } : {},
    body: data ? JSON.stringify(data) : undefined,
  });
  const result = await response.json() as { user?: Account | null; error?: string };
  if (!response.ok) throw new Error(result.error || "Chưa kết nối được. Thử lại nhé.");
  return result.user || null;
}
