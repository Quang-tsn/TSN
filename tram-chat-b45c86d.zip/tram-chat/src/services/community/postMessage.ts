import { api } from "./api";
import type { Animation } from "../../types/Extra";
export async function postMessage(room: string, content: string, nonce: string,
  replyTo: string | undefined, image: File | null, animation?: Animation | null) {
  const path = "rooms/" + room + "/messages";
  if (!image) return api(path, { content, nonce, replyTo, animation });
  const body = new FormData();
  body.set("image", image);
  body.set("content", content);
  body.set("nonce", nonce);
  if (replyTo) body.set("replyTo", replyTo);
  return api(path, body);
}
