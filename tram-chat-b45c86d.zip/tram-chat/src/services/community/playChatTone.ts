export function playChatTone(context:AudioContext,mention:boolean) {
  const tones = mention ? [660,880] : [520];
  tones.forEach((frequency,index)=>{
    const oscillator = context.createOscillator();
    const volume = context.createGain();
    const start = context.currentTime + index * 0.135;
    oscillator.type = "sine";
    oscillator.frequency.value = frequency;
    volume.gain.setValueAtTime(0.001,start);
    volume.gain.exponentialRampToValueAtTime(0.095,start + 0.022);
    volume.gain.exponentialRampToValueAtTime(0.001,start + 0.145);
    oscillator.connect(volume);
    volume.connect(context.destination);
    oscillator.onended = ()=>{oscillator.disconnect();volume.disconnect();};
    oscillator.start(start);
    oscillator.stop(start + 0.15);
  });
}
