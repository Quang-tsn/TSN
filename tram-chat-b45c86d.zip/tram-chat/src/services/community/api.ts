export async function api<T>(path: string, data?: unknown,
  method = "POST", signal?: AbortSignal): Promise<T> {
  const response = await fetch("/api/" + path, {
    method: data === undefined ? "GET" : method, signal, credentials: "same-origin",
    headers: data instanceof FormData ? { "X-Tram-Request": "1" } :
      data === undefined ? {} : { "Content-Type": "application/json", "X-Tram-Request": "1" },
    body: data instanceof FormData ? data : data === undefined ? undefined : JSON.stringify(data),
  });
  const result = await response.json();
  if (!response.ok) throw Object.assign(new Error(result.error || "Chưa kết nối được. Thử lại nhé."),
    { status: response.status });
  return result as T;
}
