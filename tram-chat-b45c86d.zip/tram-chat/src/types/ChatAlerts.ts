export interface ChatAlerts { cursor:number; priority:0 | 1 | 2; }
