import type { Tier } from "../shared/extraPlans";
import type { Account } from "./Account";
export interface ExtraState {
  status: { owner: string; allowed: boolean; tier: Tier | null; expiresAt: number | null;
    slots: number; storage: number } | null;
  user: Account | null;
  accounts: (Account & { slot: number; selectable: number })[] | null;
  images: { kind: "avatar" | "background" }[] | null;
  giphyKey: string | null;
  trialReadyAt: number | null;
  canSwitch: boolean;
}
export interface Animation { id: string; kind: "gif" | "sticker" }
