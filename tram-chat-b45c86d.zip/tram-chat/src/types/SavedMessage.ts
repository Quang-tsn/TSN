import type { Message } from "./Community";

export type SavedMessage = Pick<Message,"id"|"content"|"display_name"|"image_id"|"image_width"|"image_height"|"giphy_id"|"animation_kind">
  & { room_id: string; saved_at: number; folder_id: string | null; server_name: string; room_name: string };
