export interface LinkPreview {
  kind:"provider" | "video" | "web" | "external";
  host:string;
  url:string;
  source:string;
  title:string;
}
