export interface Server { id: string; name: string; description: string; role: string; verified?: number; is_public?: number; }
export type PublicServer = Pick<Server,"id" | "name" | "description" | "verified"> & { joined: number };
export interface Channel { id: string; name: string; topic: string; }
export interface Member { id: string; username: string; display_name: string; role: string; }
export interface Detail { server: Server; role: string; channels: Channel[]; members: Member[]; }
export interface Message {
  id: string; author_id: string; content: string; created_at: number;
  display_name: string; username: string; client_nonce: string;
  image_id?: string | null; image_width?: number; image_height?: number;
  reply_id?: string | null; reply_author?: string | null; reply_content?: string | null;
  giphy_id?: string | null; animation_kind?: string; has_avatar?: number;
  avatar_mime?: string | null; has_background?: number; background_mime?: string | null;
  is_saved?: number; saved_folder_id?: string | null;
  tier?: import("../shared/extraPlans").Tier | null;
}
export interface Page { messages: Message[]; hasMore: boolean; }
