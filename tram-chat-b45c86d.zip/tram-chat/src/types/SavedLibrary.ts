import type { SavedMessage } from "./SavedMessage";

export type SavedSort = "newest" | "oldest" | "az" | "za";
export type SavedFilters = { q: string; sort: SavedSort; folder: string; author: string; server: string };
export type SavedOption = { id: string; name: string };
export type SavedCatalog = { folders: SavedOption[]; authors: SavedOption[]; servers: SavedOption[] };
export type SavedPage = { saved: SavedMessage[]; used: number; limit: number; next: string | null };
