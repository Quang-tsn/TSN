export interface CoinResult { balance:number;amount?:number; }
export interface CoinGiftHistory {
  id:string;amount:number;created_at:number;sent:number|null;username:string|null;display_name:string|null;
}
export interface CoinHistoryPage {items:CoinGiftHistory[];next:string|null;}
export type CoinGiftNotice = Pick<CoinGiftHistory,"id"|"amount"|"username">;
export type SubmitCoins = (action:string,data:Record<string,unknown>)=>Promise<CoinResult|null>;
