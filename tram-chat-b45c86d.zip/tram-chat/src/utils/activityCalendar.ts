import type { SettingsDetails } from "../shared/SettingsDetails";

const dayMs = 86400000;
export function activityCalendar(activity: SettingsDetails["activity"], now: number) {
  const today = Math.floor((now+25200000)/dayMs);
  const thisMonday = today - (new Date(today*dayMs).getUTCDay()+6)%7;
  const start = thisMonday - 52*7;
  const counts = new Map(activity.map(item=>[item.day,item.count]));
  let cumulative = 0;
  return Array.from({length:53},(_,week)=>{
    const monday = start + week*7;
    const days = Array.from({length:7},(_,offset)=>{
      const day = monday + offset;
      return {day,count:counts.get(day) ?? 0,future:day > today};
    });
    const month = days.find(cell=>new Date(cell.day*dayMs).getUTCDate() === 1)?.day;
    const total = days.reduce((sum,cell)=>sum+cell.count,0);
    cumulative += total;
    return {monday,days,month:month === undefined ? null : new Date(month*dayMs).getUTCMonth()+1,total,cumulative};
  });
}
