import type { LinkPreview } from "../types/LinkPreview";
import { videoEmbed } from "./videoEmbed";

export function linkPreview(url:URL):LinkPreview {
  const base = {url:url.href,host:url.host,source:url.href};
  const provider = videoEmbed(url);
  if (provider) return {...base,...provider,kind:"provider"};
  const local = url.origin===location.origin || /^[0-9.]+$/.test(url.hostname)
    || /\.(?:localhost|local|internal)$/i.test(url.hostname);
  if (url.protocol!=="https:" || local) return {...base,kind:"external",title:"Liên kết trang web"};
  if (/\.(?:mp4|webm|ogv|mov)$/i.test(url.pathname)) return {...base,kind:"video",title:"Tệp video"};
  return {...base,kind:"web",title:"Trang web"};
}
