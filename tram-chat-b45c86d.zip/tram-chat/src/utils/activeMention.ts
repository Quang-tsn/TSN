export function activeMention(value:string,caret:number) {
  const opening = value.slice(0,caret).match(/(^|[^\p{L}\p{N}@_.+-])@([a-z0-9_.-]{0,32})$/iu);
  if (!opening) return null;
  const query = opening[2].toLowerCase();
  const start = caret - query.length - 1;
  const textBefore = value.slice(0,start).split(/\s/).pop() || "";
  if (/(?:https?:\/\/|www\.|[\w-]+\.[\w-]+\/)/i.test(textBefore)) return null;
  const rest = value.slice(caret).match(/^[a-z0-9_.-]*/i)?.[0].length || 0;
  return {query,start,end:caret + rest};
}
