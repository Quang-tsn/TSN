export const settingsDate = new Intl.DateTimeFormat("vi-VN",{ dateStyle:"medium",timeZone:"Asia/Ho_Chi_Minh" });
export const settingsDateTime = new Intl.DateTimeFormat("vi-VN",{ dateStyle:"short",timeStyle:"short",timeZone:"Asia/Ho_Chi_Minh" });
