const amount = new Intl.NumberFormat("vi-VN",{ maximumFractionDigits:2 });

export function formatStorage(bytes: number) {
  if (bytes >= 1_000_000) return `${amount.format(bytes/1_000_000)} MB`;
  if (bytes >= 1_000) return `${amount.format(bytes/1_000)} KB`;
  return `${amount.format(bytes)} B`;
}
