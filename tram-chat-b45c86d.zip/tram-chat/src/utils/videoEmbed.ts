export function videoEmbed(url:URL) {
  const host = url.hostname;
  const path = url.pathname.split("/").filter(Boolean);
  const youtube = ["www.youtube.com","youtube.com","m.youtube.com","www.youtube-nocookie.com"].includes(host);
  const id = host==="youtu.be" ? path[0] : youtube ?
    (path[0]==="watch" ? url.searchParams.get("v") : ["shorts","embed","live","v"].includes(path[0]) ? path[1] : "") : "";
  if (id && /^[\w-]{11}$/.test(id)) {
    return {source:"https://www.youtube-nocookie.com/embed/"+id,title:"Video YouTube"};
  }
  if (["vimeo.com","www.vimeo.com","player.vimeo.com"].includes(host)) {
    const vimeoId = path[0]==="video" || path[0]==="channels" ? path[path.length-1] : path[0];
    const hash = url.searchParams.get("h") || (/^\d+$/.test(path[0]) ? path[1] : "");
    if (vimeoId && /^\d{1,16}$/.test(vimeoId)) return {
      source:"https://player.vimeo.com/video/"+vimeoId+(hash && /^[a-z0-9]{4,32}$/i.test(hash) ? "?h="+hash : ""),
      title:"Video Vimeo",
    };
  }
  return null;
}
