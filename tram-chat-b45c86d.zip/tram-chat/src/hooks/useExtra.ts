import { useCallback, useEffect, useRef, useState } from "react";
import { api } from "../services/community/api";
import type { ExtraState } from "../types/Extra";
export function useExtra() {
  const [extra,setExtra] = useState<ExtraState | null>(null);
  const [error,setError] = useState("");
  const revision = useRef(0);
  const reload = useCallback(async (signal?: AbortSignal) => {
    const current = ++revision.current;
    try {
      const data = await api<ExtraState>("extra",undefined,"GET",signal);
      if (!signal?.aborted && current === revision.current) { setExtra(data); setError(""); }
    } catch (cause) { if (!signal?.aborted && current === revision.current) setError((cause as Error).message); }
  },[]);
  const updateStatus = (status: ExtraState["status"]) => {
    revision.current++;
    setExtra(current => current && { ...current,status });
    setError("");
  };
  useEffect(() => {
    const controller = new AbortController();
    const load = () => { if (!document.hidden) void reload(controller.signal); };
    load();
    const timer = window.setInterval(load,30000);
    window.addEventListener("focus",load);
    window.addEventListener("pageshow",load);
    document.addEventListener("visibilitychange",load);
    return () => {
      controller.abort(); clearInterval(timer); window.removeEventListener("focus",load);
      window.removeEventListener("pageshow",load); document.removeEventListener("visibilitychange",load);
    };
  },[reload]);
  return { extra,error,reload,updateStatus };
}
