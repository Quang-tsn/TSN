import { useEffect,useState } from "react";
import { api } from "../services/community/api";
import type { CoinGiftNotice } from "../types/Coins";

export function useCoinGiftNotices(userId:string) {
  const key = "tram:gift-seen:"+userId;
  const [seen,setSeen] = useState(()=>{
    try {return localStorage.getItem(key) || "";} catch {return "";}
  });
  const [items,setItems] = useState<CoinGiftNotice[]>([]);
  useEffect(()=>{
    const controller = new AbortController();
    let running = false;
    async function refresh() {
      if (running || document.hidden) return;
      running=true;
      try {
        const result = await api<{items:CoinGiftNotice[]}>("coins/gift-notices",undefined,"GET",controller.signal);
        if (!controller.signal.aborted) setItems(result.items);
      } catch { /* The next refresh retries. */ }
      finally {running=false;}
    }
    void refresh();
    const timer = window.setInterval(refresh,30000);
    document.addEventListener("visibilitychange",refresh);
    return ()=>{
      controller.abort();window.clearInterval(timer);
      document.removeEventListener("visibilitychange",refresh);
    };
  },[]);
  const index = items.findIndex(item=>item.id===seen);
  function dismiss() {
    if (!items[0]) return;
    setSeen(items[0].id);
    try {localStorage.setItem(key,items[0].id);} catch { /* The current page still remembers it. */ }
  }
  return {notices:index<0 ? items : items.slice(0,index),dismiss};
}
