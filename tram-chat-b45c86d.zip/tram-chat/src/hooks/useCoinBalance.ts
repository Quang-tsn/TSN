import { useCallback,useEffect,useState } from "react";
import { api } from "../services/community/api";

export function useCoinBalance() {
  const [balance,setBalance] = useState<number|null>(null);
  const [error,setError] = useState("");
  const reload = useCallback((signal?:AbortSignal)=>{
    api<{balance:number}>("coins",undefined,"GET",signal).then(result=>{
      if (!signal?.aborted) {setBalance(result.balance);setError("");}
    }).catch(cause=>{if (!signal?.aborted) setError(cause.message);});
  },[]);
  useEffect(()=>{
    const controller = new AbortController();
    const refresh = ()=>{if (!document.hidden) reload(controller.signal);};
    refresh();
    document.addEventListener("visibilitychange",refresh);
    const timer = window.setInterval(refresh,30000);
    return ()=>{
      controller.abort();window.clearInterval(timer);
      document.removeEventListener("visibilitychange",refresh);
    };
  },[reload]);
  return {balance,setBalance,error};
}
