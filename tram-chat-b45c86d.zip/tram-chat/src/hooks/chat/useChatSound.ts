import { useCallback,useEffect,useRef,useState } from "react";
import { playChatTone } from "../../services/community/playChatTone";

export function useChatSound(userId:string) {
  const key = "tram:chat-sound:"+userId;
  const muted = useRef(false);
  const audio = useRef<AudioContext | null>(null);
  const [enabled,setEnabled] = useState(false);
  const arm = useCallback(()=>{
    if (muted.current) return;
    const Audio = window.AudioContext || (window as Window & {webkitAudioContext?:typeof AudioContext}).webkitAudioContext;
    if (!Audio) return;
    const context = audio.current ??= new Audio();
    if (context.state === "running") setEnabled(true);
    else void context.resume().then(()=>{
      if (audio.current===context && !muted.current) setEnabled(context.state==="running");
    }).catch(()=>{});
  },[]);
  useEffect(()=>{
    try { muted.current = localStorage.getItem(key)==="off"; } catch { /* Storage is optional. */ }
    window.addEventListener("click",arm);
    window.addEventListener("keydown",arm);
    return ()=>{
      window.removeEventListener("click",arm); window.removeEventListener("keydown",arm);
      const context = audio.current; audio.current = null;
      if (context && context.state!=="closed") void context.close().catch(()=>{});
    };
  },[arm,key]);
  const play = useCallback((mention:boolean)=>{
    if (!muted.current && audio.current?.state==="running") playChatTone(audio.current,mention);
  },[]);
  function toggle() {
    muted.current = enabled;
    try { localStorage.setItem(key,enabled ? "off" : "on"); } catch { /* Storage is optional. */ }
    if (enabled) setEnabled(false);
    else arm();
  }
  return {enabled,toggle,play};
}
