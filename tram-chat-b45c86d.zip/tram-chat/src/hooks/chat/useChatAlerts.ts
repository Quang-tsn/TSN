import { useCallback,useEffect,useRef } from "react";
import type { ChatAlerts } from "../../types/ChatAlerts";
import { api } from "../../services/community/api";
import { useChatSound } from "./useChatSound";

export function useChatAlerts(userId:string) {
  const {enabled,toggle,play} = useChatSound(userId);
  const room = useRef<string | null>(null);
  const setRoom = useCallback((value:string|null)=>{room.current=value;},[]);
  useEffect(()=>{
    const controller = new AbortController();
    let cursor:number|null = null;
    let timer:number|undefined;
    let running = false;
    async function poll() {
      if (running || controller.signal.aborted) return;
      running = true; window.clearTimeout(timer);
      const params = new URLSearchParams();
      if (cursor!==null) params.set("after",String(cursor));
      if (room.current) params.set("room",room.current);
      try {
        const result = await api<ChatAlerts>("chat-alerts?"+params,undefined,"GET",controller.signal);
        if (!controller.signal.aborted) {
          cursor = result.cursor;
          if (result.priority) play(result.priority===2);
        }
      } catch { /* The next poll resumes at the last confirmed event. */ }
      finally {
        running=false;
        if (!controller.signal.aborted) timer = window.setTimeout(poll,document.hidden ? 8000 : 3500);
      }
    }
    void poll(); document.addEventListener("visibilitychange",poll);
    return ()=>{
      controller.abort(); window.clearTimeout(timer); document.removeEventListener("visibilitychange",poll);
    };
  },[play,userId]);
  return {enabled,toggle,setRoom};
}
