import { useCallback, useEffect, useState } from "react";
import { api } from "../../services/community/api";
import type { Page } from "../../types/Community";
export function useMessages(roomId: string) {
  const [page, setPage] = useState<Page>({ messages: [], hasMore: false });
  const [before, setBefore] = useState<string | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [version, setVersion] = useState(0);
  const refresh = useCallback(() => { setBefore(null); setVersion((n) => n + 1); }, []);
  const reloadPage = useCallback(()=>setVersion(n=>n+1),[]);
  useEffect(() => {
    const controller = new AbortController();
    let running = false;
    setLoading(true);
    const load = async () => {
      if (running || document.hidden) return;
      running = true;
      try {
        const result = await api<Page>("rooms/" + roomId + "/messages" +
          (before ? "?before=" + encodeURIComponent(before) : ""), undefined, "GET", controller.signal);
        if (!controller.signal.aborted) { setPage(result); setError(""); }
      } catch (cause) {
        if (!controller.signal.aborted) {
          setError((cause as Error).message);
          if ([401, 403].includes((cause as { status?: number }).status || 0)) {
            setPage({ messages: [], hasMore: false });
          }
        }
      } finally {
        running = false;
        if (!controller.signal.aborted) setLoading(false);
      }
    };
    void load();
    const timer = before ? null : window.setInterval(load, 2000);
    document.addEventListener("visibilitychange", load);
    return () => {
      controller.abort();
      if (timer) clearInterval(timer);
      document.removeEventListener("visibilitychange", load);
    };
  }, [roomId, before, version]);
  return { ...page, loading, error, refresh, reloadPage, history: !!before,
    older: () => setBefore(page.messages[0]?.id || null) };
}
