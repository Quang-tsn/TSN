import { useId,useState,type KeyboardEvent,type RefObject } from "react";
import type { Member } from "../../types/Community";
import { activeMention } from "../../utils/activeMention";
import { foldVietnamese } from "../../shared/foldVietnamese";

export function useMentionSuggestions(input:RefObject<HTMLTextAreaElement|null>,content:string,
  setContent:(text:string)=>void,members:Member[]) {
  const listId = useId();
  const [caret,setCaret] = useState<number|null>(null);
  const [index,setIndex] = useState(0);
  const token = caret===null ? null : activeMention(content,caret);
  const choices = token ? [
    ...("all".startsWith(token.query) ? [{id:"all",username:"all",display_name:"Mọi người trong kênh"}] : []),
    ...members.filter(member=>member.username!=="all" &&
      (member.username.includes(token.query) || foldVietnamese(member.display_name).includes(token.query))),
  ].slice(0,6) : [];
  const selected = Math.min(index,choices.length-1);
  function position(element:HTMLTextAreaElement) {
    const next = element.selectionStart === element.selectionEnd ? element.selectionStart : null;
    if (next!==caret) {setCaret(next);setIndex(0);}
  }
  function choose(username:string) {
    if (!token) return;
    const inserted = "@"+username+" ";
    const next = content.slice(0,token.start)+inserted+content.slice(token.end).replace(/^ /,"");
    if (next.length > 4000) return;
    setContent(next);setCaret(null);
    input.current?.focus();
    requestAnimationFrame(()=>input.current?.setSelectionRange(token.start+inserted.length,token.start+inserted.length));
  }
  function keydown(event:KeyboardEvent<HTMLTextAreaElement>) {
    if (!choices.length || event.nativeEvent.isComposing || event.shiftKey) return false;
    if (event.key==="Escape") {setCaret(null);}
    else if (event.key==="ArrowDown" || event.key==="ArrowUp") {
      setIndex((selected+(event.key==="ArrowDown" ? 1 : choices.length-1))%choices.length);
    } else if (event.key==="Enter" || event.key==="Tab") {choose(choices[selected].username);}
    else return false;
    event.preventDefault();
    return true;
  }
  return {choices,selected,listId,position,choose,keydown,close:()=>setCaret(null)};
}
