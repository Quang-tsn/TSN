import { useEffect, type RefObject } from "react";
export function useComposerShortcut(input: RefObject<HTMLTextAreaElement | null>) {
  useEffect(() => {
    function focusComposer(event: KeyboardEvent) {
      const target = event.target;
      if (event.defaultPrevented || event.key !== "/" || event.repeat || event.isComposing ||
          event.ctrlKey || event.metaKey || event.altKey || document.querySelector('[aria-modal="true"]')) return;
      if (target instanceof HTMLElement && (target.isContentEditable ||
          target.closest("input,textarea,select,[role=textbox]"))) return;
      if (!input.current || input.current.disabled) return;
      event.preventDefault();
      input.current.focus();
    }
    document.addEventListener("keydown", focusComposer);
    return () => document.removeEventListener("keydown", focusComposer);
  }, [input]);
}
