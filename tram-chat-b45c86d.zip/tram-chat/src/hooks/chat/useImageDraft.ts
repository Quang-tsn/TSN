import { useEffect, useState, type ClipboardEvent } from "react";
export function useImageDraft(setError: (message: string) => void,megabytes=4) {
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState("");
  useEffect(() => {
    if (!file) { setPreview(""); return; }
    const url = URL.createObjectURL(file);
    setPreview(url);
    return () => URL.revokeObjectURL(url);
  }, [file]);
  function select(image?: File | null) {
    if (!image) return;
    if (!["image/png", "image/jpeg"].includes(image.type) || !image.size ||
        image.size > megabytes * 1024 * 1024) {
      setError(`Chọn ảnh PNG hoặc JPEG tối đa ${megabytes} MB.`);
      return;
    }
    setFile(image);
    setError("");
  }
  function paste(event: ClipboardEvent<HTMLFormElement>) {
    const image = Array.from(event.clipboardData.items)
      .find((item) => item.kind === "file" && item.type.startsWith("image/"));
    if (!image) return;
    if (!event.clipboardData.getData("text/plain")) event.preventDefault();
    select(image.getAsFile());
  }
  return { file, preview, select, paste, clear: () => setFile(null) };
}
