import { useCallback, useEffect, useState } from "react";
import { api } from "../../services/community/api";
import type { Server } from "../../types/Community";
export function useWorkspace() {
  const [servers, setServers] = useState<Server[]>([]);
  const [selected, setSelected] = useState<string | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const reload = useCallback(async () => {
    try {
      const data = await api<{ servers: Server[] }>("servers");
      setServers(data.servers); setError("");
      setSelected((id) => id && data.servers.some((s) => s.id === id) ? id : data.servers[0]?.id || null);
    } catch (cause) { setError((cause as Error).message); }
    finally { setLoading(false); }
  }, []);
  useEffect(() => { void reload(); }, [reload]);
  return { servers, selected, setSelected, error, loading, reload };
}
