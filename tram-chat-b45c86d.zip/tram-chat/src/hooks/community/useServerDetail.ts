import { useEffect, useState } from "react";
import { api } from "../../services/community/api";
import type { Detail } from "../../types/Community";
export function useServerDetail(id: string | null, version: number) {
  const [detail, setDetail] = useState<Detail | null>(null);
  const [error, setError] = useState("");
  useEffect(() => {
    setDetail(null); setError("");
    if (!id) return;
    const controller = new AbortController();
    let running = false;
    const load = async () => {
      if (document.hidden || running) return;
      running = true;
      try {
        const data = await api<Detail>("servers/" + id, undefined, "GET", controller.signal);
        if (!controller.signal.aborted) { setDetail(data); setError(""); }
      } catch (cause) {
        if (!controller.signal.aborted) setError((cause as Error).message);
      } finally { running = false; }
    };
    void load();
    const timer = window.setInterval(load, 15000);
    return () => { controller.abort(); clearInterval(timer); };
  }, [id, version]);
  return { detail, error };
}
