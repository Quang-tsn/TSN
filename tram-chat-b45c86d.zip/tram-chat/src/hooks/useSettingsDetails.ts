import { useCallback,useEffect,useState } from "react";
import { api } from "../services/community/api";
import type { SettingsDetails } from "../shared/SettingsDetails";

export function useSettingsDetails(userId?: string) {
  const [record,setRecord] = useState<{userId: string; details: SettingsDetails} | null>(null);
  const [error,setError] = useState("");
  const reload = useCallback(async (signal?: AbortSignal) => {
    if (!userId) return;
    try {
      const data = await api<SettingsDetails>("settings",undefined,"GET",signal);
      if (!signal?.aborted) { setRecord({userId,details:data}); setError(""); }
    } catch (cause) { if (!signal?.aborted) setError((cause as Error).message); }
  },[userId]);
  useEffect(()=>{
    const controller = new AbortController();
    void reload(controller.signal);
    return ()=>controller.abort();
  },[reload]);
  return { details:record?.userId === userId ? record?.details ?? null : null,error,reload };
}
