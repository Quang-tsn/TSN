import { useRef,useState } from "react";
import { api } from "../services/community/api";
import type { CoinResult } from "../types/Coins";
import { notableGiftThreshold } from "../shared/tamperCoins";

export function useCoinAction(onSuccess:(result:CoinResult,action:string)=>void) {
  const [pending,setPending] = useState("");
  const [notice,setNotice] = useState("");
  const [giftThanks,setGiftThanks] = useState("");
  const [error,setError] = useState("");
  const busy = useRef(false);
  const attempt = useRef<{key:string;nonce:string}|null>(null);
  async function submit(action:string,data:Record<string,unknown>) {
    if (busy.current) return null;
    busy.current = true;setPending(action);setError("");setNotice("");setGiftThanks("");
    const key = JSON.stringify([action,data]);
    if (attempt.current?.key!==key) attempt.current={key,nonce:crypto.randomUUID()};
    try {
      const result = await api<CoinResult>("coins/"+action,{...data,nonce:attempt.current.nonce});
      attempt.current=null;onSuccess(result,action);
      if (action==="gift" && typeof data.amount==="number" && data.amount>notableGiftThreshold) {
        const recipient = String(data.username).trim().replace(/^@/,"").toLowerCase();
        setGiftThanks(`Đã gửi ${data.amount.toLocaleString("vi-VN")} Coins đến @${recipient}. Trạm trân trọng cảm ơn món quà của bạn.`);
      } else setNotice(action==="gift" ? "Đã tặng Coins." : action==="exchange" ?
        "Đã kích hoạt gói ExtraAccount." : `Đã nhận ${result.amount} Coins.`);
      return result;
    } catch (cause) {setError((cause as Error).message);return null;}
    finally {busy.current=false;setPending("");}
  }
  return {submit,pending,notice,error,giftThanks};
}
