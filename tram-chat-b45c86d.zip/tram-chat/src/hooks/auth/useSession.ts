import { useEffect,useRef,useState } from "react";
import type { Account } from "../../types/Account";
import { requestAuth } from "../../services/auth/requestAuth";
export function useSession() {
  const [user,setCurrentUser] = useState<Account | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const revision = useRef(0);
  function setUser(value: Account | null) {
    revision.current++;
    setCurrentUser(value);
    setLoading(false);
    setError("");
  }
  useEffect(() => {
    let active = true;
    function reload() {
      if (document.hidden) return;
      const request = ++revision.current;
      const current = () => active && request === revision.current;
      requestAuth("me").then(value=>{if(current()) {setCurrentUser(value);setError("");}})
        .catch((cause: Error)=>{if(current()) setError(cause.message);})
        .finally(()=>{if(current()) setLoading(false);});
    }
    reload();
    window.addEventListener("focus",reload);
    window.addEventListener("pageshow",reload);
    document.addEventListener("visibilitychange",reload);
    return () => {
      active = false;
      window.removeEventListener("focus",reload);
      window.removeEventListener("pageshow",reload);
      document.removeEventListener("visibilitychange",reload);
    };
  }, []);
  return { user, setUser, loading, error, setError };
}
