import { useEffect,useState } from "react";

export function useAuthTyping(length: number) {
  const [count,setCount] = useState(0);
  useEffect(()=>{
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)");
    const start = performance.now();
    const tick = () => {
      const next = reduced.matches ? length : Math.min(length,Math.floor((performance.now()-start)/28));
      setCount(next);
      if (next === length) window.clearInterval(timer);
    };
    const timer = window.setInterval(tick,28);
    tick();
    return ()=>window.clearInterval(timer);
  },[length]);
  return count;
}
