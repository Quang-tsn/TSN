import { useEffect, useState } from "react";
export function useTrialClock(ready: number | null) {
  const [now,setNow] = useState(Date.now);
  useEffect(() => {
    if (ready === null) return;
    setNow(Date.now());
    const timer = window.setInterval(() => setNow(Date.now()),250);
    return () => clearInterval(timer);
  },[ready]);
  return ready === null ? null : Math.max(0,Math.ceil((ready - now)/1000));
}
