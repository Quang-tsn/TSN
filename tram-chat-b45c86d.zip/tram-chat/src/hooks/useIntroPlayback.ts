import { useCallback,useEffect,useRef,useState } from "react";

type Playback = "ready" | "playing" | "finished" | "summary";

export function useIntroPlayback() {
  const frame = useRef<HTMLDivElement>(null);
  const started = useRef(false);
  const [mode,setMode] = useState<Playback>("ready");
  const [visible,setVisible] = useState(true);
  const [pageVisible,setPageVisible] = useState(true);
  const start = useCallback(()=>{
    started.current = true;
    setMode(window.matchMedia("(prefers-reduced-motion: reduce)").matches ? "summary" : "playing");
  },[]);
  const finish = () => setMode("finished");
  useEffect(()=>{
    const target = frame.current;
    if (!target || typeof IntersectionObserver === "undefined") return;
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)");
    let inView = false;
    const autoPlay = () => {
      if (!started.current && inView && window.scrollY > 0 && !document.hidden && !reduced.matches) start();
    };
    const onVisibility = () => { setPageVisible(!document.hidden); autoPlay(); };
    const onMotionChange = () => {
      if (reduced.matches) setMode(current=>current === "playing" ? "summary" : current);
      else autoPlay();
    };
    const observer = new IntersectionObserver(([entry])=>{
      inView = entry.isIntersecting && entry.intersectionRatio >= .55;
      setVisible(entry.isIntersecting);
      autoPlay();
    },{threshold:[0,.55]});
    observer.observe(target);
    window.addEventListener("scroll",autoPlay,{passive:true});
    document.addEventListener("visibilitychange",onVisibility);
    reduced.addEventListener("change",onMotionChange);
    return ()=>{
      observer.disconnect();
      window.removeEventListener("scroll",autoPlay);
      document.removeEventListener("visibilitychange",onVisibility);
      reduced.removeEventListener("change",onMotionChange);
    };
  },[start]);
  return {frame,mode,paused:!visible || !pageVisible,start,finish};
}
