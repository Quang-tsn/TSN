import { useEffect,useState } from "react";
import { settingsSections, type SettingsSection } from "../components/settings/settingsSections";

function readSection(): SettingsSection {
  const hash = window.location.hash.slice(1);
  return settingsSections.find(section=>section.id === hash)?.id ?? "tong-quan";
}

export function useSettingsSection() {
  const [active,setActive] = useState(readSection);
  useEffect(()=>{
    const sync = () => { setActive(readSection()); window.scrollTo(0,0); };
    window.addEventListener("hashchange",sync);
    return ()=>window.removeEventListener("hashchange",sync);
  },[]);
  return active;
}
