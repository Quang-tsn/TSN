import { useEffect, useRef } from "react";

export function useRevealOnScroll() {
  const section = useRef<HTMLElement>(null);

  useEffect(() => {
    const container = section.current;
    if (!container || !("IntersectionObserver" in window) ||
        window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;

    const observer = new IntersectionObserver((entries) => {
      for (const entry of entries) {
        if (!entry.isIntersecting) continue;
        entry.target.removeAttribute("data-reveal-pending");
        observer.unobserve(entry.target);
      }
    }, { threshold: 0.12 });

    for (const row of container.querySelectorAll("[data-reveal]")) {
      if (row.getBoundingClientRect().top > window.innerHeight) {
        row.setAttribute("data-reveal-pending", "");
        observer.observe(row);
      }
    }

    return () => observer.disconnect();
  }, []);

  return section;
}
