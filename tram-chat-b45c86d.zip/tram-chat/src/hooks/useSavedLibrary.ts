import { useEffect,useState } from "react";
import type { SavedCatalog,SavedFilters,SavedOption,SavedPage } from "../types/SavedLibrary";
import { api } from "../services/community/api";

const initial: SavedFilters = {q:"",folder:"",author:"",server:"",sort:"newest"};
const empty: SavedCatalog = {folders:[],authors:[],servers:[]};

export function useSavedLibrary() {
  const [filters,setFilters] = useState(initial);
  const [catalog,setCatalog] = useState(empty);
  const [data,setData] = useState<SavedPage | null>(null);
  const [error,setError] = useState("");
  const [catalogError,setCatalogError] = useState("");
  const [busy,setBusy] = useState(true);
  const [before,setBefore] = useState<string | null>(null);
  const [version,setVersion] = useState(0);
  function update<K extends keyof SavedFilters>(key: K,value: SavedFilters[K]) {
    setFilters(current=>({...current,[key]:value})); setBefore(null);
  }
  function refresh() { setBefore(null); setVersion(value=>value+1); }
  function addFolder(folder: SavedOption) {
    setCatalog(current=>({...current,folders:[...current.folders,folder]}));
    update("folder",folder.id); refresh();
  }
  useEffect(()=>{
    const controller = new AbortController();
    api<SavedCatalog>("extra/saved-catalog",undefined,"GET",controller.signal)
      .then(result=>{if(!controller.signal.aborted) {setCatalog(result);setCatalogError("");}})
      .catch(cause=>{if(!controller.signal.aborted) setCatalogError(cause.message);});
    return ()=>controller.abort();
  },[version]);
  useEffect(()=>{
    const controller = new AbortController();
    const params = new URLSearchParams(filters);
    if (before) params.set("before",before);
    setBusy(true);
    const timer = window.setTimeout(()=>{
      api<SavedPage>("extra/saved?"+params,undefined,"GET",controller.signal)
        .then(result=>{if(!controller.signal.aborted) {setData(result);setError("");}})
        .catch(cause=>{if(!controller.signal.aborted) setError(cause.message);})
        .finally(()=>{if(!controller.signal.aborted) setBusy(false);});
    },filters.q ? 180 : 0);
    return ()=>{controller.abort();window.clearTimeout(timer);};
  },[filters,before,version]);
  return {filters,catalog,data,busy,error:error || catalogError,before,update,setBefore,refresh,addFolder};
}
