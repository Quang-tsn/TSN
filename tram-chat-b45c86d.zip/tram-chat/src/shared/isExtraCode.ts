export function isExtraCode(value: string) {
  return value.length === 12 && /^[A-Z0-9]+$/.test(value) && /[A-Z]/.test(value) && /[0-9]/.test(value);
}
