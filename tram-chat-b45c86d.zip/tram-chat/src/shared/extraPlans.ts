export const extraPlans = {
  Bvip: { storage: 2_500_000, slots: 1, week: null, month: null },
  Avip: { storage: 5_000_000, slots: 3, week: "0.49", month: "1.00" },
  Svip: { storage: 10_000_000, slots: 10, week: "1.00", month: "2.00" },
} as const;
export type Tier = keyof typeof extraPlans;
export type PaidTier = Exclude<Tier, "Bvip">;
export const trialWait = 90_000;
export const trialDuration = 12 * 60 * 60 * 1000;
