export const coinPacks = [
  {coins:50,price:"0,99"}, {coins:100,price:"1,99"}, {coins:200,price:"2,99"},
  {coins:500,price:"4,99"}, {coins:2000,price:"5,99"},
] as const;
export const coinExchanges = [
  {tier:"Bvip",days:1,coins:9},{tier:"Bvip",days:30,coins:199},
  {tier:"Avip",days:1,coins:19},{tier:"Avip",days:30,coins:499},
  {tier:"Svip",days:1,coins:29},{tier:"Svip",days:30,coins:799},
] as const;
export const notableGiftThreshold = 100;

