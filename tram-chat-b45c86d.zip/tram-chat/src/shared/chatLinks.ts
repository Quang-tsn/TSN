export interface ChatLink { start: number; end: number; label: string; url: URL; }

export function chatLinks(text: string): ChatLink[] {
  const links: ChatLink[] = [];
  const pattern = /(^|[^\p{L}\p{N}@._/-])((?:https?:\/\/|www\.|(?:youtube\.com|youtu\.be|vimeo\.com)\/)[^\s<>"`]+)/giu;
  for (const match of text.matchAll(pattern)) {
    const start = match.index! + match[1].length;
    let label = match[2].replace(/[.,!?;:’”]+$/u,"");
    for (const [open,close] of [["(",")"],["[","]"],["{","}"]]) {
      while (label.endsWith(close) && label.split(close).length > label.split(open).length) label = label.slice(0,-1);
    }
    if (label.length > 2048) continue;
    try {
      const url = new URL(/^https?:\/\//i.test(label) ? label : "https://" + label);
      if (!url.hostname.includes(".") || url.username || url.password) continue;
      links.push({ start, end:start + label.length, label, url });
    } catch { continue; }
  }
  return links;
}
