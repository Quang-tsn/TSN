export function normalizeExtraCode(value: string) {
  return value.replace(/[\s\u200B-\u200D\u2060-]/g, "").replace(/[a-z]/g, letter => letter.toUpperCase());
}
