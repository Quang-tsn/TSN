import type { PaidTier } from "./extraPlans";

export interface SettingsSession {
  id: string; device: string; createdAt: number; lastSeen: number; expiresAt: number; current: boolean;
}

export interface SettingsDetails {
  email: string | null;
  createdAt: number;
  passwordSet: boolean;
  sessions: SettingsSession[];
  activity: { day: number; count: number }[];
  redemptions: { tier: PaidTier; redeemedAt: number; expiresAt: number }[];
}
