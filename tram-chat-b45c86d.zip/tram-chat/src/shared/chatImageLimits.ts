export const freeChatImage = {pixels:12_000_000, megabytes:4};
export const extraChatImage = {pixels:24_000_000, megabytes:8};
