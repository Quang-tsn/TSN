import { chatLinks } from "./chatLinks";

export function chatMentions(text: string, links = chatLinks(text)) {
  const mentions: { start:number; end:number; username:string }[] = [];
  let linkIndex = 0;
  for (const match of text.matchAll(/(^|[^\p{L}\p{N}@_.+-])@([a-z0-9_.-]{3,32})(?![a-z0-9_.-])/giu)) {
    const start = match.index! + match[1].length;
    const end = start + 1 + match[2].length;
    while (links[linkIndex] && links[linkIndex].end <= start) linkIndex++;
    if (links[linkIndex] && links[linkIndex].start < end) continue;
    mentions.push({ start, end, username:match[2].toLowerCase() });
  }
  return mentions;
}
