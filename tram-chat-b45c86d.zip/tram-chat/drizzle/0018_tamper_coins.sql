CREATE TABLE coin_entries (
  id TEXT PRIMARY KEY NOT NULL,
  kind TEXT NOT NULL CHECK(kind IN ('daily','purchase','gift','exchange')),
  sender_id TEXT REFERENCES users(id) ON DELETE SET NULL,
  recipient_id TEXT REFERENCES users(id) ON DELETE SET NULL,
  amount INTEGER NOT NULL CHECK(amount BETWEEN 1 AND 9007199254740991),
  detail TEXT NOT NULL DEFAULT '',
  created_at INTEGER NOT NULL,
  CHECK(sender_id IS NULL OR recipient_id IS NULL OR sender_id<>recipient_id)
);
--> statement-breakpoint
CREATE INDEX coin_entries_sender ON coin_entries(sender_id,kind,created_at DESC,id DESC);
--> statement-breakpoint
CREATE INDEX coin_entries_recipient ON coin_entries(recipient_id,kind,created_at DESC,id DESC);
--> statement-breakpoint
CREATE TABLE coin_daily (
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  day TEXT NOT NULL,
  code TEXT NOT NULL,
  amount INTEGER NOT NULL CHECK(amount BETWEEN 1 AND 5),
  PRIMARY KEY(user_id,day)
);
--> statement-breakpoint
CREATE TABLE coin_purchase_codes (
  digest TEXT PRIMARY KEY NOT NULL,
  amount INTEGER NOT NULL CHECK(amount IN (50,100,200,500,2000)),
  created_at INTEGER NOT NULL
);
