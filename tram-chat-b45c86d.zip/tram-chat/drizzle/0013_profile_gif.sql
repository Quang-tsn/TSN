CREATE TABLE extra_profile_assets_next (
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  kind TEXT NOT NULL CHECK (kind IN ('avatar','background')),
  object_key TEXT NOT NULL UNIQUE,
  mime TEXT NOT NULL CHECK (mime IN ('image/jpeg','image/png','image/gif')),
  PRIMARY KEY (user_id,kind)
);
--> statement-breakpoint
INSERT INTO extra_profile_assets_next SELECT user_id,kind,object_key,mime FROM extra_profile_assets;
--> statement-breakpoint
DROP TABLE extra_profile_assets;
--> statement-breakpoint
ALTER TABLE extra_profile_assets_next RENAME TO extra_profile_assets;
