ALTER TABLE servers ADD COLUMN is_public INTEGER NOT NULL DEFAULT 0 CHECK (is_public IN (0,1));
--> statement-breakpoint
ALTER TABLE servers ADD COLUMN verified INTEGER NOT NULL DEFAULT 0 CHECK (verified IN (0,1));
--> statement-breakpoint
ALTER TABLE servers ADD COLUMN search_name TEXT NOT NULL DEFAULT '';
--> statement-breakpoint
CREATE INDEX servers_discoverable ON servers(verified DESC,created_at DESC,id) WHERE is_public=1;
--> statement-breakpoint
INSERT INTO users(id,username,display_name,created_at,updated_at)
VALUES ('tram-system-public','[he-thong-tram]','Trạm',1795276800014,1795276800014);
--> statement-breakpoint
INSERT INTO servers(id,owner_id,name,description,created_at,is_public,verified,search_name)
VALUES ('tram-server-test','tram-system-public','Server Test','Cộng đồng công khai để làm quen với Trạm.',
  1795276800014,1,1,'server test');
--> statement-breakpoint
INSERT INTO server_members(server_id,user_id,role,joined_at)
VALUES ('tram-server-test','tram-system-public','owner',1795276800014);
--> statement-breakpoint
INSERT INTO rooms(id,kind,server_id,name,position,created_at) VALUES
  ('tram-test-general','channel','tram-server-test','general',0,1795276800014),
  ('tram-test-giao-luu','channel','tram-server-test','giao-luu',1,1795276800014);
