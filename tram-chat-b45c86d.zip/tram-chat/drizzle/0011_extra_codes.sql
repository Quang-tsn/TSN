CREATE TABLE extra_codes (
  digest TEXT PRIMARY KEY NOT NULL,
  tier TEXT NOT NULL CHECK (tier IN ('Avip','Svip')),
  period TEXT NOT NULL CHECK (period IN ('week','month')),
  created_at INTEGER NOT NULL,
  redeemed_at INTEGER
);
