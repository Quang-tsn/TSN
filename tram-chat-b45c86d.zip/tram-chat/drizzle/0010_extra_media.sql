CREATE TABLE extra_profile_assets (
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  kind TEXT NOT NULL CHECK (kind IN ('avatar','background')),
  object_key TEXT NOT NULL UNIQUE,
  mime TEXT NOT NULL CHECK (mime IN ('image/jpeg','image/png')),
  PRIMARY KEY (user_id,kind)
);
--> statement-breakpoint
CREATE TABLE extra_animations (
  message_id TEXT PRIMARY KEY NOT NULL REFERENCES messages(id) ON DELETE CASCADE,
  giphy_id TEXT NOT NULL CHECK (length(giphy_id) BETWEEN 1 AND 80),
  kind TEXT NOT NULL CHECK (kind IN ('gif','sticker'))
);
