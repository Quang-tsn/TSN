CREATE TABLE link_previews (
  id TEXT PRIMARY KEY NOT NULL,
  url TEXT NOT NULL UNIQUE CHECK (length(url) BETWEEN 8 AND 2048),
  title TEXT NOT NULL DEFAULT '' CHECK (length(title) <= 300),
  description TEXT NOT NULL DEFAULT '' CHECK (length(description) <= 1000),
  site_name TEXT NOT NULL DEFAULT '' CHECK (length(site_name) <= 100),
  image_url TEXT CHECK (image_url IS NULL OR length(image_url) <= 2048),
  state TEXT NOT NULL DEFAULT 'pending'
    CHECK (state IN ('pending', 'ready', 'failed')),
  fetched_at INTEGER CHECK (fetched_at IS NULL OR fetched_at >= 0),
  expires_at INTEGER NOT NULL CHECK (expires_at >= 0),
  CHECK (url LIKE 'https://%' OR url LIKE 'http://%')
);
--> statement-breakpoint
CREATE INDEX previews_expiry ON link_previews(expires_at);
--> statement-breakpoint
CREATE TABLE message_links (
  message_id TEXT NOT NULL REFERENCES messages(id) ON DELETE CASCADE,
  preview_id TEXT NOT NULL REFERENCES link_previews(id) ON DELETE CASCADE,
  position INTEGER NOT NULL CHECK (position BETWEEN 0 AND 2),
  PRIMARY KEY (message_id, preview_id),
  UNIQUE (message_id, position)
);
--> statement-breakpoint
CREATE TABLE room_events (
  sequence INTEGER PRIMARY KEY AUTOINCREMENT,
  room_id TEXT NOT NULL REFERENCES rooms(id) ON DELETE CASCADE,
  message_id TEXT,
  kind TEXT NOT NULL CHECK (kind IN
    ('message.created', 'message.updated', 'message.deleted',
     'reaction.changed', 'pin.changed', 'preview.changed')),
  created_at INTEGER NOT NULL CHECK (created_at >= 0),
  FOREIGN KEY (message_id, room_id)
    REFERENCES messages(id, room_id) ON DELETE CASCADE
);
--> statement-breakpoint
CREATE INDEX events_room_cursor ON room_events(room_id, sequence);
--> statement-breakpoint
CREATE INDEX events_retention ON room_events(created_at);
