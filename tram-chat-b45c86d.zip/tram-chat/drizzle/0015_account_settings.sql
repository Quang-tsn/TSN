ALTER TABLE sessions ADD COLUMN device_name TEXT NOT NULL DEFAULT '';
--> statement-breakpoint
CREATE INDEX messages_author_activity ON messages(author_id,created_at);
