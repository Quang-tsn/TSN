CREATE TABLE room_reads (
  room_id TEXT NOT NULL REFERENCES rooms(id) ON DELETE CASCADE,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  last_message_id TEXT,
  updated_at INTEGER NOT NULL CHECK (updated_at >= 0),
  muted INTEGER NOT NULL DEFAULT 0 CHECK (muted IN (0, 1)),
  PRIMARY KEY (room_id, user_id),
  FOREIGN KEY (last_message_id, room_id) REFERENCES messages(id, room_id)
    DEFERRABLE INITIALLY DEFERRED
);
--> statement-breakpoint
CREATE INDEX room_reads_user ON room_reads(user_id);
--> statement-breakpoint
CREATE TABLE server_invites (
  id TEXT PRIMARY KEY NOT NULL,
  server_id TEXT NOT NULL REFERENCES servers(id) ON DELETE CASCADE,
  code_hash TEXT NOT NULL UNIQUE CHECK (length(code_hash) = 64),
  created_by TEXT NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  created_at INTEGER NOT NULL CHECK (created_at >= 0),
  expires_at INTEGER CHECK (expires_at IS NULL OR expires_at > created_at),
  max_uses INTEGER CHECK (max_uses IS NULL OR max_uses > 0),
  use_count INTEGER NOT NULL DEFAULT 0 CHECK (use_count >= 0),
  revoked_at INTEGER,
  CHECK (max_uses IS NULL OR use_count <= max_uses)
);
--> statement-breakpoint
CREATE INDEX invites_server ON server_invites(server_id);
--> statement-breakpoint
CREATE TABLE invite_uses (
  invite_id TEXT NOT NULL REFERENCES server_invites(id) ON DELETE CASCADE,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  used_at INTEGER NOT NULL CHECK (used_at >= 0),
  PRIMARY KEY (invite_id, user_id)
);
