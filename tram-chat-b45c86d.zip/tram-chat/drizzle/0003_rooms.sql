CREATE TABLE rooms (
  id TEXT PRIMARY KEY NOT NULL,
  kind TEXT NOT NULL CHECK (kind IN ('channel', 'direct')),
  server_id TEXT REFERENCES servers(id) ON DELETE CASCADE,
  category_id TEXT,
  name TEXT CHECK (name IS NULL OR length(name) BETWEEN 1 AND 100),
  topic TEXT NOT NULL DEFAULT '' CHECK (length(topic) <= 1000),
  position INTEGER NOT NULL DEFAULT 0 CHECK (position >= 0),
  direct_user_low TEXT REFERENCES users(id) ON DELETE RESTRICT,
  direct_user_high TEXT REFERENCES users(id) ON DELETE RESTRICT,
  created_at INTEGER NOT NULL CHECK (created_at >= 0),
  UNIQUE (direct_user_low, direct_user_high),
  FOREIGN KEY (category_id, server_id)
    REFERENCES channel_categories(id, server_id),
  CHECK (
    (kind = 'channel' AND server_id IS NOT NULL AND name IS NOT NULL
      AND direct_user_low IS NULL AND direct_user_high IS NULL)
    OR
    (kind = 'direct' AND server_id IS NULL AND category_id IS NULL
      AND name IS NULL AND direct_user_low IS NOT NULL
      AND direct_user_high IS NOT NULL AND direct_user_low < direct_user_high)
  )
);
--> statement-breakpoint
CREATE UNIQUE INDEX channel_unique_name ON rooms(server_id, name)
  WHERE kind = 'channel';
--> statement-breakpoint
CREATE INDEX rooms_server_order ON rooms(server_id, position, id);
--> statement-breakpoint
CREATE INDEX rooms_direct_low ON rooms(direct_user_low);
--> statement-breakpoint
CREATE INDEX rooms_direct_high ON rooms(direct_user_high);
