CREATE TABLE messages (
  id TEXT PRIMARY KEY NOT NULL,
  room_id TEXT NOT NULL REFERENCES rooms(id) ON DELETE CASCADE,
  author_id TEXT NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  client_nonce TEXT NOT NULL CHECK (length(client_nonce) BETWEEN 8 AND 64),
  content TEXT NOT NULL DEFAULT '' CHECK (length(content) <= 4000),
  reply_to_id TEXT,
  created_at INTEGER NOT NULL CHECK (created_at >= 0),
  edited_at INTEGER CHECK (edited_at IS NULL OR edited_at >= created_at),
  deleted_at INTEGER CHECK (deleted_at IS NULL OR deleted_at >= created_at),
  UNIQUE (id, room_id),
  UNIQUE (author_id, client_nonce),
  CHECK (reply_to_id IS NULL OR reply_to_id <> id),
  FOREIGN KEY (reply_to_id, room_id) REFERENCES messages(id, room_id)
    DEFERRABLE INITIALLY DEFERRED
);
--> statement-breakpoint
CREATE INDEX messages_timeline ON messages(room_id, created_at DESC, id DESC);
--> statement-breakpoint
CREATE INDEX messages_author ON messages(author_id);
--> statement-breakpoint
CREATE INDEX messages_reply ON messages(reply_to_id, room_id);
