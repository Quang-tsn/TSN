CREATE TABLE users (
  id TEXT PRIMARY KEY NOT NULL,
  username TEXT NOT NULL COLLATE NOCASE UNIQUE,
  email TEXT COLLATE NOCASE UNIQUE,
  display_name TEXT NOT NULL,
  avatar_file_id TEXT,
  status TEXT NOT NULL DEFAULT 'online'
    CHECK (status IN ('online', 'idle', 'dnd', 'invisible')),
  bio TEXT NOT NULL DEFAULT '' CHECK (length(bio) <= 300),
  created_at INTEGER NOT NULL CHECK (created_at >= 0),
  updated_at INTEGER NOT NULL CHECK (updated_at >= created_at),
  CHECK (length(username) BETWEEN 3 AND 32 AND instr(username, '@') = 0),
  CHECK (length(display_name) BETWEEN 1 AND 64),
  CHECK (email IS NULL OR (length(email) BETWEEN 3 AND 254
    AND instr(email, '@') > 1 AND instr(email, '@') < length(email))),
  FOREIGN KEY (avatar_file_id) REFERENCES files(id) ON DELETE SET NULL
);
--> statement-breakpoint
CREATE TABLE password_credentials (
  user_id TEXT PRIMARY KEY NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  password_hash TEXT NOT NULL CHECK (length(password_hash) BETWEEN 32 AND 256),
  salt TEXT NOT NULL CHECK (length(salt) BETWEEN 16 AND 128),
  algorithm TEXT NOT NULL DEFAULT 'pbkdf2-sha256'
    CHECK (algorithm = 'pbkdf2-sha256'),
  iterations INTEGER NOT NULL CHECK (iterations >= 100000),
  changed_at INTEGER NOT NULL CHECK (changed_at >= 0)
);
--> statement-breakpoint
CREATE TABLE sessions (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash TEXT NOT NULL UNIQUE CHECK (length(token_hash) = 64),
  created_at INTEGER NOT NULL CHECK (created_at >= 0),
  expires_at INTEGER NOT NULL CHECK (expires_at > created_at),
  last_seen_at INTEGER NOT NULL CHECK (last_seen_at >= created_at),
  revoked_at INTEGER
);
--> statement-breakpoint
CREATE INDEX sessions_user ON sessions(user_id);
--> statement-breakpoint
CREATE INDEX sessions_expiry ON sessions(expires_at);
--> statement-breakpoint
CREATE TABLE user_preferences (
  user_id TEXT PRIMARY KEY NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  compact_messages INTEGER NOT NULL DEFAULT 0 CHECK (compact_messages IN (0, 1)),
  reduced_motion INTEGER NOT NULL DEFAULT 0 CHECK (reduced_motion IN (0, 1)),
  allow_dms INTEGER NOT NULL DEFAULT 1 CHECK (allow_dms IN (0, 1)),
  updated_at INTEGER NOT NULL CHECK (updated_at >= 0)
);
