CREATE TABLE files (
  id TEXT PRIMARY KEY NOT NULL,
  uploader_id TEXT NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  object_key TEXT NOT NULL UNIQUE CHECK (length(object_key) BETWEEN 1 AND 512),
  thumbnail_key TEXT CHECK (thumbnail_key IS NULL OR length(thumbnail_key) <= 512),
  original_name TEXT NOT NULL CHECK (length(original_name) BETWEEN 1 AND 255),
  mime_type TEXT NOT NULL CHECK (mime_type IN
    ('image/jpeg', 'image/png', 'image/webp', 'image/gif')),
  byte_size INTEGER NOT NULL CHECK (byte_size BETWEEN 1 AND 8388608),
  width INTEGER NOT NULL CHECK (width BETWEEN 1 AND 16384),
  height INTEGER NOT NULL CHECK (height BETWEEN 1 AND 16384),
  state TEXT NOT NULL DEFAULT 'pending'
    CHECK (state IN ('pending', 'ready', 'deleted')),
  created_at INTEGER NOT NULL CHECK (created_at >= 0)
);
--> statement-breakpoint
CREATE INDEX files_cleanup ON files(state, created_at);
--> statement-breakpoint
CREATE INDEX files_uploader ON files(uploader_id);
--> statement-breakpoint
CREATE TABLE message_attachments (
  message_id TEXT NOT NULL REFERENCES messages(id) ON DELETE CASCADE,
  file_id TEXT NOT NULL UNIQUE REFERENCES files(id) ON DELETE RESTRICT,
  position INTEGER NOT NULL DEFAULT 0 CHECK (position BETWEEN 0 AND 3),
  PRIMARY KEY (message_id, file_id),
  UNIQUE (message_id, position)
);
--> statement-breakpoint
CREATE TABLE message_reactions (
  message_id TEXT NOT NULL REFERENCES messages(id) ON DELETE CASCADE,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  reaction_code TEXT NOT NULL CHECK (reaction_code IN
    ('thumbs-up', 'heart', 'laugh', 'surprised', 'sad', 'celebrate')),
  created_at INTEGER NOT NULL CHECK (created_at >= 0),
  PRIMARY KEY (message_id, user_id, reaction_code)
);
--> statement-breakpoint
CREATE INDEX reactions_user ON message_reactions(user_id);
--> statement-breakpoint
CREATE TABLE message_pins (
  message_id TEXT PRIMARY KEY NOT NULL,
  room_id TEXT NOT NULL REFERENCES rooms(id) ON DELETE CASCADE,
  pinned_by TEXT NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  pinned_at INTEGER NOT NULL CHECK (pinned_at >= 0),
  FOREIGN KEY (message_id, room_id)
    REFERENCES messages(id, room_id) ON DELETE CASCADE
);
--> statement-breakpoint
CREATE INDEX pins_room ON message_pins(room_id, pinned_at DESC);
