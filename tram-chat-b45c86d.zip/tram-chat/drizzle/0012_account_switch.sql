ALTER TABLE sessions ADD COLUMN switch_owner_id TEXT REFERENCES users(id) ON DELETE SET NULL;
--> statement-breakpoint
UPDATE sessions SET switch_owner_id=(SELECT owner_id FROM extra_accounts WHERE user_id=sessions.user_id)
WHERE EXISTS (SELECT 1 FROM extra_accounts WHERE user_id=sessions.user_id)
AND NOT EXISTS (SELECT 1 FROM password_credentials WHERE user_id=sessions.user_id);
