CREATE TABLE extra_grants (
  id TEXT PRIMARY KEY NOT NULL,
  owner_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  tier TEXT NOT NULL CHECK (tier IN ('Bvip', 'Avip', 'Svip')),
  starts_at INTEGER NOT NULL,
  expires_at INTEGER NOT NULL CHECK (expires_at > starts_at)
);
--> statement-breakpoint
CREATE INDEX extra_grants_owner ON extra_grants(owner_id,tier,expires_at);
--> statement-breakpoint
CREATE TABLE extra_trials (
  owner_id TEXT PRIMARY KEY NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  id TEXT NOT NULL UNIQUE,
  started_at INTEGER NOT NULL
);
--> statement-breakpoint
CREATE TABLE extra_accounts (
  user_id TEXT PRIMARY KEY NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  owner_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  slot INTEGER NOT NULL CHECK (slot BETWEEN 1 AND 9),
  UNIQUE (owner_id,slot),
  CHECK (user_id <> owner_id)
);
--> statement-breakpoint
CREATE TABLE extra_orders (
  id TEXT PRIMARY KEY NOT NULL,
  owner_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  tier TEXT NOT NULL CHECK (tier IN ('Avip', 'Svip')),
  period TEXT NOT NULL CHECK (period IN ('week','month')),
  created_at INTEGER NOT NULL
);
--> statement-breakpoint
CREATE TABLE extra_saved (
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  owner_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  message_id TEXT NOT NULL REFERENCES messages(id) ON DELETE CASCADE,
  saved_at INTEGER NOT NULL,
  PRIMARY KEY (user_id,message_id)
);
--> statement-breakpoint
CREATE INDEX extra_saved_owner ON extra_saved(owner_id);
