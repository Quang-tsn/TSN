ALTER TABLE messages ADD COLUMN mention_all INTEGER NOT NULL DEFAULT 0 CHECK (mention_all IN (0,1));
--> statement-breakpoint
CREATE TABLE message_mentions (
  message_id TEXT NOT NULL REFERENCES messages(id) ON DELETE CASCADE,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  PRIMARY KEY (message_id,user_id)
);
--> statement-breakpoint
CREATE INDEX message_mentions_user ON message_mentions(user_id,message_id);
