CREATE TABLE servers (
  id TEXT PRIMARY KEY NOT NULL,
  owner_id TEXT NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  name TEXT NOT NULL CHECK (length(name) BETWEEN 1 AND 100),
  description TEXT NOT NULL DEFAULT '' CHECK (length(description) <= 1000),
  icon_file_id TEXT REFERENCES files(id) ON DELETE SET NULL,
  created_at INTEGER NOT NULL CHECK (created_at >= 0)
);
--> statement-breakpoint
CREATE INDEX servers_owner ON servers(owner_id);
--> statement-breakpoint
CREATE TABLE server_members (
  server_id TEXT NOT NULL REFERENCES servers(id) ON DELETE CASCADE,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  role TEXT NOT NULL DEFAULT 'member'
    CHECK (role IN ('owner', 'admin', 'moderator', 'member')),
  nickname TEXT CHECK (nickname IS NULL OR length(nickname) BETWEEN 1 AND 64),
  joined_at INTEGER NOT NULL CHECK (joined_at >= 0),
  PRIMARY KEY (server_id, user_id)
);
--> statement-breakpoint
CREATE INDEX server_members_user ON server_members(user_id, server_id);
--> statement-breakpoint
CREATE UNIQUE INDEX server_one_owner ON server_members(server_id)
  WHERE role = 'owner';
--> statement-breakpoint
CREATE TABLE channel_categories (
  id TEXT PRIMARY KEY NOT NULL,
  server_id TEXT NOT NULL REFERENCES servers(id) ON DELETE CASCADE,
  name TEXT NOT NULL CHECK (length(name) BETWEEN 1 AND 100),
  position INTEGER NOT NULL DEFAULT 0 CHECK (position >= 0),
  UNIQUE (id, server_id)
);
--> statement-breakpoint
CREATE INDEX categories_order ON channel_categories(server_id, position, id);
