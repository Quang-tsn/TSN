CREATE TABLE room_presence (
  room_id TEXT NOT NULL REFERENCES rooms(id) ON DELETE CASCADE,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  device_id TEXT NOT NULL CHECK (length(device_id) BETWEEN 8 AND 64),
  last_seen_at INTEGER NOT NULL CHECK (last_seen_at >= 0),
  typing_until INTEGER NOT NULL DEFAULT 0 CHECK (typing_until >= 0),
  expires_at INTEGER NOT NULL CHECK (expires_at > last_seen_at),
  PRIMARY KEY (room_id, user_id, device_id)
);
--> statement-breakpoint
CREATE INDEX presence_expiry ON room_presence(expires_at);
--> statement-breakpoint
CREATE INDEX presence_user ON room_presence(user_id, expires_at);
--> statement-breakpoint
CREATE TABLE auth_rate_limits (
  key_hash TEXT PRIMARY KEY NOT NULL CHECK (length(key_hash) = 64),
  attempts INTEGER NOT NULL DEFAULT 0 CHECK (attempts >= 0),
  window_start INTEGER NOT NULL CHECK (window_start >= 0),
  expires_at INTEGER NOT NULL CHECK (expires_at > window_start)
);
--> statement-breakpoint
CREATE INDEX rate_limits_expiry ON auth_rate_limits(expires_at);
