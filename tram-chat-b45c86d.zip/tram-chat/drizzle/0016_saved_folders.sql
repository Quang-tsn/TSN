CREATE TABLE extra_saved_folders (
  id TEXT PRIMARY KEY NOT NULL,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name TEXT NOT NULL CHECK (length(name) BETWEEN 1 AND 64),
  name_key TEXT NOT NULL,
  created_at INTEGER NOT NULL,
  UNIQUE (user_id,name_key)
);
--> statement-breakpoint
ALTER TABLE extra_saved ADD COLUMN folder_id TEXT REFERENCES extra_saved_folders(id) ON DELETE SET NULL;
--> statement-breakpoint
CREATE INDEX extra_saved_folder_order ON extra_saved(user_id,folder_id,saved_at,message_id);
