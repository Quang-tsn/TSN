CREATE TABLE friend_requests (
  id TEXT PRIMARY KEY NOT NULL,
  sender_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  recipient_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at INTEGER NOT NULL CHECK (created_at >= 0),
  CHECK (sender_id <> recipient_id),
  UNIQUE (sender_id, recipient_id)
);
--> statement-breakpoint
CREATE UNIQUE INDEX friend_requests_pair ON friend_requests(
  min(sender_id, recipient_id), max(sender_id, recipient_id)
);
--> statement-breakpoint
CREATE INDEX friend_requests_recipient ON friend_requests(recipient_id);
--> statement-breakpoint
CREATE TABLE friendships (
  user_low TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  user_high TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at INTEGER NOT NULL CHECK (created_at >= 0),
  PRIMARY KEY (user_low, user_high),
  CHECK (user_low < user_high)
);
--> statement-breakpoint
CREATE INDEX friendships_high ON friendships(user_high);
--> statement-breakpoint
CREATE TABLE user_blocks (
  blocker_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  blocked_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at INTEGER NOT NULL CHECK (created_at >= 0),
  PRIMARY KEY (blocker_id, blocked_id),
  CHECK (blocker_id <> blocked_id)
);
--> statement-breakpoint
CREATE INDEX user_blocks_reverse ON user_blocks(blocked_id, blocker_id);
