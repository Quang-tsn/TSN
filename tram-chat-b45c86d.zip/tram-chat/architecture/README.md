# Danh mục file dự kiến

Mỗi .txt chứa một đường dẫn tương đối với gốc tram-chat trên mỗi dòng.
Danh mục chia theo subsystem, đồng bộ với docs/architecture cùng tên.
Đây là manifest kiến trúc, không phải yêu cầu tạo toàn bộ file ngay.

- [Danh mục tài liệu và cây thư mục](../docs/architecture/index.md).
- Ký hiệu [H] trong cây: tệp đã tồn tại khi lập tài liệu phase nền.
- Ký hiệu [P] trong cây: tệp dự kiến, chưa triển khai hoặc tạo rỗng.
- Marker chỉ mô tả sự tồn tại, không khẳng định feature hoàn thành.
- Khi triển khai cụm mới, cập nhật marker và manifest trong cùng thay đổi.
- Mỗi đường dẫn chỉ nằm trong một manifest subsystem.
- Không đưa node_modules, dist, .git, local DB hay file secret vào danh mục.
- Các tệp docs/architecture và architecture được liệt kê qua index/tên manifest.
- Không dùng file JSON nhồi nhiều tên trên một dòng để né trần 80 dòng.
- Tên gọi channel trong UI ánh xạ rooms.kind=channel trong DB.
- Migration hiện hành là nguồn đúng cho schema, không suy bảng từ tên component.
- Custom roles chưa có trong schema; các module role dùng enum cố định.

