# Trạm — Nhắn tin & Cộng đồng

Trạm có tài khoản, cộng đồng, kênh, trả lời tin nhắn và gửi ảnh.
Dữ liệu chat dùng D1, ảnh dùng R2. Giao diện có thanh cộng đồng ngang.
Nhấn / để mở ô soạn. Dán hoặc chọn một ảnh PNG/JPEG tối đa 4 MB mỗi tin.
Chat cập nhật mỗi 2 giây và hiển thị tối đa 50 tin cùng lúc.

- [Cây thư mục đầy đủ](docs/architecture/index.md)
- [Từ điển dữ liệu và sơ đồ quan hệ](docs/database/README.md)
- Schema chuẩn: các migration SQL trong `drizzle/`
- Backend: Cloudflare Worker; Database: D1; ảnh: R2 qua Sites.
- Không tích hợp Google, thanh toán hoặc ví.

## Chạy kiểm tra

Yêu cầu Node.js >=22.13, npm và Python 3.12.

```sh
npm ci
npm run db:migrate
npm run test:database
npm run typecheck
npm run check:lines
npm run build
npm run test:server
```

Database local nằm trong `.data/chat.sqlite`, không đồng bộ với D1 hosted.
Migration hosted chỉ được áp dụng qua quy trình publish của Sites.
Không đặt thông tin đăng nhập hoặc dữ liệu người dùng vào migration.

## Phạm vi hiện tại

`GET /api/health` kiểm tra bảng thiết yếu; trả 503 khi thiếu schema.
POST /api/auth/register, /login, /logout; GET /api/auth/me.
Mỗi endpoint auth thuộc /api/auth.
API server/kênh/chat: xem docs/architecture/community-delivery.md.
Site hiện riêng tư theo quyền truy cập nền tảng.

Đăng nhập username/email + mật khẩu riêng đã triển khai.
Mật khẩu lưu hash có salt; session lưu hash token, cookie HttpOnly/Secure.
PBKDF2-SHA256 100.000 vòng cho Workers; chưa tuyên bố đạt work factor cao hơn.
Username ASCII không dấu; email tùy chọn, chưa có khôi phục mật khẩu.
Local preview: npm run db:migrate, npm run build, npm run dev (127.0.0.1:4173).
Không thể hứa chi phí hosted luôn bằng 0 khi chưa có điều khoản/quota cụ thể.
Chưa thêm dịch vụ trả phí hoặc gói nâng cấp.

Mục tiêu iPhone 7: DOM <=50 tin, cache có trần, thumbnail, viewport fallback.
60 FPS cần đo trên thiết bị thật; chưa có số đo hiệu năng.

## Quy ước mã

Một file một trách nhiệm, tối đa 80 dòng vật lý kể cả comment/dòng trống.
`check:lines` áp dụng cho mã, SQL, JSON tự viết, tài liệu và file cây.
Ngoại lệ máy sinh: package-lock.json, dist/, node_modules/, dữ liệu local.
Không minify mã nguồn để lách giới hạn. Thêm file khi trách nhiệm lớn lên.
