import { DatabaseSync } from "node:sqlite";
export function localDatabase(filename) {
  const database = new DatabaseSync(filename);
  database.exec("PRAGMA foreign_keys=ON");
  return {
    raw: database,
    prepare(sql) {
      let args = [];
      return {
        bind(...values) { args = values; return this; },
        async all() { return { success: true, results: database.prepare(sql).all(...args) }; },
        async first() { return database.prepare(sql).get(...args) || null; },
        async run() { return database.prepare(sql).run(...args); },
        execute() { return database.prepare(sql).run(...args); },
      };
    },
    async batch(statements) {
      database.exec("BEGIN");
      try {
        const results = statements.map((statement) => statement.execute());
        database.exec("COMMIT");
        return results;
      } catch (error) { database.exec("ROLLBACK"); throw error; }
    },
  };
}
