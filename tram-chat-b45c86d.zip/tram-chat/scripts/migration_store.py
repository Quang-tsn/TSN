"""Apply immutable Drizzle SQL journal entries to a SQLite connection."""
import hashlib
import json
from pathlib import Path


def apply_migrations(connection, root):
    connection.execute("PRAGMA foreign_keys = ON")
    connection.execute(
        "CREATE TABLE IF NOT EXISTS __drizzle_migrations "
        "(id INTEGER PRIMARY KEY, hash TEXT NOT NULL, created_at INTEGER NOT NULL)"
    )
    connection.commit()
    journal = json.loads((Path(root) / "meta/_journal.json").read_text())
    applied = dict(connection.execute(
        "SELECT created_at, hash FROM __drizzle_migrations"
    ).fetchall())
    count = 0
    for entry in journal["entries"]:
        sql = (Path(root) / (entry["tag"] + ".sql")).read_text(encoding="utf-8")
        digest = hashlib.sha256(sql.encode()).hexdigest()
        timestamp = entry["when"]
        if timestamp in applied:
            if applied[timestamp] != digest:
                raise ValueError("Applied migration changed: " + entry["tag"])
            continue
        with connection:
            connection.execute("BEGIN")
            for statement in sql.split("--> statement-breakpoint"):
                if statement.strip():
                    connection.execute(statement)
            connection.execute(
                "INSERT INTO __drizzle_migrations(hash, created_at) VALUES (?, ?)",
                (digest, timestamp),
            )
        count += 1
    return count
