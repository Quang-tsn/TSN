import { readdir, readFile } from "node:fs/promises";
import path from "node:path";

const excluded = new Set([
  ".git", "node_modules", "dist", ".data", "__pycache__", ".wrangler",
]);
const extensions = new Set([
  ".ts", ".tsx", ".js", ".mjs", ".py", ".sql", ".css", ".md", ".json", ".txt",
]);
const queue = [process.cwd()];
const violations = [];
let checked = 0;
for (const directory of queue) {
  for (const entry of await readdir(directory, { withFileTypes: true })) {
    const filename = path.join(directory, entry.name);
    if (entry.isDirectory() && !excluded.has(entry.name)) queue.push(filename);
    if (!entry.isFile() || entry.name === "package-lock.json") continue;
    if (!extensions.has(path.extname(entry.name))) continue;
    const source = await readFile(filename, "utf8");
    const lines = source.replace(/\r\n/g, "\n").replace(/\n$/, "").split("\n").length;
    checked += 1;
    if (lines > 80) violations.push(`${path.relative(process.cwd(), filename)}: ${lines}`);
  }
}
if (violations.length) {
  console.error(violations.join("\n"));
  process.exitCode = 1;
} else {
  console.log(`${checked} source/document files meet the 80-line limit.`);
}
