const [base,pack] = process.argv.slice(2);
const key = process.env.COIN_CODE_ADMIN_KEY ?? process.env.EXTRA_CODE_ADMIN_KEY;
const amount = Number(pack);
if (!base || !key || ![50,100,200,500,2000].includes(amount)) {
  throw Error("Cần COIN_CODE_ADMIN_KEY hoặc EXTRA_CODE_ADMIN_KEY và các đối số: <URL Site> <50|100|200|500|2000>.");
}
const {origin,protocol,hostname} = new URL(base);
if (protocol!=="https:" && hostname!=="127.0.0.1") throw Error("Dùng URL HTTPS của Site.");
const headers = { "Content-Type":"application/json",Origin:origin,"X-Tram-Request":"1",Authorization:"Bearer "+key };
if (process.env.TRAM_SITE_ACCESS_TOKEN) headers["OAI-Sites-Authorization"] = "Bearer "+process.env.TRAM_SITE_ACCESS_TOKEN;
const response = await fetch(origin+"/api/coins/issue-code",{
  method:"POST",headers,body:JSON.stringify({amount}),redirect:"error",
});
const payload = await response.json().catch(()=>null);
if (!response.ok || !payload?.code) throw Error(payload?.error || "Không cấp được mã Coins.");
console.log(payload.code);
