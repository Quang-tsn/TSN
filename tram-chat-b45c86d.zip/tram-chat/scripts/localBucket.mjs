import { mkdir, readFile, writeFile, unlink } from "node:fs/promises";
import { basename } from "node:path";
export function localBucket(directory) {
  const path = (key) => directory + "/" + basename(key);
  return {
    async put(key, bytes) {
      await mkdir(directory, { recursive: true });
      await writeFile(path(key), new Uint8Array(bytes));
    },
    async get(key) {
      try { return { body: new Response(await readFile(path(key))).body }; }
      catch (error) { if (error.code === "ENOENT") return null; throw error; }
    },
    async delete(key) {
      try { await unlink(path(key)); }
      catch (error) { if (error.code !== "ENOENT") throw error; }
    },
  };
}
