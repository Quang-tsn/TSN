"""Initialize the development-only database; never connects to hosted D1."""
import sqlite3
from pathlib import Path

from migration_store import apply_migrations

root = Path(__file__).resolve().parent.parent
destination = root / ".data/chat.sqlite"
destination.parent.mkdir(parents=True, exist_ok=True)
with sqlite3.connect(destination) as database:
    count = apply_migrations(database, root / "drizzle")
    errors = database.execute("PRAGMA foreign_key_check").fetchall()
    if errors:
        raise RuntimeError("Foreign key validation failed")
    table_count = database.execute(
        "SELECT count(*) FROM sqlite_master WHERE type = 'table' "
        "AND name NOT LIKE 'sqlite_%' AND name <> '__drizzle_migrations'"
    ).fetchone()[0]
print(f"Applied {count} migration(s); {table_count} product tables: {destination}")
