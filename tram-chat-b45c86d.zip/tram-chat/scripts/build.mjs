import { build } from "esbuild";
import { mkdir, copyFile } from "node:fs/promises";

const client = await build({
  entryPoints: ["src/main.tsx"], outfile: "app.js", bundle: true,
  format: "esm", platform: "browser", target: "safari15", write: false,
  loader: { ".svg": "dataurl" },
  minify: true, define: { "process.env.NODE_ENV": '"production"' },
});
const javascript = client.outputFiles.find((file) => file.path.endsWith(".js"))?.text || "";
const stylesheet = client.outputFiles.find((file) => file.path.endsWith(".css"))?.text || "";
await build({
  entryPoints: ["server/worker.ts"],
  outfile: "dist/server/index.js",
  bundle: true,
  format: "esm",
  platform: "browser",
  target: "es2020",
  sourcemap: false,
  minify: false,
  define: {
    __CLIENT_JS__: JSON.stringify(javascript),
    __CLIENT_CSS__: JSON.stringify(stylesheet),
  },
});
await mkdir("dist/.openai", { recursive: true });
await copyFile(".openai/hosting.json", "dist/.openai/hosting.json");
console.log("Built Worker ESM: dist/server/index.js");

