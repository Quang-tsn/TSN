const [base,tier,period] = process.argv.slice(2);
const key = process.env.EXTRA_CODE_ADMIN_KEY;
if (!base || !["Avip","Svip"].includes(tier) || !["week","month"].includes(period) || !key) {
  console.error("Cần EXTRA_CODE_ADMIN_KEY và các đối số: <URL Site> <Avip|Svip> <week|month>.");
  process.exit(1);
}
const {origin,protocol,hostname} = new URL(base);
if (protocol !== "https:" && hostname !== "127.0.0.1") throw Error("Dùng URL HTTPS của Site.");
const headers = { "Content-Type":"application/json",Origin:origin,"X-Tram-Request":"1",Authorization:`Bearer ${key}` };
if (process.env.TRAM_SITE_ACCESS_TOKEN) headers["OAI-Sites-Authorization"] = `Bearer ${process.env.TRAM_SITE_ACCESS_TOKEN}`;
const result = await fetch(origin + "/api/extra/issue-code",{
  method:"POST",headers,body:JSON.stringify({tier,period}),redirect:"error",
});
const payload = await result.json().catch(()=>null);
if (!result.ok || !payload?.code) throw Error(payload?.error || `Cấp mã thất bại (${result.status}).`);
console.log(payload.code);
