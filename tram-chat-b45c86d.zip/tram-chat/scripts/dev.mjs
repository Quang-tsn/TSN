import { createServer } from "node:http";
import worker from "../dist/server/index.js";
import { localDatabase } from "./localDatabase.mjs";
import { localBucket } from "./localBucket.mjs";
const DB = localDatabase(".data/chat.sqlite");
const BUCKET = localBucket(".data/images");
const server = createServer(async (incoming, outgoing) => {
  const chunks = [];
  for await (const chunk of incoming) chunks.push(chunk);
  const request = new Request("http://127.0.0.1:4173" + incoming.url, {
    method: incoming.method, headers: incoming.headers,
    body: ["GET", "HEAD"].includes(incoming.method) ? undefined : Buffer.concat(chunks),
  });
  try {
    const response = await worker.fetch(request, { DB, BUCKET });
    outgoing.writeHead(response.status, Object.fromEntries(response.headers));
    outgoing.end(Buffer.from(await response.arrayBuffer()));
  } catch { outgoing.writeHead(500); outgoing.end("Local preview failed"); }
});
server.listen(4173, "127.0.0.1", () => console.log("Local: http://127.0.0.1:4173"));
process.on("SIGINT", () => server.close(() => { DB.raw.close(); process.exit(); }));

