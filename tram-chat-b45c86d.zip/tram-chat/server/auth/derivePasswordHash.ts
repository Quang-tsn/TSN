export async function derivePasswordHash(password: string, salt: string,
  iterations = 100000): Promise<string> {
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(password),
    "PBKDF2", false, ["deriveBits"]);
  const bytes = Uint8Array.from(salt.match(/../g)!, (value) => parseInt(value, 16));
  const bits = await crypto.subtle.deriveBits({
    name: "PBKDF2", hash: "SHA-256", iterations, salt: bytes,
  }, key, 256);
  return Array.from(new Uint8Array(bits),
    (value) => value.toString(16).padStart(2, "0")).join("");
}
