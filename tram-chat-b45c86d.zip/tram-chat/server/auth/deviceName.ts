export function deviceName(userAgent: string | null) {
  if (!userAgent) return "";
  const browser = /Edg(?:e|A|iOS)?\//i.test(userAgent) ? "Edge"
    : /FxiOS\/|Firefox\//i.test(userAgent) ? "Firefox"
      : /OPR\/|Opera\//i.test(userAgent) ? "Opera"
        : /CriOS\/|Chrome\//i.test(userAgent) ? "Chrome"
          : /Safari\//i.test(userAgent) ? "Safari" : "Trình duyệt";
  const system = /iPhone|iPad|iPod/i.test(userAgent) ? "iOS"
    : /Android/i.test(userAgent) ? "Android" : /Windows/i.test(userAgent) ? "Windows"
      : /Macintosh/i.test(userAgent) ? "macOS" : /Linux/i.test(userAgent) ? "Linux" : "";
  return system ? browser + " trên " + system : browser;
}
