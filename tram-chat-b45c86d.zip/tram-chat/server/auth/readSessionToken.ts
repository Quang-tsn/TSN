export function readSessionToken(request: Request): string | null {
  const token = (request.headers.get("Cookie") || "").split(";").map((p) => p.trim())
    .find((p) => p.startsWith("__Host-tram_session="))?.split("=")[1];
  return token && /^[a-f0-9]{64}$/.test(token) ? token : null;
}
