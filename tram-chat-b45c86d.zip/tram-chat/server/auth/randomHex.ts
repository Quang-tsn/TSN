export function randomHex(bytes = 32): string {
  return Array.from(crypto.getRandomValues(new Uint8Array(bytes)),
    (value) => value.toString(16).padStart(2, "0")).join("");
}
