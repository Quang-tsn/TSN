export function sessionCookie(token: string, age = 604800): string {
  return `__Host-tram_session=${token}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=${age}`;
}
