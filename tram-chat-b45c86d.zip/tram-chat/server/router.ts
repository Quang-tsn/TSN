import { getHealth } from "./routes/health/getHealth";
import { handleAuth } from "./routes/auth/handleAuth";
import { notFound } from "./http/notFound";
import { serveApp } from "./http/serveApp";
import { jsonResponse } from "./http/jsonResponse";
import { HttpError } from "./http/HttpError";
import { handleCommunity } from "./routes/community/handleCommunity";
import { handleRoom } from "./routes/chat/handleRoom";
import { handleChatAlerts } from "./routes/chat/handleChatAlerts";
import { handleCoins } from "./routes/coins/handleCoins";
import { handleExtra } from "./routes/extra/handleExtra";
import { handleSettings } from "./routes/settings/handleSettings";
import type { Env } from "./types/Env";
export async function route(request: Request, env: Env): Promise<Response> {
  const { pathname } = new URL(request.url);
  try {
    if (request.method === "GET" && pathname === "/api/health") return getHealth(env);
    if (pathname.startsWith("/api/auth/")) return await handleAuth(request, env);
    if (pathname === "/api/settings" || pathname.startsWith("/api/settings/")) return await handleSettings(request, env);
    if (pathname === "/api/servers" || pathname.startsWith("/api/servers/")) {
      return await handleCommunity(request, env);
    }
    if (pathname.startsWith("/api/rooms/")) return await handleRoom(request, env);
    if (pathname === "/api/chat-alerts") return await handleChatAlerts(request,env);
    if (pathname === "/api/coins" || pathname.startsWith("/api/coins/")) return await handleCoins(env,request);
    if (pathname === "/api/extra" || pathname.startsWith("/api/extra/")) return await handleExtra(request, env);
    if (request.method === "GET" &&
        ["/", "/login", "/register", "/settings", "/extraaccount", "/coins", "/assets/app.js", "/assets/app.css"].includes(pathname)) {
      return serveApp(pathname);
    }
    return notFound();
  } catch (error) {
    if (error instanceof HttpError) return jsonResponse({ error: error.message }, error.status);
    return jsonResponse({ error: "Chưa kết nối được. Thử lại sau nhé." }, 503);
  }
}
