import type { Database } from "../../types/Database";
import type { Credential } from "../../types/Account";
export function findLoginIdentity(db: Database, identity: string) {
  const column = identity.includes("@") ? "email" : "username";
  return db.prepare(`SELECT u.id,u.username,u.display_name,c.password_hash,c.salt,c.iterations
    FROM users u JOIN password_credentials c ON c.user_id=u.id
    WHERE u.${column}=?`).bind(identity).first<Credential>();
}
