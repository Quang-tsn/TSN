import type { Database } from "../../types/Database";
import type { ChatAlerts } from "../../../src/types/ChatAlerts";

export async function readChatAlerts(db:Database,userId:string,after:number|null,activeRoom:string) {
  const visible = `FROM server_members sm JOIN rooms r ON r.server_id=sm.server_id
    JOIN room_events e ON e.room_id=r.id
    WHERE sm.user_id=? AND r.kind='channel' AND e.kind='message.created'`;
  if (after === null) {
    const newest = await db.prepare(`SELECT MAX(e.sequence) cursor ${visible}`)
      .bind(userId).first<{cursor:number|null}>();
    return {cursor:newest?.cursor ?? 0,priority:0};
  }
  const result = await db.prepare(`SELECT COALESCE(MAX(e.sequence),?) cursor,
    COALESCE(MAX(CASE WHEN m.author_id<>? AND m.deleted_at IS NULL AND e.created_at>=? THEN
      CASE WHEN m.mention_all=1 OR mm.user_id IS NOT NULL THEN 2 WHEN r.id=? THEN 1 ELSE 0 END
      ELSE 0 END),0) priority
    FROM server_members sm JOIN rooms r ON r.server_id=sm.server_id
    JOIN room_events e ON e.room_id=r.id
    JOIN messages m ON m.id=e.message_id
    LEFT JOIN message_mentions mm ON mm.message_id=m.id AND mm.user_id=?
    WHERE sm.user_id=? AND r.kind='channel' AND e.kind='message.created' AND e.sequence>?`)
    .bind(after,userId,Date.now()-120000,activeRoom,userId,userId,after).first<ChatAlerts>();
  return result ?? {cursor:after,priority:0};
}
