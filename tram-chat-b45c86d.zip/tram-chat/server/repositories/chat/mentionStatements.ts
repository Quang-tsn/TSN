import type { Database } from "../../types/Database";

export function mentionStatements(db: Database,messageId:string,authorId:string,usernames:string[]) {
  if (!usernames.length) return [];
  return [db.prepare(`INSERT OR IGNORE INTO message_mentions(message_id,user_id)
    SELECT m.id,u.id FROM messages m JOIN rooms r ON r.id=m.room_id
    JOIN json_each(?) names JOIN users u ON u.username=names.value
    JOIN server_members sm ON sm.server_id=r.server_id AND sm.user_id=u.id
    WHERE m.id=? AND u.id<>?`).bind(JSON.stringify(usernames),messageId,authorId)];
}
