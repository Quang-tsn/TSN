import type { Database } from "../../types/Database";
import { requireRoom } from "../../guards/requireRoom";
import { HttpError } from "../../http/HttpError";
export async function listMessages(db: Database, roomId: string, userId: string, before: string | null) {
  await requireRoom(db, roomId, userId);
  let cursor: { created_at: number; id: string } | null = null;
  if (before) {
    cursor = await db.prepare("SELECT id,created_at FROM messages WHERE id=? AND room_id=?")
      .bind(before, roomId).first();
    if (!cursor) throw new HttpError(400, "Mốc tin nhắn không hợp lệ.");
  }
  const rows = await db.prepare(`SELECT m.id,m.content,m.created_at,m.author_id,m.client_nonce,
    u.display_name,u.username,f.id image_id,f.width image_width,f.height image_height,
    bookmark.message_id IS NOT NULL is_saved,bookmark.folder_id saved_folder_id,
    anim.giphy_id, anim.kind animation_kind, avatar.object_key IS NOT NULL has_avatar, avatar.mime avatar_mime,
    banner.object_key IS NOT NULL has_background, banner.mime background_mime,
    (SELECT g.tier FROM extra_grants g WHERE g.owner_id=u.id AND g.expires_at>? AND g.starts_at<=?
      ORDER BY CASE g.tier WHEN 'Svip' THEN 3 WHEN 'Avip' THEN 2 ELSE 1 END DESC LIMIT 1) tier,
    q.id reply_id, CASE WHEN q.deleted_at IS NULL THEN ru.display_name END reply_author,
    CASE WHEN q.deleted_at IS NULL THEN substr(q.content,1,140) END reply_content
    FROM messages m JOIN users u ON u.id=m.author_id
    LEFT JOIN extra_saved bookmark ON bookmark.message_id=m.id AND bookmark.user_id=?
    LEFT JOIN extra_animations anim ON anim.message_id=m.id
    LEFT JOIN extra_profile_assets avatar ON avatar.user_id=u.id AND avatar.kind='avatar'
    LEFT JOIN extra_profile_assets banner ON banner.user_id=u.id AND banner.kind='background'
    LEFT JOIN message_attachments a ON a.message_id=m.id AND a.position=0
    LEFT JOIN files f ON f.id=a.file_id AND f.state='ready'
    LEFT JOIN messages q ON q.id=m.reply_to_id AND q.room_id=m.room_id
    LEFT JOIN users ru ON ru.id=q.author_id
    WHERE m.room_id=? AND m.deleted_at IS NULL AND
    (? IS NULL OR m.created_at<? OR (m.created_at=? AND m.id<?))
    AND EXISTS (SELECT 1 FROM server_members sm JOIN rooms r ON r.server_id=sm.server_id
    WHERE r.id=m.room_id AND sm.user_id=?)
    ORDER BY m.created_at DESC,m.id DESC LIMIT 51`)
    .bind(Date.now(),Date.now(),userId,roomId, cursor?.id || null, cursor?.created_at || 0,
      cursor?.created_at || 0, cursor?.id || "", userId).all();
  return { messages: rows.results.slice(0, 50).reverse(), hasMore: rows.results.length > 50 };
}
