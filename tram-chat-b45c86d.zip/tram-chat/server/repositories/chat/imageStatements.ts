import type { Database } from "../../types/Database";
import type { storeImage } from "../../services/chat/storeImage";
export function imageStatements(db: Database, image: Awaited<ReturnType<typeof storeImage>>,
  messageId: string, userId: string, now: number) {
  return [
    db.prepare(`INSERT INTO files(id,uploader_id,object_key,original_name,mime_type,
      byte_size,width,height,state,created_at)
      SELECT ?,?,?,?,?,?,?,?,'ready',? FROM messages WHERE id=?`)
      .bind(image.id, userId, image.key, "Ảnh đính kèm", image.mime, image.bytes,
        image.width, image.height, now, messageId),
    db.prepare(`INSERT INTO message_attachments(message_id,file_id)
      SELECT ?,id FROM files WHERE id=?`).bind(messageId, image.id),
  ];
}
