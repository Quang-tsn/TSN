import type { Database } from "../../types/Database";
export async function listServers(db: Database, userId: string) {
  const rows = await db.prepare(`SELECT s.id,s.name,s.description,s.verified,s.is_public,m.role FROM servers s
    JOIN server_members m ON m.server_id=s.id WHERE m.user_id=?
    ORDER BY m.joined_at,s.id LIMIT 100`).bind(userId).all();
  return rows.results;
}
