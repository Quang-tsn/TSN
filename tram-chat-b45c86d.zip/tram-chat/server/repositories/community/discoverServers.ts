import type { Database } from "../../types/Database";
import { discoveryName } from "../../validators/community/discoveryName";

export async function discoverServers(db: Database, user: string, input: string) {
  const query = discoveryName(input.slice(0,100));
  const rows = await db.prepare(`SELECT s.id,s.name,s.description,s.verified,m.user_id IS NOT NULL AS joined
    FROM servers s LEFT JOIN server_members m ON m.server_id=s.id AND m.user_id=?
    WHERE s.is_public=1 AND instr(s.search_name,?)>0 ORDER BY s.verified DESC,s.created_at DESC,s.id LIMIT 24`)
    .bind(user,query).all();
  return rows.results;
}
