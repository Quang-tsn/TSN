import type { Database } from "../../types/Database";

export async function readTableNames(db: Database): Promise<string[]> {
  const query = "SELECT name FROM sqlite_master WHERE type = 'table'";
  const result = await db.prepare(query).all<{ name: string }>();
  if (!result.success) throw new Error("Database query failed");
  return result.results.map(({ name }) => name);
}
