import type { Database } from "./Database";
import type { Bucket } from "./Bucket";

export interface Env {
  DB: Database;
  BUCKET?: Bucket;
  EXTRA_CODE_ADMIN_KEY?: string;
  COIN_CODE_ADMIN_KEY?: string;
  GIPHY_API_KEY?: string;
}
