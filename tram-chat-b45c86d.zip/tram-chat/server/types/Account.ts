export interface Account { id: string; username: string; display_name: string; }
export interface Credential extends Account {
  password_hash: string;
  salt: string;
  iterations: number;
}
