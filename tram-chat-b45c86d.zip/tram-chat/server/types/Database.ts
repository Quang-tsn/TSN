export interface Statement {
  bind(...values: unknown[]): Statement;
  all<T>(): Promise<{ results: T[]; success: boolean }>;
  first<T>(): Promise<T | null>;
  run(): Promise<unknown>;
}
export interface Database {
  prepare(sql: string): Statement;
  batch(statements: Statement[]): Promise<unknown[]>;
}
