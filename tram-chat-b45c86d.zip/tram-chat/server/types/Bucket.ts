export interface Bucket {
  put(key: string, value: ArrayBuffer): Promise<unknown>;
  get(key: string): Promise<{ body: ReadableStream<Uint8Array> } | null>;
  delete(key: string): Promise<unknown>;
}
