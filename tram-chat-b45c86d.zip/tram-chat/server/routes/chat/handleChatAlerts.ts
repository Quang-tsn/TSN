import type { Env } from "../../types/Env";
import { requireAccount } from "../../guards/requireAccount";
import { jsonResponse } from "../../http/jsonResponse";
import { HttpError } from "../../http/HttpError";
import { readChatAlerts } from "../../repositories/chat/readChatAlerts";

export async function handleChatAlerts(request:Request,env:Env) {
  if (request.method !== "GET") throw new HttpError(404,"Không tìm thấy thông báo chat.");
  const user = await requireAccount(env.DB,request);
  const params = new URL(request.url).searchParams;
  const input = params.get("after");
  const after = input === null ? null : Number(input);
  const room = params.get("room") || "";
  if ((after !== null && (!/^\d+$/.test(input!) || !Number.isSafeInteger(after))) || room.length > 128) {
    throw new HttpError(400,"Mốc thông báo không hợp lệ.");
  }
  return jsonResponse(await readChatAlerts(env.DB,user.id,after,room));
}
