import type { Env } from "../../types/Env";
import { requireAccount } from "../../guards/requireAccount";
import { readAuthBody } from "../../validators/auth/readAuthBody";
import { jsonResponse } from "../../http/jsonResponse";
import { HttpError } from "../../http/HttpError";
import { changeChannel } from "../../services/community/changeChannel";
import { listMessages } from "../../repositories/chat/listMessages";
import { sendMessage } from "../../services/chat/sendMessage";
import { readImagePost } from "../../validators/chat/readImagePost";
import { getMessageImage } from "../../services/chat/getMessageImage";
import { freeChatImage,extraChatImage } from "../../../src/shared/chatImageLimits";
import { readActiveGrant } from "../../services/extra/readActiveGrant";
export async function handleRoom(request: Request, env: Env) {
  const user = await requireAccount(env.DB, request);
  const url = new URL(request.url), path = url.pathname.split("/").filter(Boolean);
  const id = path[2], action = path[3];
  if (action === "images" && path.length === 5 && request.method === "GET") {
    return getMessageImage(env, id, path[4], user.id);
  }
  if (action === "messages" && path.length === 4) {
    if (request.method === "GET") return jsonResponse(
      await listMessages(env.DB, id, user.id, url.searchParams.get("before")));
    if (request.method === "POST") {
      const multipart = request.headers.get("Content-Type")?.startsWith("multipart/form-data;");
      const limits = multipart && await readActiveGrant(env.DB,user.id,Date.now()) ? extraChatImage : freeChatImage;
      const data = multipart ? await readImagePost(request,limits.megabytes) : await readAuthBody(request);
      return jsonResponse(await sendMessage(env.DB, id, user.id, data, env.BUCKET,limits.pixels), 201);
    }
  }
  if (path.length === 3 && ["PATCH", "DELETE"].includes(request.method)) {
    return jsonResponse(await changeChannel(env.DB, id, user.id,
      await readAuthBody(request), request.method === "DELETE"));
  }
  throw new HttpError(404, "Không tìm thấy thao tác.");
}
