import type { Env } from "../../types/Env";
import { HttpError } from "../../http/HttpError";
import { jsonResponse } from "../../http/jsonResponse";
import { readAuthBody } from "../../validators/auth/readAuthBody";
import { readSettingsDetails } from "../../services/settings/readSettingsDetails";
import { settingsIdentity } from "../../services/settings/settingsIdentity";

export async function handleSettings(request: Request, env: Env) {
  const path = new URL(request.url).pathname;
  if (request.method === "GET" && path === "/api/settings") {
    return jsonResponse(await readSettingsDetails(env.DB,request));
  }
  if (request.method !== "POST") throw new HttpError(404,"Không tìm thấy mục cài đặt.");
  const data = await readAuthBody(request);
  const account = await settingsIdentity(env.DB,request);
  if (path === "/api/settings/profile") {
    const name = typeof data.displayName === "string" ? data.displayName.trim() : "";
    if (!name || name.length > 64 || /[\u0000-\u001f\u007f]/.test(name)) {
      throw new HttpError(400,"Tên hiển thị phải có từ 1 đến 64 ký tự trên một dòng.");
    }
    await env.DB.prepare("UPDATE users SET display_name=?,updated_at=? WHERE id=?")
      .bind(name,Date.now(),account.userId).run();
    return jsonResponse({display_name:name});
  }
  if (path === "/api/settings/revoke-session") {
    if (typeof data.id !== "string" || !/^[a-f0-9-]{36}$/.test(data.id) || data.id === account.sessionId) {
      throw new HttpError(400,"Chọn một phiên đăng nhập khác.");
    }
    await env.DB.prepare("UPDATE sessions SET revoked_at=? WHERE id=? AND user_id=? AND revoked_at IS NULL")
      .bind(Date.now(),data.id,account.userId).run();
    return jsonResponse({ok:true});
  }
  throw new HttpError(404,"Không tìm thấy mục cài đặt.");
}
