import { jsonResponse } from "../../http/jsonResponse";
import { getDatabaseHealth } from "../../services/health/getDatabaseHealth";
import type { Env } from "../../types/Env";

export async function getHealth(env: Env): Promise<Response> {
  const ready = await getDatabaseHealth(env.DB);
  return jsonResponse({
    app: "Trạm",
    phase: "community-chat",
    database: ready ? "ready" : "unavailable",
    chat: "text-polling",
  }, ready ? 200 : 503);
}
