import type { Env } from "../../types/Env";
import { requireAccount } from "../../guards/requireAccount";
import { getSessionAccount } from "../../services/auth/getCurrentSession";
import { HttpError } from "../../http/HttpError";
import { jsonResponse } from "../../http/jsonResponse";
import { readAuthBody } from "../../validators/auth/readAuthBody";
import { readExtraStatus } from "../../services/extra/readExtraStatus";
import { trial } from "../../services/extra/trial";
import { createExtraAccount } from "../../services/extra/createExtraAccount";
import { switchExtraAccount } from "../../services/extra/switchExtraAccount";
import { listExtraAccounts } from "../../services/extra/listExtraAccounts";
import { redeemCode } from "../../services/extra/redeemCode";
import { handleSavedLibrary } from "./handleSavedLibrary";
import { getProfileAsset, saveProfileAsset } from "../../services/extra/profileAsset";
import { trialWait } from "../../../src/shared/extraPlans";
import { openTrialAd } from "./openTrialAd";
import { issueCode } from "./issueCode";
import { canSwitchGroup } from "../../services/auth/canSwitchGroup";
export async function handleExtra(request: Request, env: Env) {
  const url = new URL(request.url), [, , , action, assetUser, kind] = url.pathname.split("/");
  if (action === "issue-code" && request.method === "POST") return issueCode(env,request);
  if (action === "trial-open" && request.method === "POST") return openTrialAd(request,env);
  if (request.method === "GET" && !action) {
    const user = await getSessionAccount(env.DB,request);
    const status = user && await readExtraStatus(env.DB,user.id);
    const canSwitch = !!(status && user && await canSwitchGroup(env.DB,request,user.id,status.owner));
    const accounts = status && canSwitch ? await listExtraAccounts(env.DB,status.owner,status.slots) : null;
    const images = user && (await env.DB.prepare(
      `SELECT kind,mime FROM extra_profile_assets WHERE user_id=? AND
      (?='Svip' OR (?<>'' AND kind='avatar' AND mime<>'image/gif'))`)
      .bind(user.id,status?.tier ?? "",status?.tier ?? "").all<{ kind: string }>()).results;
    const pending = user && await env.DB.prepare("SELECT started_at FROM extra_trials WHERE owner_id=? AND started_at>?")
      .bind(user.id,Date.now()-900000).first<{ started_at: number }>();
    return jsonResponse({ status, user, accounts, images, canSwitch,
      giphyKey: status?.tier ? env.GIPHY_API_KEY || null : null,
      trialReadyAt: pending ? pending.started_at + trialWait : null });
  }
  if (action === "switch" && request.method === "POST") {
    const user = await getSessionAccount(env.DB,request);
    if (!user) throw new HttpError(401,"Đăng nhập để chuyển tài khoản.");
    return switchExtraAccount(env.DB,request,user.id,(await readAuthBody(request)).target);
  }
  if (action === "redeem" && request.method === "POST") {
    const user = await getSessionAccount(env.DB,request);
    if (!user) throw new HttpError(401,"Phiên đăng nhập đã hết. Đăng nhập lại nhé.");
    const data = await readAuthBody(request);
    const grant = await redeemCode(env.DB,user.id,data.code,data.tier);
    return jsonResponse({ ...grant,status:await readExtraStatus(env.DB,user.id) });
  }
  const user = await requireAccount(env.DB,request);
  if (action === "profile" && assetUser && kind) {
    if (request.method === "GET" && ["avatar","background"].includes(kind)) {
      return getProfileAsset(env,user.id,assetUser,kind);
    }
    if (request.method === "POST" && assetUser === user.id) {
      return jsonResponse(await saveProfileAsset(env,request,user.id,kind));
    }
  }
  if (action === "saved" || action === "save" || action === "unsave" || action?.startsWith("saved-")) {
    return handleSavedLibrary(env.DB,request,user.id,action);
  }
  if (request.method !== "POST") throw new HttpError(404,"Không tìm thấy thao tác.");
  const data = await readAuthBody(request);
  switch (action) {
    case "trial-claim": return jsonResponse(await trial(env.DB,user.id,true));
    case "create": return jsonResponse(await createExtraAccount(env.DB,request,user.id,data.username),201);
    default: throw new HttpError(404,"Không tìm thấy thao tác.");
  }
}
