import type { Database } from "../../types/Database";
import { HttpError } from "../../http/HttpError";
import { jsonResponse } from "../../http/jsonResponse";
import { readAuthBody } from "../../validators/auth/readAuthBody";
import { requireExtra } from "../../services/extra/requireExtra";
import { createSavedFolder,listSavedFolders } from "../../services/extra/savedFolders";
import { moveSavedMessage } from "../../services/extra/moveSavedMessage";
import { savedCatalog } from "../../services/extra/savedCatalog";
import { savedMessages,saveMessage } from "../../services/extra/savedMessages";

export async function handleSavedLibrary(db: Database,request: Request,user: string,action: string) {
  if (request.method === "GET") {
    if (action === "saved") return jsonResponse(await savedMessages(db,user,new URL(request.url).searchParams));
    if (action === "saved-catalog") {
      await requireExtra(db,user);
      return jsonResponse(await savedCatalog(db,user));
    }
    if (action === "saved-folders") {
      await requireExtra(db,user);
      return jsonResponse({folders:await listSavedFolders(db,user)});
    }
  } else if (request.method === "POST") {
    const data = await readAuthBody(request);
    if (action === "save" || action === "unsave") {
      return jsonResponse(await saveMessage(db,user,data.id,action === "unsave",data.folderId));
    }
    if (action === "saved-folders" || action === "saved-move") {
      await requireExtra(db,user);
      return action === "saved-folders" ? jsonResponse(await createSavedFolder(db,user,data.name),201)
        : jsonResponse(await moveSavedMessage(db,user,data.id,data.folderId));
    }
  }
  throw new HttpError(404,"Không tìm thấy thao tác lưu tin.");
}
