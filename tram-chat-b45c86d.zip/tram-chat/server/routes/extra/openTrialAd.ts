import type { Env } from "../../types/Env";
import { requireAccount } from "../../guards/requireAccount";
import { HttpError } from "../../http/HttpError";
import { trial } from "../../services/extra/trial";

export async function openTrialAd(request: Request, env: Env) {
  if (request.headers.get("Origin") !== new URL(request.url).origin) {
    throw new HttpError(403, "Mở quảng cáo từ trang ExtraAccount của Trạm.");
  }
  const user = await requireAccount(env.DB,request);
  await trial(env.DB,user.id,false);
  return new Response(null, {
    status: 303,
    headers: { Location: "https://lunor.wtf/", "Cache-Control": "no-store",
      "Referrer-Policy": "no-referrer" },
  });
}
