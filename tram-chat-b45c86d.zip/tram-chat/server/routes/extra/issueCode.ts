import type { Env } from "../../types/Env";
import { HttpError } from "../../http/HttpError";
import { jsonResponse } from "../../http/jsonResponse";
import { readAuthBody } from "../../validators/auth/readAuthBody";
import { codeDigest } from "../../services/extra/codeDigest";
import { generateCode } from "../../services/extra/generateCode";
import { requireCodeIssuer } from "../../guards/requireCodeIssuer";

export async function issueCode(env: Env, request: Request) {
  await requireCodeIssuer(env.EXTRA_CODE_ADMIN_KEY,request);

  const { tier,period } = await readAuthBody(request);
  if ((tier !== "Avip" && tier !== "Svip") || (period !== "week" && period !== "month")) {
    throw new HttpError(400,"Chọn Avip hoặc Svip và kỳ hạn 7 hoặc 30 ngày.");
  }
  const code = generateCode();
  await env.DB.prepare("INSERT INTO extra_codes (digest,tier,period,created_at) VALUES (?,?,?,?)")
    .bind(await codeDigest(code),tier,period,Date.now()).run();
  return jsonResponse({ code,tier,period },201);
}
