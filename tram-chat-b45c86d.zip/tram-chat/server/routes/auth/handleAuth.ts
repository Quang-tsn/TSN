import type { Env } from "../../types/Env";
import { jsonResponse } from "../../http/jsonResponse";
import { HttpError } from "../../http/HttpError";
import { readAuthBody } from "../../validators/auth/readAuthBody";
import { validateIdentity } from "../../validators/auth/validateIdentity";
import { enforceRateLimit } from "../../services/auth/enforceRateLimit";
import { registerAccount } from "../../services/auth/registerAccount";
import { loginAccount } from "../../services/auth/loginAccount";
import { createSession } from "../../services/auth/createSession";
import { getCurrentSession } from "../../services/auth/getCurrentSession";
import { logoutAccount } from "../../services/auth/logoutAccount";
import { sessionCookie } from "../../auth/sessionCookie";
import { requireSwitchGroup } from "../../services/extra/requireSwitchGroup";
import { attachExtraAccount } from "../../services/extra/attachExtraAccount";
import { deviceName } from "../../auth/deviceName";
export async function handleAuth(request: Request, env: Env): Promise<Response> {
  const path = new URL(request.url).pathname;
  if (request.method === "GET" && path === "/api/auth/me") {
    return jsonResponse({ user: await getCurrentSession(env.DB, request) });
  }
  if (request.method !== "POST" ||
      !["/api/auth/login", "/api/auth/register", "/api/auth/logout"].includes(path)) {
    throw new HttpError(404, "Không tìm thấy đường dẫn này.");
  }
  const data = await readAuthBody(request);
  if (path.endsWith("/logout")) {
    await logoutAccount(env.DB, request);
    const response = jsonResponse({ ok: true });
    response.headers.set("Set-Cookie", sessionCookie("", 0));
    return response;
  }
  const registering = path.endsWith("/register");
  const identity = validateIdentity(registering ? data.username : data.identity, registering);
  await enforceRateLimit(env.DB, request, identity);
  const group = data.addAccount === true ? await requireSwitchGroup(env.DB,request) : undefined;
  const user = registering ? await registerAccount(env.DB, data, group)
    : await loginAccount(env.DB, identity, data.password);
  if (group && !registering) await attachExtraAccount(env.DB,user.id,group.owner,group.slots);
  const token = await createSession(env.DB,user.id,group?.owner,deviceName(request.headers.get("User-Agent")));
  const response = jsonResponse({ user }, registering ? 201 : 200);
  response.headers.set("Set-Cookie", sessionCookie(token));
  return response;
}
