import type { Env } from "../../types/Env";
import { HttpError } from "../../http/HttpError";
import { jsonResponse } from "../../http/jsonResponse";
import { readAuthBody } from "../../validators/auth/readAuthBody";
import { requireAccount } from "../../guards/requireAccount";
import { requireCodeIssuer } from "../../guards/requireCodeIssuer";
import { normalizeExtraCode } from "../../../src/shared/normalizeExtraCode";
import { isExtraCode } from "../../../src/shared/isExtraCode";
import { coinDaily } from "../../services/coins/coinDaily";
import { coinHistory } from "../../services/coins/coinHistory";
import { coinGiftNotices } from "../../services/coins/coinGiftNotices";
import { coinGift } from "../../services/coins/coinGift";
import { coinExchange } from "../../services/coins/coinExchange";
import { coinBalance } from "../../services/coins/coinBalance";
import { issueCoinPurchase,redeemCoinPurchase } from "../../services/coins/coinPurchase";

export async function handleCoins(env:Env,request:Request) {
  const url = new URL(request.url);
  const action = url.pathname.slice("/api/coins".length);
  const db = env.DB;
  if (request.method==="POST" && action==="/issue-code") {
    await requireCodeIssuer(env.COIN_CODE_ADMIN_KEY ?? env.EXTRA_CODE_ADMIN_KEY,request);
    return jsonResponse(await issueCoinPurchase(db,(await readAuthBody(request)).amount),201);
  }
  const user = (await requireAccount(db,request)).id;
  if (request.method==="GET") {
    if (!action) return jsonResponse({balance:await coinBalance(db,user)});
    if (action==="/history") return jsonResponse(await coinHistory(db,user,url.searchParams));
    if (action==="/gift-notices") return jsonResponse(await coinGiftNotices(db,user));
  }
  if (request.method==="POST") {
    const data = await readAuthBody(request);
    if (action==="/daily-code") return jsonResponse(await coinDaily(db,user));
    if (action==="/daily" || action==="/redeem") {
      const code = typeof data.code==="string" ? normalizeExtraCode(data.code) : "";
      if (!isExtraCode(code)) throw new HttpError(400,"Nhập mã gồm 12 ký tự, có chữ và số.");
      const reward = action==="/daily" ? await coinDaily(db,user,code) : await redeemCoinPurchase(db,user,code);
      return jsonResponse({...reward,balance:await coinBalance(db,user)});
    }
    if (action==="/gift" || action==="/exchange") {
      if (typeof data.nonce!=="string" || !/^[a-z0-9-]{16,64}$/i.test(data.nonce)) {
        throw new HttpError(400,"Yêu cầu giao dịch không hợp lệ.");
      }
      const id = "coin:"+user+":"+data.nonce;
      if (action==="/gift") await coinGift(db,user,id,data);
      else await coinExchange(db,user,id,data);
      return jsonResponse({balance:await coinBalance(db,user)});
    }
  }
  throw new HttpError(404,"Không tìm thấy thao tác Tamper Coins.");
}
