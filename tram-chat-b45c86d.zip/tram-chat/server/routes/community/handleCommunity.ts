import type { Env } from "../../types/Env";
import { requireAccount } from "../../guards/requireAccount";
import { readAuthBody } from "../../validators/auth/readAuthBody";
import { jsonResponse } from "../../http/jsonResponse";
import { HttpError } from "../../http/HttpError";
import { listServers } from "../../repositories/community/listServers";
import { createServer } from "../../services/community/createServer";
import { getServerDetail } from "../../services/community/getServerDetail";
import { createChannel } from "../../services/community/createChannel";
import { createInvite } from "../../services/community/createInvite";
import { joinServer } from "../../services/community/joinServer";
import { discoverServers } from "../../repositories/community/discoverServers";
import { joinPublicServer } from "../../services/community/joinPublicServer";
import { setServerVisibility } from "../../services/community/setServerVisibility";
export async function handleCommunity(request: Request, env: Env) {
  const user = await requireAccount(env.DB, request);
  const url = new URL(request.url);
  const path = url.pathname.split("/").filter(Boolean);
  const id = path[2], action = path[3], method = request.method;
  if (path.length === 2 && method === "GET") {
    return jsonResponse({ servers: await listServers(env.DB, user.id) });
  }
  if (id === "discover" && path.length === 3 && method === "GET") {
    return jsonResponse({servers:await discoverServers(env.DB,user.id,url.searchParams.get("q") || "")});
  }
  if (path.length === 3 && method === "GET") {
    return jsonResponse(await getServerDetail(env.DB, id, user.id));
  }
  if (method !== "POST") throw new HttpError(404, "Không tìm thấy thao tác.");
  const data = await readAuthBody(request);
  if (path.length === 2) return jsonResponse(await createServer(env.DB, user.id, data.name, data.isPublic === true), 201);
  if (id === "join" && path.length === 3) {
    return jsonResponse(await joinServer(env.DB, user.id, data.code));
  }
  if (action === "channels" && path.length === 4) {
    return jsonResponse(await createChannel(env.DB, id, user.id, data.name), 201);
  }
  if (action === "invites" && path.length === 4) {
    return jsonResponse(await createInvite(env.DB, id, user.id), 201);
  }
  if (action === "join-public" && path.length === 4) return jsonResponse(await joinPublicServer(env.DB,user.id,id));
  if (action === "visibility" && path.length === 4) return jsonResponse(await setServerVisibility(env.DB,user.id,id,data.isPublic));
  throw new HttpError(404, "Không tìm thấy thao tác.");
}
