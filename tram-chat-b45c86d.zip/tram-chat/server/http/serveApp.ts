declare const __CLIENT_JS__: string;
declare const __CLIENT_CSS__: string;
export function serveApp(path: string): Response {
  if (path === "/assets/app.js" || path === "/assets/app.css") {
    return new Response(path.endsWith(".js") ? __CLIENT_JS__ : __CLIENT_CSS__, {
      headers: { "Content-Type": path.endsWith(".js")
        ? "text/javascript; charset=utf-8" : "text/css; charset=utf-8",
        "Cache-Control": "no-cache", "X-Content-Type-Options": "nosniff" },
    });
  }
  return new Response(`<!doctype html><html lang="vi"><head>
    <meta charset="utf-8"><meta name="viewport"
    content="width=device-width,initial-scale=1,viewport-fit=cover">
    <meta name="theme-color" content="#1E1F22"><title>Trạm — Chat & Cộng đồng</title>
    <meta name="description" content="Trạm là nơi lập cộng đồng, trò chuyện theo kênh và chia sẻ ảnh với hội bạn.">
    <link rel="stylesheet" href="/assets/app.css"></head><body>
    <div id="root"></div><script type="module" src="/assets/app.js"></script>
    </body></html>`, { headers: {
      "Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-store",
      "Content-Security-Policy": [
        "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data: blob: https://*.giphy.com",
        "connect-src 'self' https://api.giphy.com; frame-src https:; media-src 'self' https:",
        "base-uri 'none'; form-action 'self' https://lunor.wtf",
      ].join("; "),
      "X-Content-Type-Options": "nosniff", "Referrer-Policy": "same-origin",
    } });
}
