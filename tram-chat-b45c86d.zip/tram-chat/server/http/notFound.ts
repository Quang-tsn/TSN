import { jsonResponse } from "./jsonResponse";

export function notFound(): Response {
  return jsonResponse({ error: "Không tìm thấy đường dẫn này." }, 404);
}
