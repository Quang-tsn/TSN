import type { Database } from "../../types/Database";
import { requireMembership } from "../../guards/requireMembership";
import { randomHex } from "../../auth/randomHex";
import { hashSessionToken } from "../../auth/hashSessionToken";
export async function createInvite(db: Database, serverId: string, userId: string) {
  await requireMembership(db, serverId, userId, true);
  const code = randomHex(16), now = Date.now();
  await db.prepare(`INSERT INTO server_invites
    (id,server_id,code_hash,created_by,created_at,expires_at)
    SELECT ?,?,?,?,?,? WHERE EXISTS
    (SELECT 1 FROM server_members WHERE server_id=? AND user_id=? AND role IN ('owner','admin'))`)
    .bind(crypto.randomUUID(), serverId, await hashSessionToken(code), userId,
      now, now + 604800000, serverId, userId).run();
  return { code, expires_at: now + 604800000 };
}
