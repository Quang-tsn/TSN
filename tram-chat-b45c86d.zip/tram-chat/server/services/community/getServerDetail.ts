import type { Database } from "../../types/Database";
import { requireMembership } from "../../guards/requireMembership";
export async function getServerDetail(db: Database, id: string, userId: string) {
  const member = await requireMembership(db, id, userId);
  const server = await db.prepare("SELECT id,name,description,verified,is_public FROM servers WHERE id=?")
    .bind(id).first();
  const channels = await db.prepare(`SELECT id,name,topic FROM rooms
    WHERE server_id=? AND kind='channel' ORDER BY position,created_at,id LIMIT 200`)
    .bind(id).all();
  const members = await db.prepare(`SELECT u.id,u.username,u.display_name,m.role
    FROM server_members m JOIN users u ON u.id=m.user_id WHERE m.server_id=?
    ORDER BY CASE m.role WHEN 'owner' THEN 0 WHEN 'admin' THEN 1 ELSE 2 END,u.username LIMIT 100`)
    .bind(id).all();
  return { server, role: member.role, channels: channels.results, members: members.results };
}
