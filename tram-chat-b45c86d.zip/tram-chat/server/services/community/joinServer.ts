import type { Database } from "../../types/Database";
import { HttpError } from "../../http/HttpError";
import { hashSessionToken } from "../../auth/hashSessionToken";
export async function joinServer(db: Database, userId: string, value: unknown) {
  const code = typeof value === "string" ? value.trim() : "";
  if (!/^[a-f0-9]{32}$/.test(code)) throw new HttpError(400, "Mã mời chưa đúng.");
  const now = Date.now();
  const invite = await db.prepare(`SELECT id,server_id FROM server_invites
    WHERE code_hash=? AND revoked_at IS NULL AND (expires_at IS NULL OR expires_at>?)`)
    .bind(await hashSessionToken(code), now).first<{ id: string; server_id: string }>();
  if (!invite) throw new HttpError(404, "Mã mời không tồn tại hoặc đã hết hạn.");
  const existing = await db.prepare("SELECT 1 FROM server_members WHERE server_id=? AND user_id=?")
    .bind(invite.server_id, userId).first();
  if (existing) return { id: invite.server_id };
  const used = await db.prepare("SELECT 1 FROM invite_uses WHERE invite_id=? AND user_id=?")
    .bind(invite.id, userId).first();
  if (used) throw new HttpError(409, "Mã này đã được tài khoản của bạn sử dụng.");
  await db.batch([
    db.prepare(`INSERT OR IGNORE INTO invite_uses(invite_id,user_id,used_at)
      SELECT id,?,? FROM server_invites WHERE id=? AND revoked_at IS NULL
      AND (expires_at IS NULL OR expires_at>?) AND (max_uses IS NULL OR use_count<max_uses)`)
      .bind(userId, now, invite.id, now),
    db.prepare(`UPDATE server_invites SET use_count=use_count+1 WHERE id=?
      AND EXISTS (SELECT 1 FROM invite_uses WHERE invite_id=? AND user_id=? AND used_at=?)
      AND NOT EXISTS (SELECT 1 FROM server_members WHERE server_id=? AND user_id=?)`)
      .bind(invite.id, invite.id, userId, now, invite.server_id, userId),
    db.prepare(`INSERT OR IGNORE INTO server_members(server_id,user_id,role,joined_at)
      SELECT ?,?,'member',? WHERE EXISTS
      (SELECT 1 FROM invite_uses WHERE invite_id=? AND user_id=? AND used_at=?)`)
      .bind(invite.server_id, userId, now, invite.id, userId, now),
  ]);
  const joined = await db.prepare("SELECT 1 FROM server_members WHERE server_id=? AND user_id=?")
    .bind(invite.server_id, userId).first();
  if (!joined) throw new HttpError(409, "Mã mời đã dùng hết lượt.");
  return { id: invite.server_id };
}
