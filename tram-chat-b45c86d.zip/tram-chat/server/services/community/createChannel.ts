import type { Database } from "../../types/Database";
import { requireMembership } from "../../guards/requireMembership";
import { readName } from "../../validators/community/readName";
import { HttpError } from "../../http/HttpError";
export async function createChannel(db: Database, serverId: string, userId: string, value: unknown) {
  await requireMembership(db, serverId, userId, true);
  const id = crypto.randomUUID(), name = readName(value, true);
  try {
    const row = await db.prepare(`INSERT INTO rooms(id,kind,server_id,name,position,created_at)
      SELECT ?,'channel',?,?,COALESCE((SELECT MAX(position)+1 FROM rooms WHERE server_id=?),0),?
      WHERE EXISTS (SELECT 1 FROM server_members WHERE server_id=? AND user_id=?
      AND role IN ('owner','admin'))
      AND (SELECT count(*) FROM rooms WHERE server_id=?)<200 RETURNING id,name,topic`)
      .bind(id, serverId, name, serverId, Date.now(), serverId, userId, serverId).first();
    if (!row) throw new HttpError(409, "Không thể tạo thêm kênh.");
    return row;
  } catch (error) {
    if (String(error).includes("UNIQUE constraint")) throw new HttpError(409, "Tên kênh đã có rồi.");
    throw error;
  }
}
