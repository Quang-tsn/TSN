import type { Database } from "../../types/Database";
import { HttpError } from "../../http/HttpError";
import { requireMembership } from "../../guards/requireMembership";
import { readName } from "../../validators/community/readName";
export async function changeChannel(db: Database, roomId: string, userId: string,
  data: Record<string, unknown>, remove: boolean) {
  const room = await db.prepare("SELECT server_id FROM rooms WHERE id=? AND kind='channel'")
    .bind(roomId).first<{ server_id: string }>();
  if (!room) throw new HttpError(404, "Kênh này không còn nữa.");
  await requireMembership(db, room.server_id, userId, true);
  const permission = `EXISTS (SELECT 1 FROM server_members
    WHERE server_id=rooms.server_id AND user_id=? AND role IN ('owner','admin'))`;
  try {
    if (remove) {
      const row = await db.prepare(`DELETE FROM rooms WHERE id=? AND ${permission}
        AND (SELECT count(*) FROM rooms r WHERE r.server_id=rooms.server_id)>1 RETURNING id`)
        .bind(roomId, userId).first();
      if (!row) throw new HttpError(409, "Server cần giữ ít nhất một kênh.");
      return { id: roomId };
    }
    const name = readName(data.name, true);
    const topic = typeof data.topic === "string" ? data.topic.trim() : "";
    if (topic.length > 1000) throw new HttpError(400, "Chủ đề tối đa 1.000 ký tự.");
    const row = await db.prepare(`UPDATE rooms SET name=?,topic=? WHERE id=? AND ${permission}
      RETURNING id,name,topic`).bind(name, topic, roomId, userId).first();
    if (!row) throw new HttpError(403, "Bạn không còn quyền quản lý kênh.");
    return row;
  } catch (error) {
    if (String(error).includes("UNIQUE constraint")) throw new HttpError(409, "Tên kênh đã có rồi.");
    throw error;
  }
}
