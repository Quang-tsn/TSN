import type { Database } from "../../types/Database";
import { readName } from "../../validators/community/readName";
import { HttpError } from "../../http/HttpError";
import { discoveryName } from "../../validators/community/discoveryName";
export async function createServer(db: Database, userId: string, value: unknown, isPublic: boolean) {
  const name = readName(value);
  const count = await db.prepare("SELECT count(*) n FROM server_members WHERE user_id=?")
    .bind(userId).first<{ n: number }>();
  if ((count?.n || 0) >= 100) throw new HttpError(409, "Bạn đã tham gia đủ 100 server.");
  const id = crypto.randomUUID(), now = Date.now();
  await db.batch([
    db.prepare("INSERT INTO servers(id,owner_id,name,created_at,is_public,search_name) VALUES (?,?,?,?,?,?)")
      .bind(id, userId, name, now, Number(isPublic), discoveryName(name)),
    db.prepare("INSERT INTO server_members(server_id,user_id,role,joined_at) VALUES (?,?,'owner',?)")
      .bind(id, userId, now),
    ...["general", "giao-luu", "thong-bao"].map((channel, position) =>
      db.prepare(`INSERT INTO rooms(id,kind,server_id,name,position,created_at)
        VALUES (?,'channel',?,?,?,?)`).bind(crypto.randomUUID(), id, channel, position, now)),
  ]);
  return { id, name, description: "", role: "owner", is_public:Number(isPublic), verified:0 };
}
