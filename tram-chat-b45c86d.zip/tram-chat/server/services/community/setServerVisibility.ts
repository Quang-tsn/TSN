import type { Database } from "../../types/Database";
import { HttpError } from "../../http/HttpError";
import { discoveryName } from "../../validators/community/discoveryName";

export async function setServerVisibility(db: Database, user: string, id: string, visible: unknown) {
  if (typeof visible !== "boolean") throw new HttpError(400,"Chọn công khai hoặc riêng tư.");
  const server = await db.prepare("SELECT name FROM servers WHERE id=? AND owner_id=? AND verified=0")
    .bind(id,user).first<{name: string}>();
  if (!server) throw new HttpError(403,"Chỉ chủ server mới chỉnh được quyền tham gia.");
  await db.prepare("UPDATE servers SET is_public=?,search_name=? WHERE id=? AND owner_id=?")
    .bind(Number(visible),discoveryName(server.name),id,user).run();
  return {is_public:Number(visible)};
}
