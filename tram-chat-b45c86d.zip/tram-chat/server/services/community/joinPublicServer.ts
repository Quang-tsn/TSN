import type { Database } from "../../types/Database";
import { HttpError } from "../../http/HttpError";

export async function joinPublicServer(db: Database, user: string, id: string) {
  const joined = await db.prepare(`INSERT OR IGNORE INTO server_members (server_id,user_id,role,joined_at)
    SELECT id,?,'member',? FROM servers WHERE id=? AND is_public=1
    AND (SELECT COUNT(*) FROM server_members WHERE user_id=?)<100 RETURNING server_id`)
    .bind(user,Date.now(),id,user).first();
  if (joined) return {id};
  const server = await db.prepare(`SELECT EXISTS(SELECT 1 FROM server_members WHERE server_id=servers.id
    AND user_id=?) AS joined FROM servers WHERE id=? AND is_public=1`).bind(user,id).first<{joined: number}>();
  if (!server) throw new HttpError(404,"Server này không mở cho mọi người.");
  if (!server.joined) throw new HttpError(409,"Bạn đã tham gia đủ 100 server.");
  return {id};
}
