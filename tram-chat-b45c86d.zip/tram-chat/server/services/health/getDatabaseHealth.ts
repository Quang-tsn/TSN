import { REQUIRED_TABLES } from "../../constants/requiredTables";
import { readTableNames } from "../../repositories/database/readTableNames";
import type { Database } from "../../types/Database";

export async function getDatabaseHealth(db: Database): Promise<boolean> {
  try {
    const names = new Set(await readTableNames(db));
    return REQUIRED_TABLES.every((name) => names.has(name));
  } catch {
    return false;
  }
}
