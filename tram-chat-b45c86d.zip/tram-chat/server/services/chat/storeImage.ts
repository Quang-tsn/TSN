import type { Bucket } from "../../types/Bucket";
import { HttpError } from "../../http/HttpError";
import { imageDimensions } from "../../validators/chat/imageDimensions";
import { gifDimensions } from "../../validators/chat/gifDimensions";
import { freeChatImage } from "../../../src/shared/chatImageLimits";
export async function storeImage(bucket: Bucket | undefined, file: File, allowGif = false, pixels=freeChatImage.pixels) {
  if (!bucket) throw new HttpError(503, "Kho ảnh tạm thời chưa sẵn sàng.");
  const buffer = await file.arrayBuffer();
  const gif = allowGif && file.type === "image/gif";
  const size = gif ? gifDimensions(buffer) : imageDimensions(buffer, file.type);
  if (!size || !size.width || !size.height || size.width * size.height > pixels ||
      size.width > 8192 || size.height > 8192) {
    throw new HttpError(400,gif ? "Dùng GIF hợp lệ, tối đa 2 megapixel." :
      `Dùng ảnh PNG hoặc JPEG hợp lệ, tối đa ${pixels/1000000} megapixel.`);
  }
  const id = crypto.randomUUID();
  const key = "chat/" + id;
  await bucket.put(key, buffer);
  return { id, key, mime: file.type, bytes: file.size, ...size };
}
