import type { Database } from "../../types/Database";
import { requireRoom } from "../../guards/requireRoom";
import { HttpError } from "../../http/HttpError";
import type { Bucket } from "../../types/Bucket";
import { storeImage } from "./storeImage";
import { imageStatements } from "../../repositories/chat/imageStatements";
import { readAnimation } from "../extra/readAnimation";
import { chatMentions } from "../../../src/shared/chatMentions";
import { mentionStatements } from "../../repositories/chat/mentionStatements";
export async function sendMessage(db: Database, roomId: string, userId: string,
  data: Record<string, unknown>, bucket?: Bucket, pixels?:number) {
  await requireRoom(db, roomId, userId);
  const content = typeof data.content === "string" ? data.content.trim() : "";
  const nonce = typeof data.nonce === "string" ? data.nonce : "";
  const file = data.image instanceof File ? data.image : null;
  if ((!content && !file && !data.animation) || content.length > 4000 || !/^[a-zA-Z0-9-]{8,64}$/.test(nonce)) {
    throw new HttpError(400, "Nhập nội dung hoặc đính kèm ảnh. Tối đa 4.000 ký tự.");
  }
  const reply = typeof data.replyTo === "string" && data.replyTo ? data.replyTo : null;
  if (reply && !await db.prepare("SELECT id FROM messages WHERE room_id=? AND id=?")
    .bind(roomId, reply).first()) throw new HttpError(400, "Tin trả lời phải trong cùng kênh.");
  const duplicate = await db.prepare("SELECT id,room_id FROM messages WHERE author_id=? AND client_nonce=?")
    .bind(userId, nonce).first<{ id: string; room_id: string }>();
  if (duplicate?.room_id === roomId) return duplicate;
  if (duplicate) throw new HttpError(409, "Yêu cầu gửi tin đã được dùng.");
  const animation = await readAnimation(db,userId,data.animation);
  const image = file ? await storeImage(bucket, file,false,pixels) : null;
  const id = crypto.randomUUID(), now = Date.now();
  const names = [...new Set(chatMentions(content).map(mention=>mention.username))];
  const broadcast = names.includes("all");
  try {
    await db.batch([
    db.prepare(`INSERT INTO messages(id,room_id,author_id,client_nonce,content,created_at,reply_to_id,mention_all)
      SELECT ?,?,?,?,?,?,?,? WHERE EXISTS (SELECT 1 FROM rooms r
      JOIN server_members sm ON sm.server_id=r.server_id WHERE r.id=? AND sm.user_id=?)
      ON CONFLICT(author_id,client_nonce) DO NOTHING`)
      .bind(id, roomId, userId, nonce, content, now, reply, Number(broadcast), roomId, userId),
    ...mentionStatements(db,id,userId,names.filter(name=>name!=="all")),
    ...(image ? imageStatements(db, image, id, userId, now) : []),
    ...(animation ? [db.prepare(`INSERT INTO extra_animations(message_id,giphy_id,kind)
      SELECT id,?,? FROM messages WHERE id=?`).bind(animation.id,animation.kind,id)] : []),
    db.prepare(`INSERT INTO room_events(room_id,message_id,kind,created_at)
      SELECT room_id,id,'message.created',? FROM messages WHERE id=?`).bind(now, id),
    ]);
  } finally {
    if (image) {
      await db.prepare("SELECT id FROM files WHERE id=?").bind(image.id).first()
        .then((stored) => stored ? undefined : bucket?.delete(image.key)).catch(() => {});
    }
  }
  const row = await db.prepare(`SELECT m.id,m.content,m.created_at,m.author_id,m.client_nonce,
    u.display_name,u.username FROM messages m JOIN users u ON u.id=m.author_id
    WHERE m.room_id=? AND m.author_id=? AND m.client_nonce=?`).bind(roomId, userId, nonce).first();
  if (!row) throw new HttpError(409, "Chưa gửi được tin. Kiểm tra lại quyền vào kênh.");
  return row;
}
