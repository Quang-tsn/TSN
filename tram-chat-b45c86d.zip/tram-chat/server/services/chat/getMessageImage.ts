import type { Env } from "../../types/Env";
import { HttpError } from "../../http/HttpError";
export async function getMessageImage(env: Env, room: string, id: string, user: string) {
  const file = await env.DB.prepare(`SELECT f.object_key,f.mime_type FROM files f
    JOIN message_attachments a ON a.file_id=f.id JOIN messages m ON m.id=a.message_id
    JOIN rooms r ON r.id=m.room_id JOIN server_members s ON s.server_id=r.server_id
    WHERE f.id=? AND r.id=? AND r.kind='channel' AND s.user_id=?
    AND f.state='ready' AND m.deleted_at IS NULL`).bind(id, room, user)
    .first<{ object_key: string; mime_type: string }>();
  const object = file && await env.BUCKET?.get(file.object_key);
  if (!object || !file) throw new HttpError(404, "Ảnh không còn hoặc bạn không có quyền xem.");
  return new Response(object.body, { headers: {
    "Content-Type": file.mime_type, "X-Content-Type-Options": "nosniff",
    "Cache-Control": "private, no-cache", "Cross-Origin-Resource-Policy": "same-origin",
  } });
}
