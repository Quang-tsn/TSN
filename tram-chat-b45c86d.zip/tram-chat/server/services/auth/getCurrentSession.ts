import type { Database } from "../../types/Database";
import type { Account } from "../../types/Account";
import { readSessionToken } from "../../auth/readSessionToken";
import { hashSessionToken } from "../../auth/hashSessionToken";
import { readExtraStatus } from "../extra/readExtraStatus";
export async function getSessionAccount(db: Database, request: Request) {
  const token = readSessionToken(request);
  if (!token) return null;
  return db.prepare(`SELECT u.id,u.username,u.display_name FROM sessions s
    JOIN users u ON u.id=s.user_id
    WHERE s.token_hash=? AND s.expires_at>? AND s.revoked_at IS NULL`)
    .bind(await hashSessionToken(token), Date.now()).first<Account>();
}
export async function getCurrentSession(db: Database, request: Request) {
  const user = await getSessionAccount(db,request);
  if (!user) return null;
  const linked = await db.prepare("SELECT 1 FROM extra_accounts WHERE user_id=?").bind(user.id).first();
  return !linked || (await readExtraStatus(db,user.id)).allowed ? user : null;
}
