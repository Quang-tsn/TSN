import type { Database } from "../../types/Database";
import { readSessionToken } from "../../auth/readSessionToken";
import { hashSessionToken } from "../../auth/hashSessionToken";
export async function logoutAccount(db: Database, request: Request) {
  const token = readSessionToken(request);
  if (token) await db.prepare("DELETE FROM sessions WHERE token_hash=?")
    .bind(await hashSessionToken(token)).run();
}
