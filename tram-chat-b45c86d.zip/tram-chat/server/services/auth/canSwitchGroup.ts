import type { Database } from "../../types/Database";
import { readSessionToken } from "../../auth/readSessionToken";
import { hashSessionToken } from "../../auth/hashSessionToken";

export async function canSwitchGroup(db: Database, request: Request, userId: string, ownerId: string) {
  if (userId === ownerId) return true;
  const token = readSessionToken(request);
  return !!token && !!await db.prepare(`SELECT 1 FROM sessions WHERE token_hash=? AND user_id=?
    AND switch_owner_id=? AND revoked_at IS NULL AND expires_at>?`)
    .bind(await hashSessionToken(token),userId,ownerId,Date.now()).first();
}
