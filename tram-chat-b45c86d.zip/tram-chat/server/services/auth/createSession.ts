import type { Database } from "../../types/Database";
import { randomHex } from "../../auth/randomHex";
import { hashSessionToken } from "../../auth/hashSessionToken";
export async function createSession(db: Database, userId: string, switchOwner: string | null = null, device = ""): Promise<string> {
  const token = randomHex();
  const hash = await hashSessionToken(token);
  const now = Date.now();
  await db.batch([
    db.prepare("DELETE FROM sessions WHERE user_id=? AND (expires_at<=? OR revoked_at IS NOT NULL)")
      .bind(userId, now),
    db.prepare(`DELETE FROM sessions WHERE user_id=? AND id IN
      (SELECT id FROM sessions WHERE user_id=? ORDER BY created_at DESC LIMIT -1 OFFSET 19)`)
      .bind(userId, userId),
    db.prepare(`INSERT INTO sessions
      (id,user_id,token_hash,created_at,expires_at,last_seen_at,switch_owner_id,device_name) VALUES (?,?,?,?,?,?,?,?)`)
      .bind(crypto.randomUUID(), userId, hash, now, now + 604800000, now, switchOwner, device),
  ]);
  return token;
}
