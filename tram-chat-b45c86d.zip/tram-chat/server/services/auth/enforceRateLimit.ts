import type { Database } from "../../types/Database";
import { hashSessionToken } from "../../auth/hashSessionToken";
import { HttpError } from "../../http/HttpError";
export async function enforceRateLimit(db: Database, request: Request,
  identity: string): Promise<void> {
  const now = Date.now();
  await db.prepare(`DELETE FROM auth_rate_limits WHERE key_hash IN
    (SELECT key_hash FROM auth_rate_limits WHERE expires_at<=? LIMIT 100)`)
    .bind(now).run();
  const ip = request.headers.get("CF-Connecting-IP") || "local";
  for (const [key, maximum] of [[`ip:${ip}`, 60], [`id:${identity}`, 12]] as const) {
    const hash = await hashSessionToken(key);
    const row = await db.prepare(`INSERT INTO auth_rate_limits
      (key_hash,attempts,window_start,expires_at) VALUES (?,1,?,?)
      ON CONFLICT(key_hash) DO UPDATE SET
      attempts=CASE WHEN expires_at<=? THEN 1 ELSE attempts+1 END,
      window_start=CASE WHEN expires_at<=? THEN ? ELSE window_start END,
      expires_at=CASE WHEN expires_at<=? THEN ? ELSE expires_at END
      RETURNING attempts`).bind(hash, now, now + 900000, now, now, now,
        now, now + 900000).first<{ attempts: number }>();
    if (!row || row.attempts > maximum) {
      throw new HttpError(429, "Bạn thử nhiều lần quá. Chờ 15 phút rồi thử lại nhé.");
    }
  }
}
