import type { Database } from "../../types/Database";
import { findLoginIdentity } from "../../repositories/auth/findLoginIdentity";
import { derivePasswordHash } from "../../auth/derivePasswordHash";
import { constantTimeEqual } from "../../auth/constantTimeEqual";
import { validatePassword } from "../../validators/auth/validatePassword";
import { HttpError } from "../../http/HttpError";
export async function loginAccount(db: Database, identity: string, value: unknown) {
  const password = validatePassword(value);
  const row = await findLoginIdentity(db, identity);
  const hash = await derivePasswordHash(password, row?.salt || "00".repeat(16),
    row?.iterations || 100000);
  if (!row || !constantTimeEqual(hash, row.password_hash)) {
    throw new HttpError(401, "Tên đăng nhập hoặc mật khẩu chưa đúng.");
  }
  return { id: row.id, username: row.username, display_name: row.display_name };
}
