import type { Database } from "../../types/Database";
import { validateIdentity } from "../../validators/auth/validateIdentity";
import { validatePassword } from "../../validators/auth/validatePassword";
import { randomHex } from "../../auth/randomHex";
import { derivePasswordHash } from "../../auth/derivePasswordHash";
import { HttpError } from "../../http/HttpError";
export async function registerAccount(db: Database, data: Record<string, unknown>, group?: { owner: string; slots: number }) {
  const username = validateIdentity(data.username, true);
  const email = data.email ? validateIdentity(data.email) : null;
  if (email && !email.includes("@")) throw new HttpError(400, "Email không hợp lệ.");
  const password = validatePassword(data.password);
  const user = { id: crypto.randomUUID(), username, display_name: username };
  const salt = randomHex(16);
  const hash = await derivePasswordHash(password, salt);
  const now = Date.now();
  try {
    await db.batch([
      db.prepare(`INSERT INTO users (id,username,email,display_name,created_at,updated_at)
        SELECT ?,?,?,?,?,? WHERE ? IS NULL OR
        (SELECT COALESCE(MAX(slot),0)+1 FROM extra_accounts WHERE owner_id=?) < ?`)
        .bind(user.id, username, email, username, now, now, group?.owner ?? null, group?.owner ?? null, group?.slots ?? 1),
      db.prepare(`INSERT INTO password_credentials
        (user_id,password_hash,salt,iterations,changed_at) SELECT id,?,?,?,? FROM users WHERE id=?`)
        .bind(hash, salt, 100000, now, user.id),
      db.prepare("INSERT INTO user_preferences(user_id,updated_at) SELECT id,? FROM users WHERE id=?")
        .bind(now, user.id),
      ...(group ? [db.prepare(`INSERT INTO extra_accounts (user_id,owner_id,slot)
        SELECT id,?,(SELECT COALESCE(MAX(slot),0)+1 FROM extra_accounts WHERE owner_id=?) FROM users WHERE id=?`)
        .bind(group.owner,group.owner,user.id)] : []),
    ]);
  } catch (error) {
    if (String(error).includes("UNIQUE constraint")) {
      throw new HttpError(409, "Tên đăng nhập hoặc email này đã được dùng.");
    }
    throw error;
  }
  if (group && !await db.prepare("SELECT 1 FROM extra_accounts WHERE user_id=?").bind(user.id).first()) {
    throw new HttpError(409,"Bạn đã dùng hết số tài khoản của gói.");
  }
  return user;
}
