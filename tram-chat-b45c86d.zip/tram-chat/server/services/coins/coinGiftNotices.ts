import type { Database } from "../../types/Database";
import { notableGiftThreshold } from "../../../src/shared/tamperCoins";

export async function coinGiftNotices(db:Database,user:string) {
  const {results} = await db.prepare(`SELECT e.id,e.amount,u.username FROM coin_entries e
    LEFT JOIN users u ON u.id=e.sender_id
    WHERE e.recipient_id=? AND e.kind='gift' AND e.amount>?
    ORDER BY e.created_at DESC,e.id DESC LIMIT 5`)
    .bind(user,notableGiftThreshold).all<{id:string;amount:number;username:string|null}>();
  return {items:results};
}
