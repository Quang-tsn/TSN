import type { Database } from "../../types/Database";
import { HttpError } from "../../http/HttpError";

export async function coinHistory(db:Database,user:string,params:URLSearchParams) {
  const search = (params.get("q") || "").trim().replace(/^@/,"").toLowerCase().slice(0,80);
  const cursor = params.get("before");
  const [time,id] = cursor?.split("|") ?? [];
  if (cursor && (!/^\d{1,16}$/.test(time) || !id || id.length>128)) throw new HttpError(400,"Mốc lịch sử không hợp lệ.");
  const {results} = await db.prepare(`SELECT e.id,e.amount,e.created_at,(e.sender_id=?) sent,
    peer.username,peer.display_name FROM coin_entries e LEFT JOIN users peer
    ON peer.id=CASE WHEN e.sender_id=? THEN e.recipient_id ELSE e.sender_id END
    WHERE e.kind='gift' AND (e.sender_id=? OR e.recipient_id=?)
    AND (?='' OR instr(lower(peer.username),?)>0 OR instr(lower(peer.display_name),?)>0)
    AND (? IS NULL OR (e.created_at,e.id)<(?,?))
    ORDER BY e.created_at DESC,e.id DESC LIMIT 26`)
    .bind(user,user,user,user,search,search,search,cursor,Number(time)||0,id??"").all<{
      id:string;amount:number;created_at:number;sent:number|null;username:string|null;display_name:string|null;
    }>();
  const last = results[24];
  return {items:results.slice(0,25),next:results.length>25 ? last.created_at+"|"+last.id : null};
}
