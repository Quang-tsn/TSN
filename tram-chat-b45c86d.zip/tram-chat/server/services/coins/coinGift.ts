import type { Database } from "../../types/Database";
import { HttpError } from "../../http/HttpError";
import { coinBalanceSql } from "./coinBalance";

export async function coinGift(db:Database,user:string,requestId:string,data:Record<string,unknown>) {
  const name = typeof data.username==="string" ? data.username.trim().replace(/^@/,"").toLowerCase() : "";
  const amount = data.amount;
  if (!/^[a-z0-9_.-]{3,32}$/.test(name) || typeof amount!=="number" ||
    !Number.isSafeInteger(amount) || amount<1) {
    throw new HttpError(400,"Nhập tên đăng nhập và số Coins nguyên lớn hơn 0.");
  }
  const recipient = await db.prepare("SELECT id FROM users WHERE username=?").bind(name).first<{id:string}>();
  if (!recipient) throw new HttpError(404,"Không tìm thấy tài khoản này.");
  if (recipient.id===user) throw new HttpError(400,"Chọn người nhận khác tài khoản của bạn.");
  await db.prepare(`INSERT OR IGNORE INTO coin_entries(id,kind,sender_id,recipient_id,amount,created_at)
    SELECT ?,'gift',?,?,?,? WHERE ${coinBalanceSql}>=?`)
    .bind(requestId,user,recipient.id,amount,Date.now(),user,user,amount).run();
  const entry = await db.prepare("SELECT kind,recipient_id,amount FROM coin_entries WHERE id=?")
    .bind(requestId).first<{kind:string;recipient_id:string;amount:number}>();
  if (!entry) throw new HttpError(409,"Số dư Tamper Coins không đủ.");
  if (entry.kind!=="gift" || entry.recipient_id!==recipient.id || entry.amount!==amount) {
    throw new HttpError(409,"Yêu cầu này đã được dùng.");
  }
}
