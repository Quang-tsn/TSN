import type { Database } from "../../types/Database";

export const coinBalanceSql = `(COALESCE((SELECT SUM(amount) FROM coin_entries WHERE recipient_id=?),0)
  -COALESCE((SELECT SUM(amount) FROM coin_entries WHERE sender_id=?),0))`;

export async function coinBalance(db:Database,user:string) {
  const row = await db.prepare(`SELECT ${coinBalanceSql} balance`).bind(user,user).first<{balance:number}>();
  return row?.balance ?? 0;
}
