import type { Database } from "../../types/Database";
import { generateCode } from "../extra/generateCode";
import { HttpError } from "../../http/HttpError";

export function coinDay() { return new Date(Date.now()+7*3600000).toISOString().slice(0,10); }

export async function coinDaily(db:Database,user:string,input?:unknown) {
  const day = coinDay(), id = "daily:"+day+":"+user;
  if (input===undefined) {
    let random: number;
    do { random = crypto.getRandomValues(new Uint8Array(1))[0]; } while (random===255);
    await db.prepare("INSERT OR IGNORE INTO coin_daily(user_id,day,code,amount) VALUES (?,?,?,?)")
      .bind(user,day,generateCode(),random%5+1).run();
    return db.prepare(`SELECT code,EXISTS(SELECT 1 FROM coin_entries WHERE id=?) claimed
      FROM coin_daily WHERE user_id=? AND day=?`).bind(id,user,day).first<{code:string;claimed:number}>();
  }
  await db.prepare(`INSERT OR IGNORE INTO coin_entries(id,kind,recipient_id,amount,created_at)
    SELECT ?,'daily',user_id,amount,? FROM coin_daily WHERE user_id=? AND day=? AND code=?`)
    .bind(id,Date.now(),user,day,input).run();
  const reward = await db.prepare(`SELECT e.amount FROM coin_entries e JOIN coin_daily d ON d.user_id=e.recipient_id
    WHERE e.id=? AND d.day=? AND d.code=?`).bind(id,day,input).first<{amount:number}>();
  if (!reward) throw new HttpError(404,"Mã hằng ngày không hợp lệ hoặc đã qua ngày mới.");
  return reward;
}
