import type { Database } from "../../types/Database";
import { coinPacks } from "../../../src/shared/tamperCoins";
import { generateCode } from "../extra/generateCode";
import { codeDigest } from "../extra/codeDigest";
import { HttpError } from "../../http/HttpError";

export async function issueCoinPurchase(db:Database,amount:unknown) {
  if (!coinPacks.some(pack=>pack.coins===amount)) throw new HttpError(400,"Chọn gói Coins hợp lệ.");
  const code = generateCode();
  await db.prepare("INSERT INTO coin_purchase_codes(digest,amount,created_at) VALUES (?,?,?)")
    .bind(await codeDigest(code),amount,Date.now()).run();
  return {code,amount};
}

export async function redeemCoinPurchase(db:Database,user:string,code:string) {
  const digest = await codeDigest(code), id = "pack:"+digest;
  await db.prepare(`INSERT OR IGNORE INTO coin_entries(id,kind,recipient_id,amount,created_at)
    SELECT ?,'purchase',?,amount,? FROM coin_purchase_codes WHERE digest=?`)
    .bind(id,user,Date.now(),digest).run();
  const entry = await db.prepare("SELECT amount,recipient_id FROM coin_entries WHERE id=?")
    .bind(id).first<{amount:number;recipient_id:string|null}>();
  if (!entry) throw new HttpError(404,"Không tìm thấy mã nạp này.");
  if (entry.recipient_id!==user) throw new HttpError(409,"Mã nạp này đã được sử dụng.");
  return {amount:entry.amount};
}
