import type { Database } from "../../types/Database";
import { coinExchanges } from "../../../src/shared/tamperCoins";
import { HttpError } from "../../http/HttpError";
import { coinBalanceSql } from "./coinBalance";

export async function coinExchange(db:Database,user:string,requestId:string,data:Record<string,unknown>) {
  const plan = coinExchanges.find(product=>product.tier===data.tier && product.days===data.days);
  if (!plan) throw new HttpError(400,"Chọn một kỳ hạn ExtraAccount hợp lệ.");
  const {coins,tier,days} = plan, now = Date.now();
  const detail = tier+":"+days;
  await db.batch([
    db.prepare(`INSERT OR IGNORE INTO coin_entries(id,kind,sender_id,amount,detail,created_at)
      SELECT ?,'exchange',?,?,?,? WHERE ${coinBalanceSql}>=?`)
      .bind(requestId,user,coins,detail,now,user,user,coins),
    db.prepare(`INSERT OR IGNORE INTO extra_grants(id,owner_id,tier,starts_at,expires_at)
      SELECT e.id,e.sender_id,?,e.created_at,
        MAX(e.created_at,COALESCE((SELECT MAX(expires_at) FROM extra_grants WHERE owner_id=? AND tier=?),0))+?
      FROM coin_entries e WHERE e.id=? AND e.kind='exchange' AND e.detail=?`)
      .bind(tier,user,tier,days*86400000,requestId,detail),
  ]);
  const entry = await db.prepare("SELECT detail FROM coin_entries WHERE id=? AND kind='exchange'")
    .bind(requestId).first<{detail:string}>();
  if (!entry) throw new HttpError(409,"Số dư không đủ hoặc yêu cầu đã được dùng.");
  if (entry.detail!==detail) throw new HttpError(409,"Yêu cầu này đã được dùng.");
}
