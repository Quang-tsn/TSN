import type { SavedSort } from "../../../src/types/SavedLibrary";
import { HttpError } from "../../http/HttpError";

export function readSavedCursor(before: string | null,sort: SavedSort) {
  if (!before) return null;
  if (sort === "az" || sort === "za") {
    try {
      const item = JSON.parse(before);
      if (Array.isArray(item) && item.length === 2 && item[0] === sort && typeof item[1] === "string" &&
        item[1].length > 0 && item[1].length <= 128) {
        return {key:null,id:item[1] as string};
      }
    } catch {}
  } else {
    const separator = before.indexOf(":");
    const time = Number(before.slice(0,separator));
    const id = before.slice(separator+1);
    if (separator >= 1 && Number.isSafeInteger(time) && time > 0 && id && id.length<=128) return {key:time,id};
  }
  throw new HttpError(400,"Mốc kho tin không hợp lệ.");
}
