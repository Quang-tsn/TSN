import type { Database } from "../../types/Database";
import { requireAccount } from "../../guards/requireAccount";
import { readExtraStatus } from "./readExtraStatus";
import { canSwitchGroup } from "../auth/canSwitchGroup";
import { HttpError } from "../../http/HttpError";

export async function requireSwitchGroup(db: Database, request: Request) {
  const user = await requireAccount(db,request);
  const group = await readExtraStatus(db,user.id);
  if (group.slots < 2 || !await canSwitchGroup(db,request,user.id,group.owner)) {
    throw new HttpError(403,"Mở chức năng này từ tài khoản chính có Avip hoặc Svip.");
  }
  return group;
}
