import type { Database } from "../../types/Database";

export function findProfileAsset(db: Database, user: string, kind: string) {
  return db.prepare("SELECT object_key,mime FROM extra_profile_assets WHERE user_id=? AND kind=?")
    .bind(user,kind).first<{object_key: string; mime: string}>();
}
