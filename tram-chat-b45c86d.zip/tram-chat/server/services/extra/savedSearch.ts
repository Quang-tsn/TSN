const vietnameseLetters = "àáảãạăằắẳẵặâầấẩẫậđèéẻẽẹêềếểễệìíỉĩịòóỏõọôồốổỗộơờớởỡợùúủũụưừứửữựỳýỷỹỵ";
const combiningMarks = "\u0300\u0301\u0302\u0303\u0306\u0309\u031b\u0323";
const accented = [...vietnameseLetters, ...vietnameseLetters.toUpperCase()];
const replacements = [...accented, ...combiningMarks];
const split = Math.ceil(replacements.length / 2);

// Two stages stay below the D1 expression depth limit.
export function foldSavedSql(column: string,stage: 1 | 2) {
  const letters = stage === 1 ? replacements.slice(0,split) : replacements.slice(split);
  return letters.reduce((sql,letter)=>`replace(${sql},'${letter}','${foldVietnamese(letter)}')`,
    stage === 1 ? `lower(${column})` : column);
}
import { foldVietnamese } from "../../../src/shared/foldVietnamese";

