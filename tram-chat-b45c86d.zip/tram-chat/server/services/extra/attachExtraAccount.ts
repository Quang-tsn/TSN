import type { Database } from "../../types/Database";
import { HttpError } from "../../http/HttpError";

export async function attachExtraAccount(db: Database, user: string, owner: string, slots: number) {
  if (owner === user) return;
  const now = Date.now();
  await db.prepare(`INSERT OR IGNORE INTO extra_accounts (user_id,owner_id,slot)
    SELECT ?,?,next.slot FROM (SELECT COALESCE(MAX(slot),0)+1 AS slot FROM extra_accounts WHERE owner_id=?) next
    WHERE next.slot<? AND NOT EXISTS (SELECT 1 FROM extra_accounts WHERE owner_id=?)
    AND NOT EXISTS (SELECT 1 FROM extra_grants WHERE owner_id=? AND expires_at>?)
    AND NOT EXISTS (SELECT 1 FROM extra_trials WHERE owner_id=? AND started_at>?)`)
    .bind(user,owner,owner,slots,user,user,now,user,now-900000).run();
  const linked = await db.prepare("SELECT owner_id,slot FROM extra_accounts WHERE user_id=?")
    .bind(user).first<{owner_id: string; slot: number}>();
  if (linked?.owner_id === owner && linked.slot < slots) return;
  if (linked && linked.owner_id !== owner) throw new HttpError(409,"Tài khoản đã thuộc một nhóm ExtraAccount khác.");
  const full = await db.prepare("SELECT COALESCE(MAX(slot),0)+1>=? AS full FROM extra_accounts WHERE owner_id=?")
    .bind(slots,owner).first<{full: number}>();
  if (linked || full?.full) throw new HttpError(409,"Bạn đã dùng hết số tài khoản của gói.");
  throw new HttpError(409,"Tài khoản này đang dùng gói riêng hoặc có nhóm ExtraAccount riêng.");
}
