import type { Database } from "../../types/Database";
import type { Tier } from "../../../src/shared/extraPlans";

export function readActiveGrant(db: Database, user: string, now: number) {
  return db.prepare(`SELECT tier,expires_at FROM extra_grants
    WHERE owner_id=? AND starts_at<=? AND expires_at>?
    ORDER BY CASE tier WHEN 'Svip' THEN 3 WHEN 'Avip' THEN 2 ELSE 1 END DESC, expires_at DESC LIMIT 1`)
    .bind(user,now,now).first<{ tier: Tier; expires_at: number }>();
}
