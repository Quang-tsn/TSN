import type { Database } from "../../types/Database";
export async function listExtraAccounts(db: Database, owner: string, slots: number) {
  const now = Date.now();
  const { results } = await db.prepare(`SELECT id,username,display_name,0 AS slot,1 AS selectable FROM users WHERE id=?
    UNION ALL SELECT u.id,u.username,u.display_name,a.slot,(a.slot<? OR EXISTS(
      SELECT 1 FROM extra_grants g WHERE g.owner_id=u.id AND g.starts_at<=? AND g.expires_at>?
    )) AS selectable FROM extra_accounts a JOIN users u ON a.user_id=u.id WHERE a.owner_id=? ORDER BY slot`)
    .bind(owner,slots,now,now,owner).all();
  return results;
}
