import type { SavedSort } from "../../../src/types/SavedLibrary";
import { HttpError } from "../../http/HttpError";

export function readSavedQuery(params: URLSearchParams) {
  const sort = params.get("sort") || "newest";
  if (sort !== "newest" && sort !== "oldest" && sort !== "az" && sort !== "za") {
    throw new HttpError(400,"Cách sắp xếp không hợp lệ.");
  }
  const filters = {folder:params.get("folder") ?? "",author:params.get("author") ?? "",server:params.get("server") ?? ""};
  if (Object.values(filters).some(value=>value && !/^[a-zA-Z0-9_-]{1,128}$/.test(value))) {
    throw new HttpError(400,"Bộ lọc Tin đã lưu không hợp lệ.");
  }
  const before = params.get("before");
  return { ...filters,sort:sort as SavedSort,q:params.get("q")?.trim().slice(0,120) ?? "",before };
}
