export const savedMediaJoins = `LEFT JOIN message_attachments a ON a.message_id=m.id AND a.position=0
  LEFT JOIN files f ON f.id=a.file_id AND f.state='ready'
  LEFT JOIN extra_animations anim ON anim.message_id=m.id`;

export const savedMediaBytes = `length(CAST(m.content AS BLOB))+COALESCE(f.byte_size,0)
  +COALESCE(length(CAST(anim.giphy_id || anim.kind AS BLOB)),0)`;

export const savedTitle = `COALESCE(NULLIF(trim(m.content),''),CASE WHEN f.id IS NOT NULL THEN 'Ảnh đính kèm'
  WHEN anim.kind='sticker' THEN 'Sticker' ELSE 'GIF' END)`;

export const savedMessageSource = `FROM extra_saved s JOIN messages m ON m.id=s.message_id
  JOIN users u ON u.id=m.author_id JOIN rooms r ON r.id=m.room_id
  JOIN servers v ON v.id=r.server_id JOIN server_members sm ON sm.server_id=r.server_id AND sm.user_id=s.user_id
  ${savedMediaJoins} WHERE s.user_id=? AND m.deleted_at IS NULL AND (${savedMediaBytes})>0`;

export const visibleSavedBytes = `SELECT COALESCE(SUM(${savedMediaBytes}),0) n
  FROM extra_saved s JOIN messages m ON m.id=s.message_id JOIN rooms r ON r.id=m.room_id
  JOIN server_members sm ON sm.server_id=r.server_id AND sm.user_id=s.user_id
  ${savedMediaJoins} WHERE s.user_id=? AND m.deleted_at IS NULL`;
