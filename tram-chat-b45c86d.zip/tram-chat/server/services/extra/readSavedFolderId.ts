import type { Database } from "../../types/Database";
import { HttpError } from "../../http/HttpError";

export async function readSavedFolderId(db: Database,user: string,value: unknown) {
  if (value == null || value === "") return null;
  if (typeof value !== "string" || !/^[0-9a-f-]{36}$/.test(value) || !await db.prepare(
    "SELECT 1 FROM extra_saved_folders WHERE id=? AND user_id=?").bind(value,user).first()) {
    throw new HttpError(404,"Thư mục này không còn trong kho của bạn.");
  }
  return value;
}
