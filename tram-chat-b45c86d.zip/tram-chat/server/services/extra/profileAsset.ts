import type { Env } from "../../types/Env";
import { requireExtra } from "./requireExtra";
import { readExtraStatus } from "./readExtraStatus";
import { readImagePost } from "../../validators/chat/readImagePost";
import { storeImage } from "../chat/storeImage";
import { HttpError } from "../../http/HttpError";
import { findProfileAsset } from "./findProfileAsset";
export async function saveProfileAsset(env: Env, request: Request, user: string, kind: string) {
  if (!["avatar","background"].includes(kind)) throw new HttpError(404,"Loại ảnh không hợp lệ.");
  const { tier } = await requireExtra(env.DB,user);
  if (kind === "background" && tier !== "Svip") throw new HttpError(403,"Chỉ Svip mới đổi được hình nền hồ sơ.");
  const { image } = await readImagePost(request);
  if (image.type === "image/gif" && tier !== "Svip") throw new HttpError(403,"Chỉ Svip mới dùng được ảnh đại diện GIF.");
  const old = await findProfileAsset(env.DB,user,kind);
  const stored = await storeImage(env.BUCKET,image,tier === "Svip");
  try {
    const saved = await env.DB.prepare(`INSERT INTO extra_profile_assets(user_id,kind,object_key,mime) VALUES (?,?,?,?)
      ON CONFLICT(user_id,kind) DO UPDATE SET object_key=excluded.object_key,mime=excluded.mime
      WHERE extra_profile_assets.object_key=? RETURNING object_key`)
      .bind(user,kind,stored.key,stored.mime,old?.object_key ?? null).first();
    if (!saved) throw new HttpError(409,"Ảnh vừa được đổi ở nơi khác. Thử tải lại nhé.");
  } catch (error) {
    await env.BUCKET?.delete(stored.key).catch(() => {});
    throw error;
  }
  if (old) await env.BUCKET?.delete(old.object_key).catch(() => {});
  return { ok: true };
}
export async function getProfileAsset(env: Env, viewer: string, user: string, kind: string) {
  if (viewer !== user && !await env.DB.prepare(`SELECT 1 FROM server_members a JOIN server_members b
    ON a.server_id=b.server_id WHERE a.user_id=? AND b.user_id=? LIMIT 1`).bind(viewer,user).first()) {
    throw new HttpError(404,"Ảnh không khả dụng.");
  }
  const { tier } = await readExtraStatus(env.DB,user);
  const asset = await findProfileAsset(env.DB,user,kind);
  if (!tier || !asset || (kind === "background" || asset.mime === "image/gif") && tier !== "Svip") {
    throw new HttpError(404,"Ảnh không khả dụng.");
  }
  const object = asset && await env.BUCKET?.get(asset.object_key);
  if (!object) throw new HttpError(404,"Ảnh không khả dụng.");
  return new Response(object.body,{ headers: { "Content-Type": asset.mime,
    "Cache-Control": "private, no-cache", "X-Content-Type-Options": "nosniff" } });
}
