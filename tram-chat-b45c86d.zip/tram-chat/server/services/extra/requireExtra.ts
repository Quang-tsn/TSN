import type { Database } from "../../types/Database";
import { HttpError } from "../../http/HttpError";
import { readExtraStatus } from "./readExtraStatus";
export async function requireExtra(db: Database, userId: string) {
  const status = await readExtraStatus(db, userId);
  if (!status.tier) throw new HttpError(403, "Cần gói ExtraAccount đang hoạt động.");
  return status;
}
