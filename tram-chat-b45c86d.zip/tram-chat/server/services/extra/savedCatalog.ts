import type { Database } from "../../types/Database";
import type { SavedOption } from "../../../src/types/SavedLibrary";
import { savedMessageSource } from "./savedMediaSql";
import { listSavedFolders } from "./savedFolders";

export async function savedCatalog(db: Database,user: string) {
  const [folders,authors,servers] = await Promise.all([
    listSavedFolders(db,user),
    db.prepare(`SELECT DISTINCT u.id,u.display_name AS name,u.username ${savedMessageSource}
      ORDER BY name COLLATE NOCASE,u.id`).bind(user).all<SavedOption & {username: string}>(),
    db.prepare(`SELECT DISTINCT v.id,v.name ${savedMessageSource}
      ORDER BY v.name COLLATE NOCASE,v.id`).bind(user).all<SavedOption>(),
  ]);
  return { folders,authors:authors.results.map(user=>({id:user.id,name:`${user.name} (@${user.username})`})),servers:servers.results };
}
