import type { Database } from "../../types/Database";
import type { SavedMessage } from "../../../src/types/SavedMessage";
import { savedMessageSource,savedTitle } from "./savedMediaSql";
import { HttpError } from "../../http/HttpError";
import { readSavedQuery } from "./readSavedQuery";
import { readSavedCursor } from "./savedCursor";
import { foldSavedSql } from "./savedSearch";
import { foldVietnamese } from "../../../src/shared/foldVietnamese";
const pageSize = 40;
const searchable = `concat_ws(char(0),${savedTitle},u.display_name,u.username,v.name,r.name)`;

export async function readSavedPage(db: Database, user: string, params: URLSearchParams) {
  const {before,sort,q,folder,author,server} = readSavedQuery(params);
  const cursor = readSavedCursor(before,sort);
  const alpha = sort === "az" || sort === "za";
  const ascending = sort === "az" || sort === "oldest";
  const order = ascending ? "ASC" : "DESC";
  const compare = ascending ? ">" : "<";
  const key = alpha ? foldSavedSql("alpha_text",2) : "saved_at";
  const search = foldVietnamese(q.replace(/\0/g,""));
  const pivot = cursor && alpha ? await db.prepare(`WITH pivot_title AS MATERIALIZED (
    SELECT ${foldSavedSql(savedTitle,1)} alpha_text ${savedMessageSource} AND m.id=?
  ) SELECT ${key} sort_key FROM pivot_title`).bind(user,cursor.id).first<{sort_key:string}>() : null;
  if (cursor && alpha && !pivot) throw new HttpError(409,"Kho tin vừa thay đổi. Chọn Trang đầu để cập nhật.");
  const pivotKey = pivot?.sort_key ?? cursor?.key ?? null;
  const { results } = await db.prepare(`WITH candidates AS ${search || alpha ? "MATERIALIZED" : ""} (
    SELECT m.id,m.room_id,m.content,u.display_name,s.saved_at,s.folder_id,v.name server_name,r.name room_name,
    f.id image_id,f.width image_width,f.height image_height,anim.giphy_id,anim.kind animation_kind,
    ${alpha ? foldSavedSql(savedTitle,1) : "NULL"} alpha_text,
    ${search ? foldSavedSql(searchable,1) : "NULL"} search_text
    ${savedMessageSource}
    AND (?='' OR (?='unfiled' AND s.folder_id IS NULL) OR s.folder_id=?)
    AND (?='' OR m.author_id=?) AND (?='' OR v.id=?)
  ), ordered AS (
    SELECT *,${key} sort_key FROM candidates ${search ? `WHERE instr(${foldSavedSql("search_text",2)},?)>0` : ""}
  )
    SELECT * FROM ordered WHERE (? IS NULL OR sort_key${compare}? OR (sort_key=? AND id${compare}?))
    ORDER BY sort_key ${order},id ${order} LIMIT ?`)
    .bind(user,folder,folder,folder,author,author,server,server,...(search ? [search] : []),
      pivotKey,pivotKey,pivotKey,cursor?.id ?? "",pageSize+1)
    .all<SavedMessage & { sort_key: string | number; alpha_text: string | null; search_text: string | null }>();
  const saved = results.slice(0,pageSize);
  const last = saved[saved.length-1];
  const next = results.length > pageSize && last
    ? alpha ? JSON.stringify([sort,last.id]) : last.saved_at + ":" + last.id : null;
  return { saved:saved.map(({sort_key,alpha_text,search_text,...item})=>item),next };
}
