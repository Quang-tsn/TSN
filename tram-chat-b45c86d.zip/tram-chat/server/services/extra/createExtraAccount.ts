import type { Database } from "../../types/Database";
import { readExtraStatus } from "./readExtraStatus";
import { validateIdentity } from "../../validators/auth/validateIdentity";
import { HttpError } from "../../http/HttpError";
import { canSwitchGroup } from "../auth/canSwitchGroup";
export async function createExtraAccount(db: Database, request: Request, user: string, value: unknown) {
  const status = await readExtraStatus(db,user);
  if (!status.allowed || status.slots <= 1) throw new HttpError(403, "Gói hiện tại chỉ dùng tài khoản chính.");
  if (!await canSwitchGroup(db,request,user,status.owner)) throw new HttpError(403,"Tạo tài khoản từ tài khoản chính.");
  const username = validateIdentity(value, true);
  const id = crypto.randomUUID(), now = Date.now();
  try {
    await db.batch([
      db.prepare(`INSERT INTO users(id,username,display_name,created_at,updated_at)
        SELECT ?,?,?,?,? WHERE (SELECT count(*) FROM extra_accounts WHERE owner_id=?)<?`)
        .bind(id, username, username, now, now, status.owner, status.slots - 1),
      db.prepare(`INSERT INTO extra_accounts(user_id,owner_id,slot)
        SELECT id,?,COALESCE((SELECT max(slot)+1 FROM extra_accounts WHERE owner_id=?),1)
        FROM users WHERE id=?`).bind(status.owner,status.owner,id),
    ]);
  } catch (error) {
    if (String(error).includes("UNIQUE constraint")) throw new HttpError(409,"Tên đã được dùng.");
    throw error;
  }
  const created = await db.prepare("SELECT slot FROM extra_accounts WHERE user_id=?").bind(id).first();
  if (!created) throw new HttpError(409, "Bạn đã dùng hết số tài khoản của gói.");
  return { id, username };
}
