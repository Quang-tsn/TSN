import type { Database } from "../../types/Database";
import { requireExtra } from "./requireExtra";
import { HttpError } from "../../http/HttpError";
import { readSavedPage } from "./readSavedPage";
import { savedMediaBytes,savedMediaJoins,visibleSavedBytes } from "./savedMediaSql";
import { readSavedFolderId } from "./readSavedFolderId";
export async function savedMessages(db: Database, user: string, params: URLSearchParams) {
  const status = await requireExtra(db,user);
  const total = await db.prepare(visibleSavedBytes).bind(user).first<{ n: number }>();
  return { ...(await readSavedPage(db,user,params)), used: total?.n || 0, limit: status.storage };
}
export async function saveMessage(db: Database,user: string,id: unknown,remove = false,folder?: unknown) {
  if (typeof id !== "string" || !id || id.length > 128) throw new HttpError(400, "Tin nhắn không hợp lệ.");
  if (remove) {
    await db.prepare("DELETE FROM extra_saved WHERE user_id=? AND message_id=?").bind(user,id).run();
    return { ok: true };
  }
  const { storage } = await requireExtra(db,user);
  const folderId = await readSavedFolderId(db,user,folder);
  const found = await db.prepare(`SELECT m.id FROM messages m JOIN rooms r ON r.id=m.room_id
    JOIN server_members sm ON sm.server_id=r.server_id ${savedMediaJoins} WHERE m.id=? AND sm.user_id=?
    AND m.deleted_at IS NULL AND (${savedMediaBytes})>0`).bind(id,user).first();
  if (!found) throw new HttpError(404, "Tin nhắn hoặc tệp đính kèm không còn trong kênh bạn có quyền xem.");
  await db.prepare(`INSERT INTO extra_saved(user_id,owner_id,message_id,saved_at,folder_id)
    SELECT ?,?,m.id,?,? FROM messages m JOIN rooms r ON r.id=m.room_id
    JOIN server_members sm ON sm.server_id=r.server_id AND sm.user_id=? ${savedMediaJoins}
    WHERE m.id=? AND m.deleted_at IS NULL AND (${savedMediaBytes})>0
    AND (EXISTS (SELECT 1 FROM extra_saved WHERE user_id=? AND message_id=m.id)
      OR (${savedMediaBytes})+(${visibleSavedBytes})<=?)
    ON CONFLICT(user_id,message_id) DO UPDATE SET folder_id=excluded.folder_id WHERE ?`)
    .bind(user,user,Date.now(),folderId,user,id,user,user,storage,folder !== undefined ? 1 : 0).run();
  if (!await db.prepare("SELECT 1 FROM extra_saved WHERE user_id=? AND message_id=?").bind(user,id).first()) {
    throw new HttpError(409, "Kho lưu đã đầy. Bỏ lưu một số tin rồi thử lại.");
  }
  return { ok: true };
}
