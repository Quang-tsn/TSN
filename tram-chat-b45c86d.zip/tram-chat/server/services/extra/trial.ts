import type { Database } from "../../types/Database";
import { HttpError } from "../../http/HttpError";
import { trialDuration, trialWait } from "../../../src/shared/extraPlans";
import { readExtraStatus } from "./readExtraStatus";
export async function trial(db: Database, user: string, claim: boolean) {
  const status = await readExtraStatus(db, user);
  if (status.tier || !status.allowed) throw new HttpError(409, "Tài khoản chưa thể bắt đầu lượt thử mới.");
  const now = Date.now();
  type Challenge = { id: string; started_at: number };
  const pending = claim ? await db.prepare(
    "SELECT id,started_at FROM extra_trials WHERE owner_id=? AND started_at>?"
  ).bind(user,now-900000).first<Challenge>() : await db.prepare(`INSERT INTO extra_trials(owner_id,id,started_at)
    VALUES (?,?,?) ON CONFLICT(owner_id) DO UPDATE SET
    id=CASE WHEN started_at<? THEN excluded.id ELSE id END,
    started_at=CASE WHEN started_at<? THEN excluded.started_at ELSE started_at END
    RETURNING id,started_at`).bind(user, crypto.randomUUID(), now, now - 900000, now - 900000)
    .first<Challenge>();
  if (!pending) throw new HttpError(409, "Mở quảng cáo để bắt đầu lượt thử.");
  const readyAt = pending.started_at + trialWait;
  if (!claim) return { readyAt, serverTime: now };
  if (now < readyAt) throw new HttpError(409, "Lượt chờ 90 giây chưa kết thúc.");
  await db.batch([
    db.prepare(`INSERT OR IGNORE INTO extra_grants(id,owner_id,tier,starts_at,expires_at)
      SELECT id,owner_id,'Bvip',?,? FROM extra_trials WHERE owner_id=? AND id=?
      AND NOT EXISTS (SELECT 1 FROM extra_grants WHERE owner_id=? AND expires_at>?)`)
      .bind(now, now + trialDuration, user, pending.id, user, now),
    db.prepare("DELETE FROM extra_trials WHERE owner_id=? AND id=?").bind(user, pending.id),
  ]);
  return readExtraStatus(db, user);
}
