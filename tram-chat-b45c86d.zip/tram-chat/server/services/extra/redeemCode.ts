import type { Database } from "../../types/Database";
import type { PaidTier } from "../../../src/shared/extraPlans";
import { isExtraCode } from "../../../src/shared/isExtraCode";
import { normalizeExtraCode } from "../../../src/shared/normalizeExtraCode";
import { HttpError } from "../../http/HttpError";
import { codeDigest } from "./codeDigest";

export async function redeemCode(db: Database, userId: string, input: unknown, plan?: unknown) {
  if (plan !== undefined && plan !== "Avip" && plan !== "Svip") throw new HttpError(400,"Chọn gói Avip hoặc Svip.");
  const code = typeof input === "string" ? normalizeExtraCode(input) : "";
  if (!isExtraCode(code)) throw new HttpError(400,"Kiểm tra lại mã. Mã gồm 12 ký tự, có cả chữ và số.");
  const digest = await codeDigest(code);
  const grantId = "code:" + digest;
  const now = Date.now();
  // D1 runs the grant and consumption together, even for simultaneous requests.
  await db.batch([
    db.prepare(`INSERT INTO extra_grants (id,owner_id,tier,starts_at,expires_at)
      SELECT ?,?,c.tier,?,MAX(?,COALESCE((SELECT MAX(g.expires_at) FROM extra_grants g
        WHERE g.owner_id=? AND g.tier=c.tier),0)) + CASE c.period
        WHEN 'week' THEN 604800000 ELSE 2592000000 END
      FROM extra_codes c WHERE c.digest=? AND c.redeemed_at IS NULL AND (? IS NULL OR c.tier=?)`)
      .bind(grantId,userId,now,now,userId,digest,plan ?? null,plan ?? null),
    db.prepare(`UPDATE extra_codes SET redeemed_at=? WHERE digest=? AND redeemed_at IS NULL
      AND EXISTS (SELECT 1 FROM extra_grants WHERE id=? AND owner_id=?)`)
      .bind(now,digest,grantId,userId),
  ]);
  const grant = await db.prepare("SELECT tier,expires_at FROM extra_grants WHERE id=? AND owner_id=?")
    .bind(grantId,userId).first<{ tier: PaidTier; expires_at: number }>();
  if (!grant) {
    const codeRow = await db.prepare("SELECT tier,redeemed_at FROM extra_codes WHERE digest=?")
      .bind(digest).first<{ tier: PaidTier; redeemed_at: number | null }>();
    if (codeRow?.redeemed_at != null) throw new HttpError(409,"Mã này đã được dùng cho tài khoản khác.");
    if (plan && codeRow?.tier && plan !== codeRow.tier) throw new HttpError(400,`Mã này dùng cho gói ${codeRow.tier}.`);
    throw new HttpError(404,"Không tìm thấy mã này. Hãy kiểm tra lại mã bạn nhận được.");
  }
  if (plan && plan !== grant.tier) throw new HttpError(400,`Mã này dùng cho gói ${grant.tier}.`);
  return { tier:grant.tier,expiresAt:grant.expires_at };
}
