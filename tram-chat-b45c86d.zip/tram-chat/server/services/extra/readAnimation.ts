import type { Database } from "../../types/Database";
import { HttpError } from "../../http/HttpError";
import { requireExtra } from "./requireExtra";
export async function readAnimation(db: Database, user: string, value: unknown) {
  if (value === undefined || value === null) return null;
  const item = value as { id?: unknown; kind?: unknown };
  if (typeof item.id !== "string" || !/^[a-zA-Z0-9]{1,80}$/.test(item.id) ||
      (item.kind !== "gif" && item.kind !== "sticker")) {
    throw new HttpError(400, "Ảnh động GIPHY không hợp lệ.");
  }
  await requireExtra(db,user);
  return { id: item.id, kind: item.kind };
}
