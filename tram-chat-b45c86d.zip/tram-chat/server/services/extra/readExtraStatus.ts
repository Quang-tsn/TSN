import type { Database } from "../../types/Database";
import { extraPlans } from "../../../src/shared/extraPlans";
import { readActiveGrant } from "./readActiveGrant";
export async function readExtraStatus(db: Database, userId: string) {
  const linked = await db.prepare("SELECT owner_id,slot FROM extra_accounts WHERE user_id=?")
    .bind(userId).first<{ owner_id: string; slot: number }>();
  const owner = linked?.owner_id || userId;
  const now = Date.now();
  const personal = readActiveGrant(db,userId,now);
  const [grant,groupGrant] = await Promise.all([personal,linked ? readActiveGrant(db,owner,now) : personal]);
  const slots = groupGrant ? extraPlans[groupGrant.tier].slots : 1;
  const allowed = !linked || !!grant || linked.slot < slots;
  return { owner,allowed,tier:grant?.tier ?? null,expiresAt:grant?.expires_at ?? null,
    slots,storage:grant ? extraPlans[grant.tier].storage : 0 };
}
