import type { Database } from "../../types/Database";
import type { SavedOption } from "../../../src/types/SavedLibrary";
import { HttpError } from "../../http/HttpError";

export async function listSavedFolders(db: Database,user: string) {
  const data = await db.prepare("SELECT id,name FROM extra_saved_folders WHERE user_id=? ORDER BY name_key,id")
    .bind(user).all<SavedOption>();
  return data.results;
}

export async function createSavedFolder(db: Database,user: string,input: unknown) {
  const name = typeof input === "string" ? input.trim().normalize("NFC") : "";
  if (!name || [...name].length > 64 || /[\u0000-\u001f\u007f]/.test(name)) {
    throw new HttpError(400,"Tên thư mục phải có từ 1 đến 64 ký tự trên một dòng.");
  }
  const folder = await db.prepare(`INSERT OR IGNORE INTO extra_saved_folders(id,user_id,name,name_key,created_at)
    VALUES (?,?,?,?,?) RETURNING id,name`).bind(crypto.randomUUID(),user,name,name.toLocaleLowerCase("vi"),Date.now())
    .first<SavedOption>();
  if (!folder) throw new HttpError(409,"Bạn đã có thư mục tên này.");
  return folder;
}
