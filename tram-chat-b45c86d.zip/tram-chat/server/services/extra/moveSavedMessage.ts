import type { Database } from "../../types/Database";
import { HttpError } from "../../http/HttpError";
import { readSavedFolderId } from "./readSavedFolderId";

export async function moveSavedMessage(db: Database,user: string,message: unknown,folder: unknown) {
  if (typeof message !== "string" || !message || message.length > 128) throw new HttpError(400,"Tin đã lưu không hợp lệ.");
  const folderId = await readSavedFolderId(db,user,folder);
  const updated = await db.prepare("UPDATE extra_saved SET folder_id=? WHERE user_id=? AND message_id=? RETURNING message_id")
    .bind(folderId,user,message).first();
  if (!updated) throw new HttpError(404,"Tin này không còn trong kho.");
  return {folderId};
}
