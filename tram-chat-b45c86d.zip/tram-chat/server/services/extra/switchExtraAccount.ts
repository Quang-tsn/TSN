import type { Database } from "../../types/Database";
import { HttpError } from "../../http/HttpError";
import { readExtraStatus } from "./readExtraStatus";
import { createSession } from "../auth/createSession";
import { logoutAccount } from "../auth/logoutAccount";
import { jsonResponse } from "../../http/jsonResponse";
import { sessionCookie } from "../../auth/sessionCookie";
import { canSwitchGroup } from "../auth/canSwitchGroup";
import { deviceName } from "../../auth/deviceName";
export async function switchExtraAccount(db: Database, request: Request, user: string, target: unknown) {
  const status = await readExtraStatus(db, user);
  const authorized = await canSwitchGroup(db,request,user,status.owner);
  if (typeof target !== "string" || !authorized || (target !== status.owner && (!await db.prepare(
    "SELECT 1 FROM extra_accounts WHERE user_id=? AND owner_id=?"
  ).bind(target,status.owner).first() || !(await readExtraStatus(db,target)).allowed))) {
    throw new HttpError(403, "Tài khoản này không nằm trong gói đang dùng.");
  }
  const token = await createSession(db,target,status.owner,deviceName(request.headers.get("User-Agent")));
  await logoutAccount(db,request);
  const response = jsonResponse({ ok: true });
  response.headers.set("Set-Cookie", sessionCookie(token));
  return response;
}
