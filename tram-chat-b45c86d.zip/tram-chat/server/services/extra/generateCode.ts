import { isExtraCode } from "../../../src/shared/isExtraCode";

const alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
export function generateCode() {
  let code = "";
  do {
    code = Array.from(crypto.getRandomValues(new Uint8Array(24)))
      .filter(byte => byte < 252).slice(0,12).map(byte => alphabet[byte % alphabet.length]).join("");
  } while (!isExtraCode(code));
  return code;
}
