import type { Database } from "../../types/Database";
import type { SettingsDetails, SettingsSession } from "../../../src/shared/SettingsDetails";
import { deviceName } from "../../auth/deviceName";
import { settingsIdentity } from "./settingsIdentity";

export async function readSettingsDetails(db: Database, request: Request): Promise<SettingsDetails> {
  const active = await settingsIdentity(db,request);
  const now = Date.now();
  const name = deviceName(request.headers.get("User-Agent"));
  await db.prepare(`UPDATE sessions SET last_seen_at=?, device_name=COALESCE(NULLIF(?,''),device_name)
    WHERE id=? AND (last_seen_at<? OR (device_name='' AND ?<>''))`)
    .bind(now,name,active.sessionId,now-60_000,name).run();
  const [sessions,activity,redemptions] = await Promise.all([
    db.prepare(`SELECT id,device_name AS device, created_at AS createdAt,last_seen_at AS lastSeen,expires_at AS expiresAt
      FROM sessions WHERE user_id=? AND revoked_at IS NULL AND expires_at>?
      ORDER BY (id=?) DESC,created_at DESC,id LIMIT 20`)
      .bind(active.userId,now,active.sessionId).all<Omit<SettingsSession,"current">>(),
    db.prepare(`SELECT (created_at+25200000)/86400000 AS day,COUNT(*) AS count FROM messages
      WHERE author_id=? AND created_at>=? AND deleted_at IS NULL GROUP BY day ORDER BY day`)
      .bind(active.userId,now-370*86400000).all<SettingsDetails["activity"][number]>(),
    db.prepare(`SELECT g.tier,c.redeemed_at AS redeemedAt,g.expires_at AS expiresAt
      FROM extra_grants g JOIN extra_codes c ON c.digest=substr(g.id,6)
      WHERE g.owner_id=? AND g.id LIKE 'code:%' ORDER BY g.starts_at DESC,g.id LIMIT 50`)
      .bind(active.userId).all<SettingsDetails["redemptions"][number]>(),
  ]);
  return { email:active.email,createdAt:active.createdAt,passwordSet:!!active.passwordSet,
    sessions:sessions.results.map(item=>({...item,current:item.id===active.sessionId})),
    activity:activity.results,redemptions:redemptions.results };
}
