import type { Database } from "../../types/Database";
import { readSessionToken } from "../../auth/readSessionToken";
import { hashSessionToken } from "../../auth/hashSessionToken";
import { HttpError } from "../../http/HttpError";

export async function settingsIdentity(db: Database, request: Request) {
  const token = readSessionToken(request);
  const active = token && await db.prepare(`SELECT s.id AS sessionId,s.user_id AS userId,
    u.email,u.created_at AS createdAt, EXISTS(SELECT 1 FROM password_credentials WHERE user_id=u.id) AS passwordSet
    FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=? AND s.expires_at>? AND s.revoked_at IS NULL`)
    .bind(await hashSessionToken(token),Date.now())
    .first<{sessionId: string; userId: string; email: string | null; createdAt: number; passwordSet: number}>();
  if (!active) throw new HttpError(401,"Phiên đăng nhập đã hết. Đăng nhập lại nhé.");
  return active;
}
