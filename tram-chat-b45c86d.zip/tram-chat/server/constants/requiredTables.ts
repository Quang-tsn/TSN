export const REQUIRED_TABLES = [
  "users",
  "password_credentials",
  "sessions",
  "servers",
  "server_members",
  "rooms",
  "messages",
  "room_events",
  "message_mentions",
] as const;
