import { HttpError } from "../../http/HttpError";
export function validatePassword(value: unknown): string {
  if (typeof value !== "string" || value.length < 12 || value.length > 128) {
    throw new HttpError(400, "Mật khẩu cần từ 12 đến 128 ký tự.");
  }
  return value;
}
