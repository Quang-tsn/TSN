import { HttpError } from "../../http/HttpError";
export function validateIdentity(value: unknown, usernameOnly = false): string {
  const identity = typeof value === "string" ? value.trim().toLowerCase() : "";
  if (/^[a-z0-9_.-]{3,32}$/.test(identity)) return identity;
  if (!usernameOnly && identity.length <= 254 &&
      /^[a-z0-9.!#$%&'*+/=?^_~-]+@[a-z0-9.-]+\.[a-z]{2,}$/.test(identity)) return identity;
  throw new HttpError(400, usernameOnly
    ? "Tên đăng nhập: 3–32 ký tự, dùng chữ không dấu, số, dấu chấm, gạch ngang."
    : "Nhập tên đăng nhập hoặc email hợp lệ.");
}
