import { HttpError } from "../../http/HttpError";
export function requireSameOrigin(request: Request) {
  if (request.headers.get("Origin") !== new URL(request.url).origin ||
      request.headers.get("X-Tram-Request") !== "1") {
    throw new HttpError(403, "Yêu cầu không hợp lệ. Tải lại trang rồi thử nhé.");
  }
}
