import { HttpError } from "../../http/HttpError";
import { requireSameOrigin } from "./requireSameOrigin";
export async function readAuthBody(request: Request): Promise<Record<string, unknown>> {
  requireSameOrigin(request);
  if (!request.headers.get("Content-Type")?.startsWith("application/json")) {
    throw new HttpError(415, "Dữ liệu cần ở dạng JSON.");
  }
  const reader = request.body?.getReader();
  if (!reader) throw new HttpError(400, "Thiếu dữ liệu.");
  let size = 0;
  let text = "";
  const decoder = new TextDecoder();
  while (true) {
    const { value, done } = await reader.read();
    if (done) break;
    size += value.length;
    if (size > 8192) {
      await reader.cancel();
      throw new HttpError(413, "Dữ liệu quá dài.");
    }
    text += decoder.decode(value, { stream: true });
  }
  try {
    const data = JSON.parse(text + decoder.decode());
    if (!data || Array.isArray(data) || typeof data !== "object") throw Error();
    return data;
  } catch { throw new HttpError(400, "Dữ liệu không hợp lệ."); }
}
