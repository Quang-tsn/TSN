import { HttpError } from "../../http/HttpError";
import { requireSameOrigin } from "../auth/requireSameOrigin";
export async function readImagePost(request: Request, megabytes=4) {
  requireSameOrigin(request);
  let size = 0;
  const limit = megabytes * 1024 * 1024;
  const limited = request.body?.pipeThrough(new TransformStream<Uint8Array, Uint8Array>({
    transform(chunk, controller) {
      size += chunk.byteLength;
      if (size > limit + 32768) throw new HttpError(413, `Ảnh tối đa ${megabytes} MB.`);
      controller.enqueue(chunk);
    },
  }));
  try {
    const form = await new Response(limited, {
      headers: { "Content-Type": request.headers.get("Content-Type")! },
    }).formData();
    const image = form.get("image");
    if (!(image instanceof File) || !image.size) throw new HttpError(400, "Chọn một ảnh để gửi.");
    if (image.size > limit) throw new HttpError(413, `Ảnh tối đa ${megabytes} MB.`);
    return { image, content: form.get("content"), nonce: form.get("nonce"), replyTo: form.get("replyTo") };
  } catch (error) {
    if (error instanceof HttpError) throw error;
    throw new HttpError(400, "Không đọc được ảnh đính kèm.");
  }
}
