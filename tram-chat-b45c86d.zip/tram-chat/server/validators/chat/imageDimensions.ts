type Dimensions = { width: number; height: number };
export function imageDimensions(data: ArrayBuffer, mime: string): Dimensions | null {
  const view = new DataView(data);
  if (mime === "image/png" && view.byteLength >= 33 &&
      view.getUint32(0) === 0x89504e47 && view.getUint32(4) === 0x0d0a1a0a &&
      view.getUint32(8) === 13 && view.getUint32(12) === 0x49484452) {
    return { width: view.getUint32(16), height: view.getUint32(20) };
  }
  if (mime !== "image/jpeg" || view.byteLength < 12 || view.getUint16(0) !== 0xffd8 ||
      view.getUint16(view.byteLength - 2) !== 0xffd9) return null;
  let offset = 2;
  const frameMarkers = [0xc0, 0xc1, 0xc2, 0xc3, 0xc5, 0xc6, 0xc7, 0xc9, 0xca, 0xcb, 0xcd, 0xce, 0xcf];
  while (offset + 4 < view.byteLength && view.getUint8(offset++) === 0xff) {
    while (offset < view.byteLength && view.getUint8(offset) === 0xff) offset++;
    if (offset + 3 > view.byteLength) return null;
    const marker = view.getUint8(offset++);
    if (marker === 0xda || marker === 0xd9) return null;
    const length = view.getUint16(offset);
    if (length < 2 || offset + length > view.byteLength) return null;
    if (frameMarkers.includes(marker) && length >= 8) {
      return { height: view.getUint16(offset + 3), width: view.getUint16(offset + 5) };
    }
    offset += length;
  }
  return null;
}
