export function gifDimensions(data: ArrayBuffer) {
  const bytes = new DataView(data);
  if (bytes.byteLength < 35 || bytes.getUint32(0) !== 0x47494638 ||
      ![0x3761,0x3961].includes(bytes.getUint16(4)) || bytes.getUint8(bytes.byteLength - 1) !== 0x3b) return null;
  const width = bytes.getUint16(6,true), height = bytes.getUint16(8,true);
  // Animated profile art gets a smaller decode budget than static chat images.
  return width > 0 && height > 0 && width * height <= 2_000_000 ? { width,height } : null;
}
