import { HttpError } from "../../http/HttpError";
export function readName(value: unknown, channel = false): string {
  const name = typeof value === "string" ? value.trim() : "";
  if (!name || name.length > (channel ? 60 : 100) || /[\x00-\x1f]/.test(name)) {
    throw new HttpError(400, "Tên cần từ 1 đến " + (channel ? 60 : 100) + " ký tự.");
  }
  return channel ? name.toLowerCase().replace(/\s+/g, "-") : name;
}
