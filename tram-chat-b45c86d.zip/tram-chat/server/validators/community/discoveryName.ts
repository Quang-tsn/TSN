export function discoveryName(value: string) {
  return value.normalize("NFD").toLowerCase().replace(/[\u0300-\u036f]/g, "").replace(/đ/g,"d").trim();
}
