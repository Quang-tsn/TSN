import type { Database } from "../types/Database";
import { getCurrentSession } from "../services/auth/getCurrentSession";
import { HttpError } from "../http/HttpError";
export async function requireAccount(db: Database, request: Request) {
  const user = await getCurrentSession(db, request);
  if (!user) throw new HttpError(401, "Phiên đăng nhập đã hết. Đăng nhập lại nhé.");
  return user;
}
