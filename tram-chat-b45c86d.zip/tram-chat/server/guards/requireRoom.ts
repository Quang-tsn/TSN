import type { Database } from "../types/Database";
import { HttpError } from "../http/HttpError";
export async function requireRoom(db: Database, roomId: string, userId: string) {
  const row = await db.prepare(`SELECT r.id,r.name,r.server_id FROM rooms r
    JOIN server_members m ON m.server_id=r.server_id
    WHERE r.id=? AND r.kind='channel' AND m.user_id=?`).bind(roomId, userId).first();
  if (!row) throw new HttpError(403, "Bạn không có quyền xem kênh này.");
  return row;
}
