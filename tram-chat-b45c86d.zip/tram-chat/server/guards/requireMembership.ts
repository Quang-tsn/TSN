import type { Database } from "../types/Database";
import { HttpError } from "../http/HttpError";
export async function requireMembership(db: Database, serverId: string,
  userId: string, manage = false) {
  const member = await db.prepare("SELECT role FROM server_members WHERE server_id=? AND user_id=?")
    .bind(serverId, userId).first<{ role: string }>();
  if (!member || (manage && !["owner", "admin"].includes(member.role))) {
    throw new HttpError(403, "Bạn không có quyền thực hiện thao tác này.");
  }
  return member;
}
