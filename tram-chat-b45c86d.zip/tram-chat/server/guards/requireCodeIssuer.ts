import { HttpError } from "../http/HttpError";
import { codeDigest } from "../services/extra/codeDigest";

export async function requireCodeIssuer(key:string|undefined,request:Request) {
  const provided = request.headers.get("Authorization") ?? "";
  if (!key || !provided.startsWith("Bearer ")) throw new HttpError(403,"Bạn không có quyền cấp mã.");
  const [expected,actual] = await Promise.all([codeDigest("Bearer "+key),codeDigest(provided)]);
  let difference = 0;
  for (let i=0;i<expected.length;i++) difference |= expected.charCodeAt(i)^actual.charCodeAt(i);
  if (difference) throw new HttpError(403,"Bạn không có quyền cấp mã.");
}
