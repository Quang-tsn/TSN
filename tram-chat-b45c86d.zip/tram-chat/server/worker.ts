import { route } from "./router";
import type { Env } from "./types/Env";

export default {
  fetch(request: Request, env: Env): Promise<Response> {
    return route(request, env);
  },
};
