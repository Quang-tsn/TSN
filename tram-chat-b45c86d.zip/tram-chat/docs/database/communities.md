# Quan hệ và cộng đồng

| Bảng | Cột và ý nghĩa |
| --- | --- |
| `friend_requests` | `id` PK; `sender_id`; `recipient_id` cùng FK users; `created_at` |
| `friendships` | PK kép `user_low`, `user_high` cùng FK users; `created_at` |
| `user_blocks` | PK kép `blocker_id`, `blocked_id` cùng FK users; `created_at` |
| `servers` | `id` PK; `owner_id` FK users; `name`; `description`; `icon_file_id` FK files nullable; `created_at` |
| `server_members` | PK kép `server_id`, `user_id`; `role`; `nickname` nullable; `joined_at` |
| `channel_categories` | `id` PK; `server_id` FK; `name`; `position` |

Lời mời kết bạn không thể gửi chính mình; unique theo cặp không thứ tự,
nên không thể cùng tồn tại hai yêu cầu a→b và b→a.
Chấp nhận yêu cầu: kiểm block, INSERT friendship cặp chuẩn hóa,
DELETE request trong cùng batch. Từ chối/hủy chỉ xóa request.
Friendship dùng `user_low < user_high` theo so sánh binary ID, không theo username.
Block có hướng và không tự block; service xóa friendship/request liên quan.

Tên server/category dài 1–100; description server tối đa 1000.
Vai trò: `owner`, `admin`, `moderator`, `member`.
Unique một thành viên/server; unique tối đa một role owner/server.
Backend phải bảo đảm owner member đúng `servers.owner_id` trong cùng giao dịch.
Chuyển chủ cần cập nhật cả hai nơi; không cho owner rời server trước khi chuyển.
Không có custom role hoặc permission overwrite trong phạm vi ban đầu.

Nickname optional 1–64; vị trí category/channel là số nguyên không âm.
Category có unique `(id, server_id)` để channel không tham chiếu sai server.
Xóa category: chuyển các channel sang category khác hoặc NULL rồi xóa,
thực hiện giao dịch; FK không cho xóa category vẫn đang chứa channel.
Xóa server cascade thành viên, category, channel và lịch sử của server.
`owner_id` RESTRICT bảo vệ người sở hữu trước thao tác DELETE user.
