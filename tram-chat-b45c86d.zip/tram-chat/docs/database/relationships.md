# Quan hệ giữa các bảng

```mermaid
erDiagram
  users ||--o| password_credentials : credentials
  users ||--o{ sessions : sessions
  users ||--o| user_preferences : preferences
  users ||--o{ friend_requests : sends_or_receives
  users ||--o{ friendships : endpoints
  users ||--o{ user_blocks : blocks_or_blocked
  users ||--o{ servers : owns
  servers ||--o{ server_members : members
  users ||--o{ server_members : joins
  servers ||--o{ channel_categories : categories
  servers o|--o{ rooms : channels
  channel_categories o|--o{ rooms : groups
  users o|--o{ rooms : direct_endpoints
  rooms ||--o{ messages : timeline
  users ||--o{ messages : authors
  messages o|--o{ messages : replies
  users ||--o{ files : uploads
  files o|--o{ users : avatar
  files o|--o{ servers : icon
  messages ||--o{ message_attachments : attachments
  files ||--o| message_attachments : used_once
  messages ||--o{ message_reactions : reactions
  users ||--o{ message_reactions : reacts
  messages ||--o| message_pins : pin
  rooms ||--o{ message_pins : pins
  rooms ||--o{ room_reads : cursors
  users ||--o{ room_reads : reads
  servers ||--o{ server_invites : invites
  server_invites ||--o{ invite_uses : uses
  users ||--o{ invite_uses : redeems
  messages ||--o{ message_links : links
  link_previews ||--o{ message_links : previews
  rooms ||--o{ room_events : events
  messages o|--o{ room_events : changes
  rooms ||--o{ room_presence : presence
  users ||--o{ room_presence : devices
```

`auth_rate_limits` là bảng độc lập, dùng khóa hash thay cho thông tin gốc.
Sơ đồ giản lược các FK phụ; SQL migration là định nghĩa đầy đủ.

`rooms.kind` chọn channel hoặc DM; CHECK bắt buộc đúng một loại.
DM chứa đúng hai endpoint theo thứ tự chuẩn, có UNIQUE chống trùng.
Reply, pin và read cursor dùng FK kép gồm `room_id` để giữ cùng phòng.
Quyền truy cập, owner membership và upload ownership còn cần service kiểm.
