# Mời, cập nhật và trạng thái tạm

| Bảng | Cột và ý nghĩa |
| --- | --- |
| `server_invites` | `id` PK; `server_id`; `code_hash` unique; `created_by`; `created_at`; `expires_at` nullable; `max_uses` nullable; `use_count`; `revoked_at` nullable |
| `invite_uses` | PK kép `invite_id`, `user_id`; `used_at` |
| `room_events` | `sequence` INTEGER PK AUTOINCREMENT; `room_id`; `message_id` nullable; `kind`; `created_at` |
| `room_presence` | PK ba `room_id`, `user_id`, `device_id`; `last_seen_at`; `typing_until`; `expires_at` |
| `auth_rate_limits` | `key_hash` PK; `attempts`; `window_start`; `expires_at` |

Mã mời gốc tạo ngẫu nhiên ở backend; DB chỉ lưu SHA-256 hash 64 hex.
Expiry/max uses nullable nghĩa là không đặt giới hạn tương ứng.
Dùng mã: kiểm còn hạn/chưa revoke, tăng use_count với điều kiện max_uses,
thêm server member và invite_use trong một batch nguyên tử.
Unique invite/user chống cùng user dùng lại cùng mã.
Service không tăng count nếu user đã là thành viên; race xử lý cùng giao dịch.

Event kinds: `message.created`, `message.updated`, `message.deleted`,
`reaction.changed`, `pin.changed`, `preview.changed`.
Ghi event trong cùng batch thay đổi dữ liệu; event không sao chép nội dung chat.
Client poll theo `sequence > cursor`, theo room và giới hạn mỗi batch.
API luôn kiểm membership; khi xóa tin, sự kiện vẫn còn nhờ xóa mềm message.
Sau retention cleanup, cursor quá cũ phải nhận yêu cầu đồng bộ lại 50 tin.
Cursor polling là đường dự phòng cho môi trường chưa có hub WebSocket;
schema không tự cung cấp fan-out hoặc bảo đảm độ trễ realtime.

Presence là lease theo phòng/user/device; hết hạn được xem là offline ngay.
`typing_until` TTL ngắn, cập nhật có throttle, không ghi từng phím.
Room change/unmount hủy heartbeat; lease hết hạn xử lý disconnect bất thường.
Status invisible trong users phải che presence khi trả API cho người khác.
Cleanup xóa lease/rate-limit hết hạn theo lô có giới hạn, ngoài request chat.

Rate limit dùng hash khóa đã chuẩn hóa, không lưu IP/account gốc tại bảng này.
Tăng attempts nguyên tử và so sánh window/expiry phía server.
Schema chưa quyết định ngưỡng rate limit hoặc triển khai endpoint đăng nhập.
