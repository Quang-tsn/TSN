# Phòng, tin nhắn và vị trí đọc

| Bảng | Cột và ý nghĩa |
| --- | --- |
| `rooms` | `id` PK; `kind`; `server_id`; `category_id`; `name`; `topic`; `position`; `direct_user_low`; `direct_user_high`; `created_at` |
| `messages` | `id` PK; `room_id`; `author_id`; `client_nonce`; `content`; `reply_to_id`; `created_at`; `edited_at`; `deleted_at` |
| `message_pins` | `message_id` PK; `room_id`; `pinned_by` FK users; `pinned_at` |
| `room_reads` | PK kép `room_id`, `user_id`; `last_message_id` nullable; `updated_at`; `muted` 0/1 |

Room loại `channel`: bắt buộc server/name; hai direct user phải NULL.
Room loại `direct`: không server/category/name; hai user bắt buộc và có thứ tự.
Unique cặp direct user ngăn hai DM cho cùng cặp; không DM chính mình.
Unique tên channel trong server; topic tối đa 1000 ký tự.
Channel hiện là kênh text chung cho thành viên server; chưa có private channel.
Server member là nguồn quyền của channel; DM endpoints là nguồn quyền DM.

Tin nhắn tối đa 4000 ký tự; nội dung rỗng cho phép ảnh-only.
Service phải bảo đảm có text hoặc ít nhất một ảnh sẵn sàng.
`client_nonce` 8–64 ký tự; unique `(author_id, client_nonce)` chống gửi lại.
Reply FK kép `(reply_to_id, room_id)` ngăn reply xuyên phòng.
Không tự reply; FK deferred cho phép batch và xóa room chứa chuỗi reply.
Sửa/xóa là cập nhật timestamps; xóa mềm giữ id/reply và hiện “Tin nhắn đã xóa”.
Service phải xóa text, gỡ file/preview khi xóa mềm; không trả nội dung cũ qua API.

Ghim và vị trí đọc cũng dùng FK kép message/room chống tham chiếu sai phòng.
Ghim có tối đa một hàng/message. Service kiểm quyền ghim và giới hạn số ghim.
Cursor đọc chỉ tiến khi client báo đã thấy; kiểm membership trước UPSERT.
Timeline index `(room_id, created_at DESC, id DESC)` dùng keyset pagination.
API giới hạn 50 tin/lần; client giữ tối đa 50 message row trong DOM.
Không dùng OFFSET; truy vấn trước cursor bằng cặp `(created_at, id)`.
Event cursor là `room_events.sequence`, không thay thế timeline cursor.
Trước xóa cứng một message: gỡ read cursor và reply tham chiếu trong giao dịch;
luồng người dùng thông thường chỉ xóa mềm.
