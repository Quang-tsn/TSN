# Ảnh, reaction và embed

| Bảng | Cột và ý nghĩa |
| --- | --- |
| `files` | `id` PK; `uploader_id`; `object_key` unique; `thumbnail_key` nullable; `original_name`; `mime_type`; `byte_size`; `width`; `height`; `state`; `created_at` |
| `message_attachments` | PK kép `message_id`, `file_id`; `position` |
| `message_reactions` | PK ba `message_id`, `user_id`, `reaction_code`; `created_at` |
| `link_previews` | `id` PK; `url` unique; `title`; `description`; `site_name`; `image_url` nullable; `state`; `fetched_at` nullable; `expires_at` |
| `message_links` | PK kép `message_id`, `preview_id`; `position` |

Database chỉ lưu metadata; bytes ảnh/thumbnail nằm ở R2.
File state: `pending`, `ready`, `deleted`; client không tự chọn trạng thái ready.
Upload service xác minh byte signature, MIME, kích thước và quyền sở hữu.
Chấp nhận JPEG/PNG/WebP/GIF, tối đa 8 MiB/file, chiều mỗi cạnh 1–16384.
Giới hạn diện tích pixel và ảnh động phải kiểm thêm khi decode, ngoài SQL.
Mỗi message tối đa 4 ảnh qua unique vị trí 0–3; một file chỉ gắn một message.
Cho gửi ảnh-only; không nhận SVG upload để tránh nội dung chủ động.
Endpoint đọc ảnh kiểm quyền phòng trước khi stream; không expose object key công khai.
File chưa gắn message cần job dọn pending; chỉ xóa R2 sau khi DB xác nhận.
Xóa mềm message phải ẩn attachment ngay, không đợi cleanup vật lý.

Reaction dùng mã `thumbs-up`, `heart`, `laugh`, `surprised`, `sad`, `celebrate`.
UI vẽ SVG riêng cho từng mã; không dùng emoji hoặc thư viện icon.
Unique ba cột cho phép một user thả mỗi mã một lần trên tin nhắn.

Preview state: `pending`, `ready`, `failed`; cache dùng expiry.
URL chỉ nhận http/https, tối đa 2048; title 300, description 1000, site name 100.
SQL không đủ chặn SSRF. Backend kiểm DNS/IP/redirect, cấm địa chỉ private,
giới hạn timeout, response bytes, redirect count và không gửi cookie đến link.
Không fetch favicon/image_url trực tiếp vào browser nếu chưa xử lý an toàn.
Mỗi message tối đa 3 preview qua unique vị trí 0–2.
Embed không render HTML từ nguồn; chỉ trả plain text và URL đã kiểm.
