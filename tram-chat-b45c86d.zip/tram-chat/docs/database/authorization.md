# Quyền phía backend và giao dịch

Foreign key/CHECK bảo vệ dữ liệu; quyền người dùng phải kiểm tại service.
Không để client gửi SQL, user_id tác giả hoặc role có hiệu lực trực tiếp.

| Thao tác | Kiểm bắt buộc |
| --- | --- |
| Đọc channel/events/ảnh | Session hợp lệ, còn server member của channel |
| Đọc DM/events/ảnh | Session là một trong hai endpoint; chặn áp theo chính sách |
| Gửi/reply/react | Có quyền đọc, không bị hạn chế; reply/reaction cùng phòng |
| Sửa/xóa tin | Author; moderator/admin/owner chỉ được xóa theo chính sách |
| Ghim | Thành viên có quyền moderator/admin/owner; DM endpoint được ghim |
| Tạo/sửa/xóa channel | Owner hoặc admin của server |
| Mời người vào server | Owner/admin; mã còn hạn và chưa revoke |
| Đổi role/owner | Chỉ owner; không tự nâng role từ payload client |
| Sửa hồ sơ/tùy chọn | Chỉ user của session |
| Upload/gắn ảnh | Uploader của file, file ready, có quyền gửi trong phòng |
| Presence/read cursor | User của session, có quyền phòng |

Channel ban đầu đều public trong server; DM chỉ hai user.
Không có group DM, voice/video, tiền tệ, ví hoặc thanh toán.

Giao dịch bắt buộc:

- Tạo server + owner member + channel mặc định.
- Chấp nhận bạn bè + xóa request; block + gỡ friendship/request.
- Gửi tin + gắn ảnh/link + room_event; sửa/xóa/react/pin + event.
- Dùng invite + tăng use_count có điều kiện + member + invite_use.
- Chuyển owner + hai role member; không cho server thiếu owner ở cuối batch.
- Thay mật khẩu + revoke sessions; xóa mềm tin + gỡ nội dung nhạy cảm.

D1 dùng mỗi `prepare()` cho một statement, `batch()` cho nhiều statement.
Service dùng truy vấn có điều kiện để authorization và mutation không bị race;
không chỉ kiểm membership trước rồi chờ một request khác mới ghi.
Đặc biệt kiểm membership lại khi commit gửi tin trong lúc user bị kick.
Không dựa vào UI ẩn nút để bảo vệ thao tác.

Chưa có các service trong bước schema; không expose write API trước khi có chúng.
