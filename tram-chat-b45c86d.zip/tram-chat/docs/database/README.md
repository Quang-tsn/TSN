# Cơ sở dữ liệu Trạm

Schema SQL là nguồn chuẩn: [drizzle](../../drizzle/).
24 bảng sản phẩm; 9 migration có thứ tự trong `drizzle/meta/_journal.json`.
`sqlite_sequence` và `__drizzle_migrations` là bảng hệ thống, không thuộc 24 bảng.
Mọi thời gian dùng số nguyên epoch milliseconds; ID do backend tạo.
Database dùng D1 binding `DB`; ảnh nằm trong R2 binding `BUCKET`.

Từ điển dữ liệu:

- [Sơ đồ quan hệ](relationships.md): các khóa liên kết giữa bảng.
- [Tài khoản](accounts.md): hồ sơ, mật khẩu, phiên và tùy chọn.
- [Quan hệ và cộng đồng](communities.md): bạn bè, chặn, server, thành viên.
- [Phòng và tin nhắn](messages.md): channel, DM, reply, đọc và ghim.
- [Ảnh và liên kết](media.md): upload, attachment, preview và reaction.
- [Mời và cập nhật](events.md): mã mời, event cursor, presence và rate limit.
- [Quyền và giao dịch](authorization.md): quy tắc backend bắt buộc triển khai.

Khởi tạo bản local, tách biệt hoàn toàn với D1 hosted:

```powershell
python scripts/migrate-local.py
python -m unittest discover -s tests/database -p 'test_*.py' -v
```

Runner local ghi `.data/chat.sqlite`, bật foreign keys, kiểm hash migration.
Chạy lần nữa sẽ bỏ qua migration đã áp dụng; SQL khác hash bị từ chối.
Sites áp dụng migration D1 hosted khi deploy artifact chứa journal và SQL.
Không tạo bảng trong request handler; không đưa seed/backfill vào migration.
SQL đã áp dụng là bất biến: mọi thay đổi sau này thêm migration mới.
Không có tài khoản mẫu hay mật khẩu mặc định trong Database.

Giới hạn của bước này: schema chưa tạo API auth, upload hoặc chat.
Presence có TTL; query phải lọc `expires_at > now`, không chờ dọn mới ẩn.
`room_events` phục vụ cursor polling dự phòng, chưa phải WebSocket broadcast.
Typing được throttle; không ghi mỗi phím gõ. Chính sách dọn TTL sẽ ở backend.
