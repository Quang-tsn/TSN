# Tài khoản

Các cột `TEXT` ID không phải thông tin đăng nhập. `PK`: khóa chính.

| Bảng | Cột và ý nghĩa |
| --- | --- |
| `users` | `id` PK; `username` tên đăng nhập; `email` nullable; `display_name`; `avatar_file_id` nullable FK files; `status`; `bio`; `created_at`; `updated_at` |
| `password_credentials` | `user_id` PK/FK users; `password_hash`; `salt`; `algorithm`; `iterations`; `changed_at` |
| `sessions` | `id` PK; `user_id` FK; `token_hash`; `created_at`; `expires_at`; `last_seen_at`; `revoked_at` nullable |
| `user_preferences` | `user_id` PK/FK; `compact_messages`; `reduced_motion`; `allow_dms`; `updated_at` |

`username` unique không phân biệt hoa/thường, dài 3–32 ký tự.
`email` optional, unique NOCASE; dài 3–254, có `@` giữa local/domain không rỗng.
Không ép nhà cung cấp, không giả định đã xác minh quyền sở hữu email.
SQLite NOCASE chỉ xử lý ASCII; backend chuẩn hóa lowercase cho ASCII,
và dùng Unicode casefold nhất quán nếu cho phép Unicode trong định danh.
Backend kiểm và chuẩn hóa username/email trước cả lookup lẫn INSERT.
Username không chứa `@` để phân biệt username với email ở ô đăng nhập.
`display_name` 1–64 ký tự, bio tối đa 300.
Status lựa chọn: `online`, `idle`, `dnd`, `invisible`; online thực tế cần TTL.

Mật khẩu không lưu plaintext hoặc mã hóa có thể giải ngược.
Schema giữ hash, salt riêng và thuật toán `pbkdf2-sha256`.
`iterations >= 100000` là sàn tính toàn vẹn dữ liệu, chưa là tham số auth đã chốt.
Trước triển khai auth phải benchmark KDF trên Workers, xác minh mức bảo vệ
và CPU limit; không chọn tham số chỉ theo điều kiện CHECK của bảng.
Thay mật khẩu phải thu hồi các phiên cũ trong cùng giao dịch.

Session chỉ lưu SHA-256 hash token (64 hex), token gốc ở cookie HttpOnly.
Cookie: Secure, SameSite; backend phải kiểm expiry và revoked_at mỗi request.
`last_seen_at` dùng heartbeat có throttle, không cập nhật mỗi render.
Tùy chọn boolean lưu số 0/1; `allow_dms` mặc định bật.
Xóa user cascade credentials, sessions và preferences; lịch sử chat giữ user FK.
Đóng tài khoản sẽ ẩn danh hồ sơ trước, không DELETE phá lịch sử.
