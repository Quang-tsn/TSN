# ExtraAccount

Từ thanh hồ sơ trong chat, mở Cài đặt tại `/settings`. Trang gói có địa chỉ riêng `/extraaccount`.
Bvip kéo dài 12 giờ theo giờ máy chủ. Mở Lunor đi qua Trạm để bắt đầu đếm 90 giây
và chuyển hướng trong thẻ mới. Lunor từ chối nhúng iframe và Trạm không thể
quan sát độ tập trung của thẻ sau khi chuyển hướng.

Tin đã lưu có hạn mức 2,5 / 5 / 10 MB theo từng tài khoản. Máy chủ tính số byte UTF-8 của chữ,
dung lượng tệp ảnh và dữ liệu tham chiếu GIF hoặc sticker trên GIPHY.
Giới hạn Avip/Svip gồm tài khoản chính. Tài khoản phụ có danh tính và quyền vào server riêng.
Gói, huy hiệu và Tin đã lưu thuộc từng tài khoản, kể cả khi các tài khoản cùng nhóm.
Tin đã lưu có thể xếp vào thư mục cá nhân và tìm theo chữ, người gửi, kênh hoặc server.
Đổi thư mục giữ nguyên thời điểm lưu và dung lượng đã dùng.
Khi gói hết hạn, tài khoản chính vẫn chat cơ bản và có thể gia hạn.

Trong Cài đặt → Tài khoản, **Đổi tài khoản** cho phép đăng nhập hoặc đăng ký từ phiên hiện tại.
Tài khoản có gói hoặc nhóm riêng không thể đưa vào nhóm khác. Chỉ phiên được cấp từ nhóm mới
có quyền đổi qua các tài khoản trong nhóm. Phiên đăng nhập độc lập không có quyền này.

Svip hỗ trợ avatar và ảnh nền PNG, JPEG hoặc GIF. Bvip và Avip dùng avatar PNG hoặc JPEG.
Ảnh nền Svip xuất hiện ở tên người gửi và thẻ hồ sơ mở khi bấm vào avatar. Ảnh hồ sơ có thể
được xem bởi người dùng cùng server. Máy chủ kiểm tra quyền trước khi trả ảnh từ kho R2.

## Biến môi trường Site

- `GIPHY_API_KEY`: API key Web. Tìm kiếm trực tiếp từ trình duyệt.
  Khi chưa có key, chọn GIF/sticker bằng liên kết chia sẻ GIPHY.
- `EXTRA_CODE_ADMIN_KEY`: khóa bí mật cho API cấp mã. Dùng chuỗi ngẫu nhiên mạnh và thiết lập dưới dạng secret.
- Google Pay, Apple Pay và MoMo hiển thị nhãn Coming soon.

## Cấp và dùng mã

Đặt `EXTRA_CODE_ADMIN_KEY` trong môi trường của tiến trình quản trị và Site.
Với Site riêng tư, tiến trình có thể gửi quyền truy cập Site qua `TRAM_SITE_ACCESS_TOKEN`.
Chạy `node scripts/issue-extra-code.mjs <URL Site> Avip week` để nhận một mã.
Dùng `Avip` hoặc `Svip` với `week` (7 ngày) hoặc `month` (30 ngày).
Chia sẻ mã riêng cho người nhận. D1 lưu mã băm và cấp quyền một lần cho tài khoản dùng mã.
Người nhận mở `/extraaccount`, chọn **Nhập mã** ở Avip hoặc Svip rồi bấm **Kích hoạt**.
Gia hạn cùng gói cộng thêm thời lượng còn lại. Kết quả xuất hiện trong Cài đặt → Lịch sử mã.

## Kiểm thử

`npm run db:migrate`, `npm run build`, `npm run test:server`, `npm run test:database`.
Kiểm thử đổi mã dùng SQLite có migration thực. Kiểm thử ảnh dùng bucket bộ nhớ.
