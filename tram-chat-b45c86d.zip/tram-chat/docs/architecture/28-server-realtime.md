# Đồng bộ qua event cursor

[Danh mục kiến trúc](index.md) · [Danh sách đường dẫn](../../architecture/28-server-realtime.txt)

`[H]`: tệp hiện có ở bước nền; `[P]`: dự kiến, chưa tạo.
Chỉ tạo module khi triển khai cụm tương ứng; không tạo file rỗng.

```text
tram-chat/
└── server/
    └── realtime/
        ├── TransportContract.ts [P]
        ├── RoomEventPayload.ts [P]
        ├── readIncrementalEvents.ts [P]
        ├── buildResetResponse.ts [P]
        ├── appendRoomEvent.ts [P]
        ├── serializeRoomEvent.ts [P]
        ├── checkCursorRetention.ts [P]
        ├── getTypingSnapshot.ts [P]
        ├── expireTyping.ts [P]
        ├── getPresenceSnapshot.ts [P]
        ├── getPollInterval.ts [P]
        └── authorizeEventRead.ts [P]
```

