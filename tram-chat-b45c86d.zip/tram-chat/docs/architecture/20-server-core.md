# HTTP Worker và lớp kiểm soát chung

[Danh mục kiến trúc](index.md) · [Danh sách đường dẫn](../../architecture/20-server-core.txt)

`[H]`: tệp hiện có ở bước nền; `[P]`: dự kiến, chưa tạo.
Chỉ tạo module khi triển khai cụm tương ứng; không tạo file rỗng.

```text
tram-chat/
└── server/
    ├── http/
    │   ├── parseJsonBody.ts [P]
    │   ├── readCookie.ts [P]
    │   ├── setSessionCookie.ts [P]
    │   ├── clearSessionCookie.ts [P]
    │   ├── errorResponse.ts [P]
    │   ├── withErrorBoundary.ts [P]
    │   ├── requireMethod.ts [P]
    │   └── checkSameOrigin.ts [P]
    ├── errors/
    │   ├── HttpError.ts [P]
    │   └── toHttpError.ts [P]
    ├── types/
    │   ├── RequestContext.ts [P]
    │   ├── AuthenticatedContext.ts [P]
    │   ├── SqlResult.ts [P]
    │   └── Clock.ts [P]
    ├── constants/
    │   ├── security.ts [P]
    │   ├── limits.ts [P]
    │   ├── eventKinds.ts [P]
    │   └── reactionKinds.ts [P]
    ├── utils/
    │   ├── newId.ts [P]
    │   ├── nowUtc.ts [P]
    │   ├── parseCursor.ts [P]
    │   ├── createCursor.ts [P]
    │   └── normalizeIdentity.ts [P]
    └── middleware/
        ├── requireSession.ts [P]
        ├── requireRoomAccess.ts [P]
        ├── requireServerMember.ts [P]
        ├── requirePermission.ts [P]
        └── rateLimit.ts [P]
```

