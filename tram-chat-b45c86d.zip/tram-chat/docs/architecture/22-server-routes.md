# Mỗi route một file

[Danh mục kiến trúc](index.md) · [Danh sách đường dẫn](../../architecture/22-server-routes.txt)

`[H]`: tệp hiện có ở bước nền; `[P]`: dự kiến, chưa tạo.
Chỉ tạo module khi triển khai cụm tương ứng; không tạo file rỗng.

```text
tram-chat/
└── server/
    └── routes/
        ├── auth/
        │   ├── postRegister.ts [P]
        │   ├── postLogin.ts [P]
        │   ├── postLogout.ts [P]
        │   ├── getSession.ts [P]
        │   ├── patchPassword.ts [P]
        │   ├── getSessions.ts [P]
        │   └── deleteSession.ts [P]
        ├── users/
        │   ├── getUser.ts [P]
        │   ├── patchProfile.ts [P]
        │   ├── getSettings.ts [P]
        │   └── patchSettings.ts [P]
        ├── friends/
        │   ├── getFriends.ts [P]
        │   ├── postFriendRequest.ts [P]
        │   ├── patchFriendRequest.ts [P]
        │   └── deleteFriend.ts [P]
        ├── dm/
        │   ├── getDirectMessages.ts [P]
        │   └── postDirectMessage.ts [P]
        ├── servers/
        │   ├── getServers.ts [P]
        │   ├── postServer.ts [P]
        │   ├── patchServer.ts [P]
        │   ├── deleteServer.ts [P]
        │   └── postLeaveServer.ts [P]
        ├── channels/
        │   ├── getChannels.ts [P]
        │   ├── postChannel.ts [P]
        │   ├── patchChannel.ts [P]
        │   └── deleteChannel.ts [P]
        ├── messages/
        │   ├── getMessages.ts [P]
        │   ├── postMessage.ts [P]
        │   ├── patchMessage.ts [P]
        │   ├── deleteMessage.ts [P]
        │   ├── putReaction.ts [P]
        │   ├── deleteReaction.ts [P]
        │   ├── getPins.ts [P]
        │   ├── putPin.ts [P]
        │   ├── deletePin.ts [P]
        │   └── putReadCursor.ts [P]
        ├── rooms/
        │   ├── getRoomEvents.ts [P]
        │   └── putTyping.ts [P]
        └── uploads/
            ├── postImage.ts [P]
            ├── getImage.ts [P]
            └── deleteImage.ts [P]
```

