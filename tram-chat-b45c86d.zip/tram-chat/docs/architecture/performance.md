# Giới hạn iPhone 7

## Tin nhắn và bộ nhớ

- DOM chứa tối đa 50 hàng tin nhắn, kể cả tin đang gửi.
- API cũng giới hạn mỗi trang 50; history dùng cursor (created_at, id).
- Chỉ một room có subscription foreground; hủy request khi đổi phòng.
- Cache tối đa 3 room × 100 message; room đang đọc vẫn render tối đa 50.
- Cache loại LRU; không giữ lịch sử vô hạn trong context hoặc localStorage.
- Draft tối đa 10 room, 4000 ký tự mỗi room; không lưu blob/base64 trong draft.
- Event batch có trần; dữ liệu cũ được dọn trước khi nối trang mới.
- Giữ scroll anchor khi chuyển cửa sổ; đo layout theo requestAnimationFrame.
- Khi người dùng đang đọc cũ, hiện “Tin nhắn mới”, không ép cuộn xuống.
- Không download và giữ toàn bộ lịch sử chỉ để tìm tin nhắn được reply.
- Revoke object URL khi thay ảnh, xóa upload, đổi room hoặc unmount.

## Ảnh

- Mỗi tin tối đa 4 ảnh; SQL giới hạn mỗi file 8 MiB.
- Backend cần thêm giới hạn tổng dung lượng và tổng pixel trước decode.
- Thumbnail có width/height cố định để tránh layout nhảy.
- Ảnh ngoài viewport lazy-load; ảnh gốc chỉ mở khi người dùng chọn xem.
- Hạn chế số upload đồng thời; tránh decode nhiều ảnh lớn cùng lúc.

## Safari và bàn phím

- Dùng 100dvh khi có hỗ trợ; Safari 15.0–15.3 cần fallback.
- `useVisualViewport` cập nhật CSS --app-height bằng visualViewport.height.
- Fallback cuối là window.innerHeight; listener resize chạy qua rAF.
- Dùng safe-area-inset-bottom và viewport-fit=cover.
- Không giả định dvh tự xử lý mọi tình huống bàn phím iOS.
- Kiểm tra mở/đóng bàn phím, xoay máy, focus input và quay lại từ background.
- Cleanup listener và timer; tránh forced synchronous layout khi gõ.

## Render và mạng

- Chỉ transition transform/opacity; không blur và không shadow dày.
- Không animation chạy liên tục cho thành phần trang trí.
- Poll nền dừng khi tab ẩn; reconnect có backoff và jitter.
- Typing gửi theo throttle và TTL, không ghi D1 trên từng phím.
- Presence heartbeat thưa; dữ liệu hết TTL không được coi là online.
- Mục tiêu là 60FPS; phải đo trên iPhone 7 thật trước khi xác nhận.
- Không hứa “không bao giờ văng”; theo dõi memory, frame và network thực tế.

Safari thêm dvh từ 15.4: [tài liệu WebKit](https://webkit.org/blog/12445/new-webkit-features-in-safari-15-4/).

