# Thứ tự triển khai

1. **Nền dữ liệu — phase hiện tại:** SQL migrations, DB health, build/check-lines.
2. **Auth:** PBKDF2, rate limit, cookie sessions và form login/register.
3. **Khung Discord:** rail, sidebar, profile panel, drawer mobile và SVG.
4. **Server và kênh:** tạo/join bằng invite, membership và role cố định.
5. **Bạn bè và DM:** request/accept/remove, DM pair duy nhất, block/allow_dms.
6. **Tin nhắn cơ bản:** cursor API, composer, 50-row DOM window, bounded cache.
7. **Đồng bộ:** room_events, polling có cursor, typing và presence TTL.
8. **Tương tác tin:** reply, edit/delete, reactions SVG, pins và read cursor.
9. **Ảnh và embed:** R2, upload policy, thumbnails, preview cache và URL policy.
10. **Cài đặt và mobile QA:** profile, sessions, role assignment, iPhone 7 thực tế.
11. **Push transport:** chỉ sau khi coordination được xác minh và kiểm thử.

Mỗi cụm hoàn thành một luồng dùng được, kèm kiểm chứng phù hợp.
Mã UI và module dự kiến không được tạo rỗng ở bước khởi tạo DB.
Không gọi tính năng đã hoàn thành chỉ vì có type, bảng hoặc mục trong cây file.
Giữ mọi file tự viết ≤80 dòng; ưu tiên module khoảng 60 dòng.
Các test trong danh mục cũng là kế hoạch, trừ tệp có ký hiệu [H].

## Phạm vi role

Schema hiện tại chỉ hỗ trợ bốn role cố định.
Role settings hiển thị quyền và gán role; không có custom role editor.
Custom role và ACL kênh riêng cần thiết kế/migration riêng khi được triển khai.

