# Repository chat và đồng bộ

[Danh mục kiến trúc](index.md) · [Danh sách đường dẫn](../../architecture/26-server-repositories-chat.txt)

`[H]`: tệp hiện có ở bước nền; `[P]`: dự kiến, chưa tạo.
Chỉ tạo module khi triển khai cụm tương ứng; không tạo file rỗng.

```text
tram-chat/
└── server/
    └── repositories/
        ├── rooms/
        │   ├── findRoom.ts [P]
        │   ├── findRoomMember.ts [P]
        │   ├── readRoomCursor.ts [P]
        │   └── updateReadCursor.ts [P]
        ├── messages/
        │   ├── findMessage.ts [P]
        │   ├── listMessagePage.ts [P]
        │   ├── insertMessage.ts [P]
        │   ├── updateMessage.ts [P]
        │   ├── softDeleteMessage.ts [P]
        │   ├── listMessageAttachments.ts [P]
        │   └── listMessageEmbeds.ts [P]
        ├── reactions/
        │   ├── listMessageReactions.ts [P]
        │   ├── insertReaction.ts [P]
        │   └── deleteReaction.ts [P]
        ├── pins/
        │   ├── listPinnedMessages.ts [P]
        │   ├── insertPin.ts [P]
        │   └── deletePin.ts [P]
        ├── events/
        │   ├── insertRoomEvent.ts [P]
        │   ├── listRoomEvents.ts [P]
        │   ├── findOldestRoomEvent.ts [P]
        │   └── pruneRoomEvents.ts [P]
        ├── typing/
        │   ├── upsertTyping.ts [P]
        │   ├── listActiveTyping.ts [P]
        │   └── deleteTyping.ts [P]
        ├── presence/
        │   ├── upsertPresence.ts [P]
        │   ├── listPresence.ts [P]
        │   └── deleteExpiredPresence.ts [P]
        ├── uploads/
        │   ├── insertUpload.ts [P]
        │   ├── findUpload.ts [P]
        │   ├── linkMessageUpload.ts [P]
        │   └── deleteUpload.ts [P]
        └── embeds/
            ├── findCachedEmbed.ts [P]
            ├── upsertCachedEmbed.ts [P]
            └── linkMessageEmbed.ts [P]
```

