# Thành phần UI nguyên tử

[Danh mục kiến trúc](index.md) · [Danh sách đường dẫn](../../architecture/05-primitives.txt)

`[H]`: tệp hiện có ở bước nền; `[P]`: dự kiến, chưa tạo.
Chỉ tạo module khi triển khai cụm tương ứng; không tạo file rỗng.

```text
tram-chat/
└── src/
    └── components/
        └── primitives/
            ├── Button.tsx [P]
            ├── IconButton.tsx [P]
            ├── TextInput.tsx [P]
            ├── PasswordInput.tsx [P]
            ├── TextArea.tsx [P]
            ├── FieldLabel.tsx [P]
            ├── FieldError.tsx [P]
            ├── Avatar.tsx [P]
            ├── PresenceDot.tsx [P]
            ├── Divider.tsx [P]
            ├── Badge.tsx [P]
            ├── Tooltip.tsx [P]
            ├── Menu.tsx [P]
            ├── MenuItem.tsx [P]
            ├── Dialog.tsx [H]
            ├── DialogTitle.tsx [P]
            ├── DialogActions.tsx [P]
            ├── EmptyState.tsx [P]
            ├── LoadingState.tsx [P]
            ├── InlineError.tsx [P]
            ├── Toast.tsx [P]
            ├── ToastViewport.tsx [P]
            ├── FocusTrap.tsx [P]
            └── VisuallyHidden.tsx [P]
```

