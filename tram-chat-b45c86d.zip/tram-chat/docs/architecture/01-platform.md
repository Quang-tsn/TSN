# Nền dự án và file đã triển khai

[Danh mục kiến trúc](index.md) · [Danh sách đường dẫn](../../architecture/01-platform.txt)

`[H]`: tệp hiện có ở bước nền; `[P]`: dự kiến, chưa tạo.
Chỉ tạo module khi triển khai cụm tương ứng; không tạo file rỗng.

```text
tram-chat/
├── package.json [H]
├── package-lock.json [H]
├── tsconfig.json [H]
├── tsconfig.app.json [P]
├── tsconfig.server.json [P]
├── vite.config.ts [P]
├── index.html [P]
├── .gitignore [H]
├── .openai/
│   └── hosting.json [H]
├── README.md [H]
├── scripts/
│   ├── build.mjs [H]
│   ├── check-lines.mjs [H]
│   ├── migrate-local.py [H]
│   ├── check-architecture.mjs [P]
│   └── migration_store.py [H]
├── server/
│   ├── worker.ts [H]
│   ├── router.ts [H]
│   ├── http/
│   │   ├── jsonResponse.ts [H]
│   │   └── notFound.ts [H]
│   ├── types/
│   │   ├── Database.ts [H]
│   │   └── Env.ts [H]
│   ├── constants/
│   │   └── requiredTables.ts [H]
│   ├── repositories/
│   │   └── database/
│   │       └── readTableNames.ts [H]
│   ├── services/
│   │   └── health/
│   │       └── getDatabaseHealth.ts [H]
│   └── routes/
│       └── health/
│           └── getHealth.ts [H]
└── src/
    ├── main.tsx [H]
    ├── App.tsx [H]
    └── app/
        ├── AppProviders.tsx [P]
        ├── AppRouter.tsx [P]
        └── RouteBoundary.tsx [P]
```

