# Mật khẩu và phiên đăng nhập

[Danh mục kiến trúc](index.md) · [Danh sách đường dẫn](../../architecture/21-server-auth.txt)

`[H]`: tệp hiện có ở bước nền; `[P]`: dự kiến, chưa tạo.
Chỉ tạo module khi triển khai cụm tương ứng; không tạo file rỗng.

```text
tram-chat/
└── server/
    ├── auth/
    │   ├── createPasswordSalt.ts [P]
    │   ├── derivePasswordHash.ts [H]
    │   ├── verifyPassword.ts [P]
    │   ├── constantTimeEqual.ts [H]
    │   ├── createSessionToken.ts [P]
    │   ├── hashSessionToken.ts [H]
    │   ├── getSessionExpiry.ts [P]
    │   └── verifyCsrfToken.ts [P]
    ├── services/
    │   └── auth/
    │       ├── registerAccount.ts [H]
    │       ├── loginAccount.ts [H]
    │       ├── logoutAccount.ts [H]
    │       ├── getCurrentSession.ts [H]
    │       ├── changePassword.ts [P]
    │       └── revokeSession.ts [P]
    └── repositories/
        └── auth/
            ├── findLoginIdentity.ts [H]
            ├── insertAccount.ts [P]
            ├── findCredential.ts [P]
            ├── updateCredential.ts [P]
            ├── insertSession.ts [P]
            ├── findSessionByHash.ts [P]
            ├── deleteSession.ts [P]
            ├── deleteUserSessions.ts [P]
            └── listUserSessions.ts [P]
```

