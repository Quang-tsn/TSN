# HTTP client và truy cập backend

[Danh mục kiến trúc](index.md) · [Danh sách đường dẫn](../../architecture/17-client-services.txt)

`[H]`: tệp hiện có ở bước nền; `[P]`: dự kiến, chưa tạo.
Chỉ tạo module khi triển khai cụm tương ứng; không tạo file rỗng.

```text
tram-chat/
└── src/
    └── services/
        ├── http/
        │   ├── request.ts [P]
        │   ├── readResponse.ts [P]
        │   ├── createApiError.ts [P]
        │   └── getCsrfHeader.ts [P]
        ├── auth/
        │   ├── login.ts [P]
        │   ├── register.ts [P]
        │   ├── logout.ts [P]
        │   ├── getSession.ts [P]
        │   └── changePassword.ts [P]
        ├── friends/
        │   ├── listFriends.ts [P]
        │   ├── sendFriendRequest.ts [P]
        │   ├── respondToFriendRequest.ts [P]
        │   └── removeFriend.ts [P]
        ├── dm/
        │   ├── listDirectMessages.ts [P]
        │   └── openDirectMessage.ts [P]
        ├── servers/
        │   ├── listServers.ts [P]
        │   ├── createServer.ts [P]
        │   ├── updateServer.ts [P]
        │   ├── leaveServer.ts [P]
        │   └── deleteServer.ts [P]
        ├── channels/
        │   ├── listChannels.ts [P]
        │   ├── createChannel.ts [P]
        │   ├── updateChannel.ts [P]
        │   └── deleteChannel.ts [P]
        ├── messages/
        │   ├── listMessages.ts [P]
        │   ├── sendMessage.ts [P]
        │   ├── editMessage.ts [P]
        │   ├── deleteMessage.ts [P]
        │   ├── toggleReaction.ts [P]
        │   ├── listPins.ts [P]
        │   ├── togglePin.ts [P]
        │   └── markRead.ts [P]
        ├── members/
        │   ├── listMembers.ts [P]
        │   └── kickMember.ts [P]
        ├── uploads/
        │   ├── uploadImage.ts [P]
        │   └── deleteUpload.ts [P]
        └── invites/
            ├── createInvite.ts [P]
            ├── acceptInvite.ts [P]
            ├── listInvites.ts [P]
            └── revokeInvite.ts [P]
```

