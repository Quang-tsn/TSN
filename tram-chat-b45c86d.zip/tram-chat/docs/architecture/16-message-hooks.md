# Hooks message, đồng bộ và hiệu năng

[Danh mục kiến trúc](index.md) · [Danh sách đường dẫn](../../architecture/16-message-hooks.txt)

`[H]`: tệp hiện có ở bước nền; `[P]`: dự kiến, chưa tạo.
Chỉ tạo module khi triển khai cụm tương ứng; không tạo file rỗng.

```text
tram-chat/
└── src/
    └── hooks/
        ├── messages/
        │   ├── useMessages.ts [P]
        │   ├── useMessageWindow.ts [P]
        │   ├── useMessagePagination.ts [P]
        │   ├── useMessageActions.ts [P]
        │   ├── useMessageReactions.ts [P]
        │   ├── usePinnedMessages.ts [P]
        │   ├── useReadCursor.ts [P]
        │   ├── useScrollAnchor.ts [P]
        │   └── useRoomDraft.ts [P]
        ├── realtime/
        │   ├── useRoomSubscription.ts [P]
        │   ├── useRoomEvents.ts [P]
        │   ├── useTyping.ts [P]
        │   ├── useTypingExpiry.ts [P]
        │   └── useConnectionState.ts [P]
        ├── platform/
        │   ├── useVisualViewport.ts [P]
        │   ├── useDocumentVisibility.ts [P]
        │   ├── useReducedMotion.ts [P]
        │   ├── useOnlineState.ts [P]
        │   ├── useIntersection.ts [P]
        │   └── useMediaQuery.ts [P]
        └── ui/
            ├── useOutsideClick.ts [P]
            ├── useToast.ts [P]
            └── useEscapeKey.ts [P]
```

