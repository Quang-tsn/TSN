# Cụm xác thực đã triển khai

- Đăng ký username + mật khẩu; email tùy chọn, không OAuth.
- Username ASCII được trim/lowercase trước INSERT và lookup.
- Email được lowercase; chưa xác minh quyền sở hữu hoặc reset password.
- Mật khẩu 12–128 ký tự, PBKDF2-SHA256, salt ngẫu nhiên 16 byte.
- Work factor 100.000 vòng tương thích Workers; cần đánh giá lại khi mở rộng.
- Cookie __Host-tram_session: HttpOnly, Secure, SameSite=Lax, Path=/.
- Session 7 ngày, DB chỉ lưu SHA256 token; tối đa 20 phiên mỗi tài khoản.
- Logout xóa session phía server, cookie Max-Age=0.
- POST bắt buộc Origin cùng origin và X-Tram-Request: 1, JSON tối đa 8 KiB.
- Rate limit bền vững: 12 lần/identity và 60 lần/IP mỗi 15 phút.
- SQL mutation dùng parameter binding; tạo account và credential cùng batch.
- Không có tài khoản test hoặc mật khẩu mẫu trên D1 hosted.

Frontend React được esbuild bundle nhắm Safari 15, phục vụ cùng Worker origin.
Chưa cần Vite; giữ một build pipeline cho cụm auth nhỏ hiện tại.
Logo và HashIcon là SVG tự vẽ; chưa triển khai 50 icon còn lại.
CSS dùng nền đặc, hairline, font hệ thống; không blur hoặc animation library.

Kiểm chứng: 16 DB tests, 9 backend tests, typecheck, build, check:lines.
Backend auth tests dùng SQLite thật, cùng 9 SQL migrations với D1.
Đã kiểm UI local: register, reload/restore, logout và login.
Đã xem bố cục màn hình hẹp; chưa kiểm Safari/iPhone 7 vật lý.

Các phần tiếp theo: rail/sidebar/profile, server/kênh, bạn bè/DM và chat.
Site tiếp tục riêng tư theo quyền nền tảng; chưa mở đăng ký cho công chúng.
