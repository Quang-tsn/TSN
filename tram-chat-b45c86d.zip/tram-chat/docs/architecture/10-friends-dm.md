# Bạn bè và DM 1–1

[Danh mục kiến trúc](index.md) · [Danh sách đường dẫn](../../architecture/10-friends-dm.txt)

`[H]`: tệp hiện có ở bước nền; `[P]`: dự kiến, chưa tạo.
Chỉ tạo module khi triển khai cụm tương ứng; không tạo file rỗng.

```text
tram-chat/
└── src/
    ├── components/
    │   └── discord/
    │       ├── friends/
    │       │   ├── FriendsPage.tsx [P]
    │       │   ├── FriendsHeader.tsx [P]
    │       │   ├── FriendsTabs.tsx [P]
    │       │   ├── FriendsList.tsx [P]
    │       │   ├── FriendRow.tsx [P]
    │       │   ├── FriendActions.tsx [P]
    │       │   ├── FriendRequestRow.tsx [P]
    │       │   ├── AddFriendForm.tsx [P]
    │       │   ├── FriendsEmptyState.tsx [P]
    │       │   └── Friends.module.css [P]
    │       └── channel-sidebar/
    │           ├── DmSidebar.tsx [P]
    │           ├── DmList.tsx [P]
    │           ├── DmRow.tsx [P]
    │           ├── DmUnreadBadge.tsx [P]
    │           └── NewDmButton.tsx [P]
    └── hooks/
        ├── friends/
        │   ├── useFriends.ts [P]
        │   ├── useFriendRequests.ts [P]
        │   └── useFriendActions.ts [P]
        └── dm/
            ├── useDirectMessages.ts [P]
            └── useOpenDirectMessage.ts [P]
```

