# Ảnh R2 và link preview

[Danh mục kiến trúc](index.md) · [Danh sách đường dẫn](../../architecture/29-server-media-embed.txt)

`[H]`: tệp hiện có ở bước nền; `[P]`: dự kiến, chưa tạo.
Chỉ tạo module khi triển khai cụm tương ứng; không tạo file rỗng.

```text
tram-chat/
└── server/
    ├── media/
    │   ├── readUploadBody.ts [P]
    │   ├── checkImageSignature.ts [P]
    │   ├── checkImageDimensions.ts [P]
    │   ├── createObjectKey.ts [P]
    │   ├── writeImageObject.ts [P]
    │   ├── readImageObject.ts [P]
    │   ├── deleteImageObject.ts [P]
    │   ├── buildImageResponse.ts [P]
    │   ├── assertUploadOwnership.ts [P]
    │   └── assertUploadQuota.ts [P]
    ├── services/
    │   ├── uploads/
    │   │   ├── uploadImage.ts [P]
    │   │   ├── deleteUpload.ts [P]
    │   │   └── readAuthorizedImage.ts [P]
    │   └── embeds/
    │       └── enrichMessageLinks.ts [P]
    └── link-preview/
        ├── extractMessageUrls.ts [P]
        ├── validatePreviewUrl.ts [P]
        ├── resolveSafeRedirect.ts [P]
        ├── fetchPreviewHtml.ts [P]
        ├── readLimitedBody.ts [P]
        ├── parseOpenGraph.ts [P]
        ├── sanitizeMetadata.ts [P]
        ├── getCachedPreview.ts [P]
        └── buildPreview.ts [P]
```

