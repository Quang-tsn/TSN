# Repository cộng đồng và tài khoản

[Danh mục kiến trúc](index.md) · [Danh sách đường dẫn](../../architecture/25-server-repositories-community.txt)

`[H]`: tệp hiện có ở bước nền; `[P]`: dự kiến, chưa tạo.
Chỉ tạo module khi triển khai cụm tương ứng; không tạo file rỗng.

```text
tram-chat/
└── server/
    └── repositories/
        ├── users/
        │   ├── findUserById.ts [P]
        │   ├── findUserByUsername.ts [P]
        │   ├── updateProfile.ts [P]
        │   ├── readSettings.ts [P]
        │   └── writeSettings.ts [P]
        ├── friends/
        │   ├── listFriendships.ts [P]
        │   ├── findFriendship.ts [P]
        │   ├── insertFriendRequest.ts [P]
        │   ├── updateFriendRequest.ts [P]
        │   └── deleteFriendship.ts [P]
        ├── dm/
        │   ├── findDirectPair.ts [P]
        │   ├── createDirectRoom.ts [P]
        │   └── listDirectRooms.ts [P]
        ├── servers/
        │   ├── listUserServers.ts [P]
        │   ├── insertServer.ts [P]
        │   ├── findServer.ts [P]
        │   ├── updateServer.ts [P]
        │   └── deleteServer.ts [P]
        ├── channels/
        │   ├── listChannels.ts [P]
        │   ├── insertChannel.ts [P]
        │   ├── findChannel.ts [P]
        │   ├── updateChannel.ts [P]
        │   └── deleteChannel.ts [P]
        ├── members/
        │   ├── findMember.ts [P]
        │   ├── listMembers.ts [P]
        │   ├── insertMember.ts [P]
        │   ├── deleteMember.ts [P]
        │   ├── readMemberRole.ts [P]
        │   └── updateMemberRole.ts [P]
        └── invites/
            ├── findInviteByHash.ts [P]
            ├── insertInvite.ts [P]
            ├── consumeInvite.ts [P]
            ├── listInvites.ts [P]
            └── revokeInvite.ts [P]
```

