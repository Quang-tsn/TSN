# Toàn bộ SVG tự vẽ

[Danh mục kiến trúc](index.md) · [Danh sách đường dẫn](../../architecture/04-svg-icons.txt)

`[H]`: tệp hiện có ở bước nền; `[P]`: dự kiến, chưa tạo.
Chỉ tạo module khi triển khai cụm tương ứng; không tạo file rỗng.

```text
tram-chat/
└── src/
    └── components/
        └── icons/
            ├── BrandLogo.tsx [H]
            ├── HomeIcon.tsx [P]
            ├── HashIcon.tsx [H]
            ├── DirectMessageIcon.tsx [P]
            ├── UsersIcon.tsx [H]
            ├── UserPlusIcon.tsx [H]
            ├── UserMinusIcon.tsx [P]
            ├── ServerPlusIcon.tsx [H]
            ├── JoinServerIcon.tsx [H]
            ├── ChevronDownIcon.tsx [P]
            ├── ChevronRightIcon.tsx [P]
            ├── MenuIcon.tsx [H]
            ├── CloseIcon.tsx [H]
            ├── SearchIcon.tsx [P]
            ├── SettingsIcon.tsx [P]
            ├── LogoutIcon.tsx [H]
            ├── MoreIcon.tsx [P]
            ├── SendIcon.tsx [H]
            ├── PlusIcon.tsx [H]
            ├── ImageIcon.tsx [P]
            ├── AttachmentIcon.tsx [P]
            ├── ReplyIcon.tsx [P]
            ├── EditIcon.tsx [H]
            ├── TrashIcon.tsx [P]
            ├── PinIcon.tsx [P]
            ├── UnpinIcon.tsx [P]
            ├── ReactionIcon.tsx [P]
            ├── SmileIcon.tsx [P]
            ├── HeartIcon.tsx [P]
            ├── ThumbsUpIcon.tsx [P]
            ├── CheckIcon.tsx [P]
            ├── CopyIcon.tsx [P]
            ├── LinkIcon.tsx [P]
            ├── ExternalLinkIcon.tsx [P]
            ├── BellIcon.tsx [P]
            ├── BellOffIcon.tsx [P]
            ├── LockIcon.tsx [P]
            ├── ShieldIcon.tsx [P]
            ├── BackIcon.tsx [P]
            ├── SpinnerIcon.tsx [P]
            ├── AlertIcon.tsx [P]
            ├── EyeIcon.tsx [P]
            ├── EyeOffIcon.tsx [P]
            ├── AtSignIcon.tsx [P]
            ├── ClockIcon.tsx [P]
            ├── RetryIcon.tsx [P]
            ├── DownloadIcon.tsx [P]
            ├── ExpandIcon.tsx [P]
            ├── LaughIcon.tsx [P]
            ├── SurprisedIcon.tsx [P]
            ├── SadIcon.tsx [P]
            └── CelebrateIcon.tsx [P]
```

