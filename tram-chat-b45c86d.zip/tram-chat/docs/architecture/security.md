# Auth và quyền truy cập

## Tài khoản tự chủ

- Đăng nhập bằng username hoặc email đã đăng ký; email là tùy chọn.
- Chuẩn hóa username; định nghĩa rõ ASCII/case folding trước mở đăng ký.
- Email không cần Google và chưa được xác minh quyền sở hữu.
- Chưa triển khai email reset password; không giả lập gửi email thành công.
- PBKDF2-SHA-256 dùng Workers Web Crypto, salt ngẫu nhiên riêng từng mật khẩu.
- Lưu thuật toán, iterations, salt và hash; không lưu mật khẩu gốc.
- Work factor phải đo/kiểm chứng trên runtime trước bật auth production.
- Session token là bytes ngẫu nhiên; D1 chỉ lưu SHA-256 token.
- Cookie Secure, HttpOnly, SameSite=Lax và Path=/; không lưu token trong JS.
- Kiểm Origin và CSRF trên mutation; response session không chứa token hash.
- Lỗi đăng nhập không tiết lộ identity tồn tại; rate limit có expiry.
- Đổi mật khẩu thu hồi session khác; revoke/logout có hiệu lực phía server.

## Phân quyền

- Mọi message/read/event/upload đều kiểm quyền của room ở backend.
- Channel yêu cầu server membership; DM chỉ cho hai user trong cặp.
- Chặn không được vượt qua bằng request trực tiếp; tôn trọng allow_dms.
- Owner/admin/moderator/member ánh xạ permission cố định, mặc định từ chối.
- Owner_id phải khớp owner membership; không cho owner rời khi chưa chuyển quyền.
- Member role mutation không được tự nâng quyền hoặc đổi owner tùy tiện.
- Reply, pin và read cursor phải tham chiếu message cùng room.
- Edit/delete kiểm author hoặc quyền moderation; ghi room_event cùng mutation.
- Invite lưu hash; redeem kiểm hạn dùng và tăng lượt dùng nguyên tử.
- Không chỉ ẩn nút UI rồi bỏ qua kiểm tra backend.

## Ảnh và preview

- R2 object_key không phải quyền truy cập; endpoint ảnh kiểm room hoặc uploader.
- Chỉ gắn file thuộc uploader, trạng thái ready và chưa gắn message khác.
- Kiểm magic bytes, MIME, kích thước và pixel count; không tin tên file.
- Ảnh avatar/server icon cũng kiểm ownership; không phục vụ SVG upload tùy ý.
- Preview chỉ fetch HTTP(S) được phép, chặn loopback/private/link-local/metadata.
- Mỗi redirect kiểm lại URL; cấm credential URL và giới hạn số redirect.
- Chưa xác minh DNS rebinding thì dùng allowlist host public thay vì fetch tùy ý.
- Timeout, byte limit và content-type limit áp dụng cả body preview.
- Metadata render dưới dạng text; không đưa HTML website vào dangerouslySetInnerHTML.
- Không tải tài nguyên tùy ý chỉ vì có og:image; áp dụng chính sách URL tương tự.

## Dữ liệu

- SQL dùng bind parameter, batch nguyên tử cho mutation liên quan.
- Xóa tin dùng tombstone để reply/cursor hoạt động; không lộ content đã xóa.
- DB constraint hỗ trợ integrity; service kiểm quan hệ ownership và permission.
- Dọn session, rate limit, presence, upload mồ côi và event quá hạn có giới hạn.

