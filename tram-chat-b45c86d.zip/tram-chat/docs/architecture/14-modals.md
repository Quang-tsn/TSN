# Các hộp thoại

[Danh mục kiến trúc](index.md) · [Danh sách đường dẫn](../../architecture/14-modals.txt)

`[H]`: tệp hiện có ở bước nền; `[P]`: dự kiến, chưa tạo.
Chỉ tạo module khi triển khai cụm tương ứng; không tạo file rỗng.

```text
tram-chat/
└── src/
    ├── components/
    │   └── discord/
    │       └── modals/
    │           ├── ModalHost.tsx [P]
    │           ├── CreateServerModal.tsx [P]
    │           ├── JoinServerModal.tsx [P]
    │           ├── InviteMembersModal.tsx [P]
    │           ├── InviteCodeField.tsx [P]
    │           ├── CreateChannelModal.tsx [P]
    │           ├── EditChannelModal.tsx [P]
    │           ├── DeleteChannelModal.tsx [P]
    │           ├── LeaveServerModal.tsx [P]
    │           ├── DeleteServerModal.tsx [P]
    │           ├── DeleteMessageModal.tsx [P]
    │           ├── PinnedMessagesModal.tsx [P]
    │           ├── PinnedMessageRow.tsx [P]
    │           ├── ReactionPickerModal.tsx [P]
    │           ├── ReactionUsersModal.tsx [P]
    │           ├── ImageViewerModal.tsx [P]
    │           ├── UserProfileModal.tsx [P]
    │           ├── NewDmModal.tsx [P]
    │           ├── RemoveFriendModal.tsx [P]
    │           ├── KickMemberModal.tsx [P]
    │           └── ModalForms.module.css [P]
    └── hooks/
        └── ui/
            ├── useModal.ts [P]
            └── useDialogFocus.ts [P]
```

