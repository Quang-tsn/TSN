# Transport thay thế được và state có giới hạn

[Danh mục kiến trúc](index.md) · [Danh sách đường dẫn](../../architecture/18-client-transport-state.txt)

`[H]`: tệp hiện có ở bước nền; `[P]`: dự kiến, chưa tạo.
Chỉ tạo module khi triển khai cụm tương ứng; không tạo file rỗng.

```text
tram-chat/
└── src/
    ├── services/
    │   ├── realtime/
    │   │   ├── createTransport.ts [P]
    │   │   ├── createPollingTransport.ts [P]
    │   │   ├── fetchRoomEvents.ts [P]
    │   │   ├── subscribeToRoom.ts [P]
    │   │   └── sendTyping.ts [P]
    │   ├── presence/
    │   │   └── sendHeartbeat.ts [P]
    │   ├── settings/
    │   │   ├── getSettings.ts [P]
    │   │   ├── updateSettings.ts [P]
    │   │   ├── updateProfile.ts [P]
    │   │   ├── listSessions.ts [P]
    │   │   └── revokeSession.ts [P]
    │   └── roles/
    │       ├── listRoles.ts [P]
    │       └── assignRole.ts [P]
    └── state/
        ├── session/
        │   ├── SessionContext.ts [P]
        │   └── SessionProvider.tsx [P]
        ├── navigation/
        │   ├── NavigationContext.ts [P]
        │   └── NavigationProvider.tsx [P]
        ├── messages/
        │   ├── createMessageCache.ts [P]
        │   ├── messageReducer.ts [P]
        │   ├── applyRoomEvent.ts [P]
        │   ├── trimMessageCache.ts [P]
        │   └── roomDraftCache.ts [P]
        └── ui/
            ├── ModalContext.ts [P]
            ├── ModalProvider.tsx [P]
            ├── ToastContext.ts [P]
            └── ToastProvider.tsx [P]
```

