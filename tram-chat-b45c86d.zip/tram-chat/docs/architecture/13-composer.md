# Soạn tin và ảnh

[Danh mục kiến trúc](index.md) · [Danh sách đường dẫn](../../architecture/13-composer.txt)

`[H]`: tệp hiện có ở bước nền; `[P]`: dự kiến, chưa tạo.
Chỉ tạo module khi triển khai cụm tương ứng; không tạo file rỗng.

```text
tram-chat/
└── src/
    ├── components/
    │   └── discord/
    │       └── chat-area/
    │           ├── MessageComposer.tsx [H]
    │           ├── ComposerInput.tsx [P]
    │           ├── ComposerToolbar.tsx [P]
    │           ├── ComposerSendButton.tsx [P]
    │           ├── ComposerAttachmentButton.tsx [P]
    │           ├── ReplyBanner.tsx [P]
    │           ├── TypingIndicator.tsx [P]
    │           ├── UploadQueue.tsx [P]
    │           ├── UploadPreview.tsx [P]
    │           ├── UploadProgress.tsx [P]
    │           ├── UploadFailure.tsx [P]
    │           ├── ComposerError.tsx [P]
    │           └── MessageComposer.module.css [P]
    └── hooks/
        ├── messages/
        │   ├── useComposer.ts [P]
        │   ├── useReply.ts [P]
        │   └── useSendMessage.ts [P]
        └── uploads/
            ├── useUploadQueue.ts [P]
            ├── useImagePreview.ts [P]
            └── useImageUpload.ts [P]
```

