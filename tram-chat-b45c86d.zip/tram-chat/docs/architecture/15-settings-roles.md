# Cài đặt, quyền và vai trò

[Danh mục kiến trúc](index.md) · [Danh sách đường dẫn](../../architecture/15-settings-roles.txt)

`[H]`: tệp hiện có ở bước nền; `[P]`: dự kiến, chưa tạo.
Chỉ tạo module khi triển khai cụm tương ứng; không tạo file rỗng.

```text
tram-chat/
└── src/
    ├── components/
    │   └── discord/
    │       └── settings/
    │           ├── SettingsModal.tsx [P]
    │           ├── SettingsNavigation.tsx [P]
    │           ├── ProfileSettings.tsx [P]
    │           ├── ProfileForm.tsx [P]
    │           ├── AvatarUpload.tsx [P]
    │           ├── AccountSettings.tsx [P]
    │           ├── ChangePasswordForm.tsx [P]
    │           ├── PresenceSettings.tsx [P]
    │           ├── NotificationSettings.tsx [P]
    │           ├── SessionSettings.tsx [P]
    │           ├── SessionRow.tsx [P]
    │           ├── ServerSettings.tsx [P]
    │           ├── ServerProfileForm.tsx [P]
    │           ├── ServerMembersSettings.tsx [P]
    │           ├── ServerRolesSettings.tsx [P]
    │           ├── RoleRow.tsx [P]
    │           ├── PermissionSummary.tsx [P]
    │           ├── MemberRolePicker.tsx [P]
    │           ├── InviteSettings.tsx [P]
    │           ├── InviteRow.tsx [P]
    │           └── Settings.module.css [P]
    └── hooks/
        ├── settings/
        │   ├── useProfileSettings.ts [P]
        │   ├── useAccountSettings.ts [P]
        │   └── useNotificationSettings.ts [P]
        ├── roles/
        │   └── useRoles.ts [P]
        └── invites/
            └── useInvites.ts [P]
```

