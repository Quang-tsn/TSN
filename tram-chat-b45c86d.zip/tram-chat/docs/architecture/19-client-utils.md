# Hàm thuần frontend

[Danh mục kiến trúc](index.md) · [Danh sách đường dẫn](../../architecture/19-client-utils.txt)

`[H]`: tệp hiện có ở bước nền; `[P]`: dự kiến, chưa tạo.
Chỉ tạo module khi triển khai cụm tương ứng; không tạo file rỗng.

```text
tram-chat/
└── src/
    └── utils/
        ├── date/
        │   ├── formatMessageTime.ts [P]
        │   ├── formatDayLabel.ts [P]
        │   └── isSameDay.ts [P]
        ├── messages/
        │   ├── groupMessages.ts [P]
        │   ├── sortMessages.ts [P]
        │   ├── mergeMessagePage.ts [P]
        │   ├── getWindowSlice.ts [P]
        │   ├── tokenizeMessage.ts [P]
        │   └── getReplyExcerpt.ts [P]
        ├── images/
        │   ├── checkImageFile.ts [P]
        │   ├── getImageDimensions.ts [P]
        │   └── releaseObjectUrl.ts [P]
        ├── identity/
        │   ├── normalizeUsername.ts [P]
        │   ├── getAvatarInitials.ts [P]
        │   └── getDisplayName.ts [P]
        ├── permissions/
        │   ├── canManageServer.ts [P]
        │   ├── canManageMessages.ts [P]
        │   └── canEditMessage.ts [P]
        ├── dom/
        │   ├── restoreScrollAnchor.ts [P]
        │   ├── getViewportHeight.ts [P]
        │   └── copyText.ts [P]
        ├── validation/
        │   ├── validateLogin.ts [P]
        │   ├── validateRegistration.ts [P]
        │   └── validateMessage.ts [P]
        └── url/
            └── isHttpUrl.ts [P]
```

