# Dịch vụ tin nhắn và người dùng

[Danh mục kiến trúc](index.md) · [Danh sách đường dẫn](../../architecture/24-server-messaging.txt)

`[H]`: tệp hiện có ở bước nền; `[P]`: dự kiến, chưa tạo.
Chỉ tạo module khi triển khai cụm tương ứng; không tạo file rỗng.

```text
tram-chat/
└── server/
    └── services/
        ├── messages/
        │   ├── listMessages.ts [P]
        │   ├── sendMessage.ts [P]
        │   ├── editMessage.ts [P]
        │   ├── deleteMessage.ts [P]
        │   ├── addReaction.ts [P]
        │   ├── removeReaction.ts [P]
        │   ├── pinMessage.ts [P]
        │   ├── unpinMessage.ts [P]
        │   ├── listPins.ts [P]
        │   ├── markRoomRead.ts [P]
        │   ├── assertReplyInRoom.ts [P]
        │   ├── assertMessageOwnership.ts [P]
        │   └── buildMessageView.ts [P]
        ├── permissions/
        │   ├── getEffectivePermissions.ts [P]
        │   ├── assertServerPermission.ts [P]
        │   └── assertRoomAccess.ts [P]
        ├── users/
        │   ├── getUserProfile.ts [P]
        │   ├── updateUserProfile.ts [P]
        │   ├── getUserSettings.ts [P]
        │   └── updateUserSettings.ts [P]
        └── presence/
            ├── updateHeartbeat.ts [P]
            ├── readPresence.ts [P]
            └── pruneExpiredPresence.ts [P]
```

