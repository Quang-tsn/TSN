# Quyết định kiến trúc

## Stack

- Frontend dự kiến: React + TypeScript + Vite, cùng origin với HTTP API.
- Backend: Cloudflare Worker qua Sites; D1 lưu record, R2 lưu ảnh.
- Phase 1 dùng esbuild cho Worker và TypeScript, chưa cài React/Vite.
- Không dùng Google, Firebase, Google OAuth hay dịch vụ Google khác.
- Tài khoản ứng dụng là username/email và mật khẩu tự quản lý.
- Không có bảng thanh toán, ví, gói trả phí hay kiếm tiền trong app.
- Không khẳng định hạ tầng miễn phí vô hạn; quota thực tế phải xác minh.

## Ranh giới

- Mỗi file một trách nhiệm; hàm logic và component độc lập có file riêng.
- Mục tiêu 60 dòng; trần cứng 80 dòng cho mọi file mã nguồn tự viết.
- Tách khi có trách nhiệm độc lập; không nén nhiều câu lên một dòng để né trần.
- Component nhận dữ liệu; hook quản lý vòng đời/state; service gọi HTTP.
- Route parse request; validator kiểm input; service thực hiện nghiệp vụ.
- Repository chỉ truy vấn D1 bằng parameter binding; không đọc request hay cookie.
- Middleware kiểm session/quyền; UI không quyết định quyền cuối cùng.
- DB, DTO và domain type tách riêng; không gửi credential/session hash ra client.
- Tệp module chỉ xuất hiện khi cụm của nó được triển khai.

## Mô hình sản phẩm

- `rooms.kind` phân biệt channel và DM; message dùng chung một pipeline.
- DM 1–1 dùng cặp user ID chuẩn hóa và unique, không tạo phòng trùng.
- Role hiện có: owner, admin, moderator, member trong server_members.
- Role settings gán role cố định; chưa có bảng hay editor custom roles.
- Custom roles cần migration và review quyền mới trước khi triển khai.
- Kênh hiện có là phòng chung của server; private-channel ACL là mở rộng sau.
- Reaction code ánh xạ SVG, không dùng ký tự emoji làm icon giao diện.

## Thiết kế

- Màu nền: #1E1F22, #2B2D31, #313338, #383A40.
- Hairline: 1px solid #3F4147; chữ chính #F2F3F5, phụ #949BA4.
- Không gradient neon, glow, kính mờ, blur hay bóng dày.
- Không icon library, emoji UI hoặc framer-motion.
- SVG có strokeWidth 1.75 hoặc 2, strokeLinecap round, viewBox nhất quán.
- Dùng nhãn thực tế: “Nhập tin nhắn tới #general”, “Sao chép mã mời”.
- PC có rail/sidebar/chat; member panel có thể bật tắt.
- Mobile dùng từng panel và drawer; giữ composer luôn truy cập được.
- Dùng focus rõ, nhãn cho icon button, bàn phím và reduced-motion.

