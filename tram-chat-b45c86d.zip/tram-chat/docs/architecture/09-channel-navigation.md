# Kênh và điều hướng server

[Danh mục kiến trúc](index.md) · [Danh sách đường dẫn](../../architecture/09-channel-navigation.txt)

`[H]`: tệp hiện có ở bước nền; `[P]`: dự kiến, chưa tạo.
Chỉ tạo module khi triển khai cụm tương ứng; không tạo file rỗng.

```text
tram-chat/
└── src/
    ├── components/
    │   └── discord/
    │       └── channel-sidebar/
    │           ├── ServerHeader.tsx [P]
    │           ├── ServerMenu.tsx [P]
    │           ├── ChannelCategory.tsx [P]
    │           ├── ChannelCategoryHeader.tsx [P]
    │           ├── ChannelList.tsx [P]
    │           ├── ChannelRow.tsx [P]
    │           ├── ChannelLabel.tsx [P]
    │           ├── ChannelUnreadBadge.tsx [P]
    │           ├── ChannelRowActions.tsx [P]
    │           ├── CreateChannelButton.tsx [P]
    │           └── ChannelEmptyState.tsx [P]
    └── hooks/
        ├── channels/
        │   ├── useChannels.ts [P]
        │   ├── useCreateChannel.ts [P]
        │   ├── useUpdateChannel.ts [P]
        │   └── useDeleteChannel.ts [P]
        └── navigation/
            ├── useActiveRoom.ts [P]
            ├── useSidebarMode.ts [P]
            └── useMobilePanel.ts [P]
```

