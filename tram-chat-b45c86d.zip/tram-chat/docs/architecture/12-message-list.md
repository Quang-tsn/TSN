# Tin nhắn và cửa sổ DOM

[Danh mục kiến trúc](index.md) · [Danh sách đường dẫn](../../architecture/12-message-list.txt)

`[H]`: tệp hiện có ở bước nền; `[P]`: dự kiến, chưa tạo.
Chỉ tạo module khi triển khai cụm tương ứng; không tạo file rỗng.

```text
tram-chat/
└── src/
    └── components/
        └── discord/
            └── chat-area/
                ├── MessageWindow.tsx [P]
                ├── MessageList.tsx [H]
                ├── MessageGroup.tsx [P]
                ├── MessageRow.tsx [H]
                ├── MessageAvatar.tsx [P]
                ├── MessageAuthor.tsx [P]
                ├── MessageTimestamp.tsx [P]
                ├── MessageBody.tsx [P]
                ├── MessageText.tsx [P]
                ├── MessageLink.tsx [P]
                ├── MessageReply.tsx [P]
                ├── MessageReactions.tsx [P]
                ├── ReactionButton.tsx [P]
                ├── MessageAttachments.tsx [P]
                ├── MessageImage.tsx [P]
                ├── MessageEmbed.tsx [P]
                ├── MessageActions.tsx [P]
                ├── MessageMenu.tsx [P]
                ├── MessageEditForm.tsx [P]
                ├── MessageDeliveryState.tsx [P]
                ├── DeletedMessage.tsx [P]
                ├── DateDivider.tsx [P]
                ├── UnreadDivider.tsx [P]
                ├── NewMessagesButton.tsx [P]
                ├── OlderMessagesButton.tsx [P]
                └── MessageList.module.css [P]
```

