# Vùng chat và danh sách thành viên

[Danh mục kiến trúc](index.md) · [Danh sách đường dẫn](../../architecture/11-chat-layout.txt)

`[H]`: tệp hiện có ở bước nền; `[P]`: dự kiến, chưa tạo.
Chỉ tạo module khi triển khai cụm tương ứng; không tạo file rỗng.

```text
tram-chat/
└── src/
    ├── components/
    │   └── discord/
    │       ├── chat-area/
    │       │   ├── ChatArea.tsx [H]
    │       │   ├── ChatHeader.tsx [H]
    │       │   ├── ChatTitle.tsx [P]
    │       │   ├── ChatTopic.tsx [P]
    │       │   ├── ChatHeaderActions.tsx [P]
    │       │   ├── ChatEmptyState.tsx [P]
    │       │   ├── RoomAccessNotice.tsx [P]
    │       │   └── ChatArea.module.css [P]
    │       └── member-list/
    │           ├── MemberList.tsx [P]
    │           ├── MemberGroup.tsx [P]
    │           ├── MemberGroupHeader.tsx [P]
    │           ├── MemberRow.tsx [P]
    │           ├── MemberName.tsx [P]
    │           ├── MemberActions.tsx [P]
    │           ├── MemberEmptyState.tsx [P]
    │           └── MemberList.module.css [P]
    └── hooks/
        ├── members/
        │   ├── useMembers.ts [P]
        │   └── useMemberPermissions.ts [P]
        └── presence/
            ├── usePresence.ts [P]
            └── useHeartbeat.ts [P]
```

