# Validation từng thao tác

[Danh mục kiến trúc](index.md) · [Danh sách đường dẫn](../../architecture/27-server-validation.txt)

`[H]`: tệp hiện có ở bước nền; `[P]`: dự kiến, chưa tạo.
Chỉ tạo module khi triển khai cụm tương ứng; không tạo file rỗng.

```text
tram-chat/
└── server/
    └── validators/
        ├── auth/
        │   ├── parseRegistration.ts [P]
        │   ├── parseLogin.ts [P]
        │   ├── parsePasswordChange.ts [P]
        │   └── validatePasswordStrength.ts [P]
        ├── users/
        │   ├── parseProfile.ts [P]
        │   └── parseSettings.ts [P]
        ├── friends/
        │   ├── parseFriendRequest.ts [P]
        │   └── parseFriendResponse.ts [P]
        ├── servers/
        │   ├── parseCreateServer.ts [P]
        │   └── parseUpdateServer.ts [P]
        ├── channels/
        │   ├── parseCreateChannel.ts [P]
        │   └── parseUpdateChannel.ts [P]
        ├── messages/
        │   ├── parseMessagePage.ts [P]
        │   ├── parseSendMessage.ts [P]
        │   ├── parseEditMessage.ts [P]
        │   ├── parseReaction.ts [P]
        │   └── parseReadCursor.ts [P]
        ├── invites/
        │   ├── parseCreateInvite.ts [P]
        │   └── parseRedeemInvite.ts [P]
        ├── roles/
        │   └── parseMemberRole.ts [P]
        ├── realtime/
        │   ├── parseEventCursor.ts [P]
        │   └── parseTyping.ts [P]
        ├── presence/
        │   └── parseHeartbeat.ts [P]
        └── shared/
            ├── parseId.ts [P]
            ├── parseText.ts [P]
            ├── parseInteger.ts [P]
            ├── parseHttpUrl.ts [P]
            └── rejectUnknownFields.ts [P]
```

