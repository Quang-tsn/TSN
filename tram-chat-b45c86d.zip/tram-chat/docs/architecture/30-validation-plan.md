# Kiểm chứng theo rủi ro

[Danh mục kiến trúc](index.md) · [Danh sách đường dẫn](../../architecture/30-validation-plan.txt)

`[H]`: tệp hiện có ở bước nền; `[P]`: dự kiến, chưa tạo.
Chỉ tạo module khi triển khai cụm tương ứng; không tạo file rỗng.

```text
tram-chat/
└── tests/
    ├── database/
    │   ├── test_migrations.py [H]
    │   ├── test_rooms.py [H]
    │   ├── test_messages.py [H]
    │   └── fixtures.py [H]
    ├── auth/
    │   ├── password.test.ts [P]
    │   └── session.test.ts [P]
    ├── security/
    │   ├── room-access.test.ts [P]
    │   ├── link-preview.test.ts [P]
    │   └── upload-validation.test.ts [P]
    ├── messages/
    │   ├── reply-scope.test.ts [P]
    │   └── idempotency.test.ts [P]
    ├── realtime/
    │   ├── event-cursor.test.ts [P]
    │   └── reconnect.test.ts [P]
    ├── frontend/
    │   ├── message-window.test.ts [P]
    │   ├── message-cache.test.ts [P]
    │   ├── scroll-anchor.test.ts [P]
    │   └── viewport-height.test.ts [P]
    ├── browser/
    │   ├── keyboard-checklist.md [P]
    │   └── iphone7-checklist.md [P]
    └── server/
        └── health.test.mjs [H]
```

