# Kiểu dữ liệu và hợp đồng

[Danh mục kiến trúc](index.md) · [Danh sách đường dẫn](../../architecture/02-domain-types.txt)

`[H]`: tệp hiện có ở bước nền; `[P]`: dự kiến, chưa tạo.
Chỉ tạo module khi triển khai cụm tương ứng; không tạo file rỗng.

```text
tram-chat/
└── src/
    └── types/
        ├── User.ts [P]
        ├── UserProfile.ts [P]
        ├── Session.ts [P]
        ├── Presence.ts [P]
        ├── Friendship.ts [P]
        ├── Server.ts [P]
        ├── ServerMember.ts [P]
        ├── Role.ts [P]
        ├── Permission.ts [P]
        ├── Channel.ts [P]
        ├── Room.ts [P]
        ├── DirectMessage.ts [P]
        ├── Message.ts [P]
        ├── MessageReply.ts [P]
        ├── Reaction.ts [P]
        ├── Attachment.ts [P]
        ├── LinkEmbed.ts [P]
        ├── Invite.ts [P]
        ├── RoomEvent.ts [P]
        ├── EventCursor.ts [P]
        ├── MessageCursor.ts [P]
        ├── PaginatedResult.ts [P]
        ├── ApiError.ts [P]
        ├── ApiResult.ts [P]
        ├── Transport.ts [P]
        ├── TypingState.ts [P]
        ├── UserSettings.ts [P]
        ├── ModalState.ts [P]
        └── IconProps.ts [P]
```

