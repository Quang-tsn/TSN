# Migrations D1: 24 bảng

[Danh mục kiến trúc](index.md) · [Danh sách đường dẫn](../../architecture/31-database.txt)

`[H]`: tệp hiện có ở bước nền; `[P]`: dự kiến, chưa tạo.
Chỉ tạo module khi triển khai cụm tương ứng; không tạo file rỗng.

```text
tram-chat/
├── drizzle/
│   ├── 0000_accounts.sql [H]
│   ├── 0001_social.sql [H]
│   ├── 0002_communities.sql [H]
│   ├── 0003_rooms.sql [H]
│   ├── 0004_messages.sql [H]
│   ├── 0005_content.sql [H]
│   ├── 0006_navigation.sql [H]
│   ├── 0007_embeds_events.sql [H]
│   ├── 0008_ephemeral.sql [H]
│   └── meta/
│       └── _journal.json [H]
└── docs/
    └── database/
        ├── README.md [H]
        ├── accounts.md [H]
        ├── authorization.md [H]
        ├── communities.md [H]
        ├── events.md [H]
        ├── media.md [H]
        ├── messages.md [H]
        └── relationships.md [H]
```

