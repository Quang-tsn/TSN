# Khung ứng dụng và hồ sơ đáy sidebar

[Danh mục kiến trúc](index.md) · [Danh sách đường dẫn](../../architecture/07-shell-profile.txt)

`[H]`: tệp hiện có ở bước nền; `[P]`: dự kiến, chưa tạo.
Chỉ tạo module khi triển khai cụm tương ứng; không tạo file rỗng.

```text
tram-chat/
└── src/
    └── components/
        └── discord/
            ├── DiscordShell.tsx [P]
            ├── DiscordShell.module.css [P]
            ├── MobileNavigation.tsx [P]
            ├── MobileDrawer.tsx [P]
            ├── ConnectionNotice.tsx [P]
            └── channel-sidebar/
                ├── ChannelSidebar.tsx [H]
                ├── SidebarHeader.tsx [P]
                ├── SidebarContent.tsx [P]
                ├── SidebarModeSwitch.tsx [P]
                ├── SidebarSearch.tsx [P]
                ├── UserPanel.tsx [H]
                ├── UserPanelAvatar.tsx [P]
                ├── UserPanelStatus.tsx [P]
                ├── UserPanelActions.tsx [P]
                ├── UserMenu.tsx [P]
                └── ChannelSidebar.module.css [P]
```

