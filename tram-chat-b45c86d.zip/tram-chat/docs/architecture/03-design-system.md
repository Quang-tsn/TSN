# Màu sắc, bố cục và bản sao giao diện

[Danh mục kiến trúc](index.md) · [Danh sách đường dẫn](../../architecture/03-design-system.txt)

`[H]`: tệp hiện có ở bước nền; `[P]`: dự kiến, chưa tạo.
Chỉ tạo module khi triển khai cụm tương ứng; không tạo file rỗng.

```text
tram-chat/
└── src/
    ├── styles/
    │   ├── reset.css [P]
    │   ├── tokens.css [P]
    │   ├── typography.css [P]
    │   ├── layout.css [P]
    │   ├── controls.css [P]
    │   ├── accessibility.css [P]
    │   ├── mobile.css [P]
    │   ├── viewport.css [P]
    │   ├── scrollbars.css [P]
    │   └── transitions.css [P]
    └── constants/
        ├── colors.ts [P]
        ├── layout.ts [P]
        ├── messageLimits.ts [P]
        ├── polling.ts [P]
        ├── uploadLimits.ts [P]
        ├── reactionKinds.ts [P]
        ├── permissions.ts [P]
        ├── routes.ts [P]
        └── copy.ts [P]
```

