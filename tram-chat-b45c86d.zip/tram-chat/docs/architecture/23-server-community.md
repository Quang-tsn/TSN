# Dịch vụ cộng đồng, invite và roles

[Danh mục kiến trúc](index.md) · [Danh sách đường dẫn](../../architecture/23-server-community.txt)

`[H]`: tệp hiện có ở bước nền; `[P]`: dự kiến, chưa tạo.
Chỉ tạo module khi triển khai cụm tương ứng; không tạo file rỗng.

```text
tram-chat/
└── server/
    ├── routes/
    │   ├── members/
    │   │   ├── getMembers.ts [P]
    │   │   └── deleteMember.ts [P]
    │   ├── roles/
    │   │   ├── getRoles.ts [P]
    │   │   └── putMemberRole.ts [P]
    │   ├── invites/
    │   │   ├── postInvite.ts [P]
    │   │   ├── getInvites.ts [P]
    │   │   ├── postAcceptInvite.ts [P]
    │   │   └── deleteInvite.ts [P]
    │   └── presence/
    │       └── putHeartbeat.ts [P]
    └── services/
        ├── friends/
        │   ├── listFriends.ts [P]
        │   ├── requestFriendship.ts [P]
        │   ├── respondToRequest.ts [P]
        │   └── removeFriendship.ts [P]
        ├── dm/
        │   ├── openDirectMessage.ts [P]
        │   └── listDirectMessages.ts [P]
        ├── servers/
        │   ├── createServer.ts [P]
        │   ├── updateServer.ts [P]
        │   ├── deleteServer.ts [P]
        │   ├── leaveServer.ts [P]
        │   └── listServers.ts [P]
        ├── channels/
        │   ├── createChannel.ts [P]
        │   ├── updateChannel.ts [P]
        │   ├── deleteChannel.ts [P]
        │   └── listChannels.ts [P]
        ├── invites/
        │   ├── createInvite.ts [P]
        │   ├── redeemInvite.ts [P]
        │   ├── revokeInvite.ts [P]
        │   └── listInvites.ts [P]
        ├── roles/
        │   ├── assignMemberRole.ts [P]
        │   └── listRoles.ts [P]
        └── members/
            ├── listMembers.ts [P]
            └── kickMember.ts [P]
```

