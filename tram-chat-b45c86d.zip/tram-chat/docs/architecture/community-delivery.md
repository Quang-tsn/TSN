# Cụm server, kênh và chat ba cột

Đã triển khai:

- Rail server, sidebar kênh và vùng chat theo bảng màu đã chốt.
- Mobile giữ rail, mở danh sách kênh bằng drawer; không ép ba cột hẹp.
- Tạo server cùng owner membership và 3 kênh trong một transaction.
- Mã mời lưu hash, có hạn 7 ngày; redeem kiểm hạn/lượt dùng trong batch.
- Tạo/sửa/xóa kênh: owner/admin, server luôn giữ ít nhất một kênh.
- Xóa kênh có bước xác nhận trong UI; xóa cả lịch sử kênh.
- Danh sách thành viên đọc từ D1; không giả trạng thái online.
- Gửi tin bằng Enter hoặc nút; Shift+Enter xuống dòng; xử lý IME.
- Nonce chống gửi trùng khi retry; mutation và event cùng batch.
- Đọc 50 tin gần nhất; phân trang cursor xem 50 tin trước.
- MessageList tự cắt 50 hàng kể cả khi nhận đầu vào lớn hơn.
- Poll 2 giây khi xem mới nhất; dừng tab ẩn, abort khi đổi kênh.
- Chưa có WebSocket, DM/bạn bè, reply/reaction, ảnh hoặc embed UI.

API:

- GET/POST /api/servers
- GET /api/servers/:id
- POST /api/servers/join
- POST /api/servers/:id/channels
- POST /api/servers/:id/invites
- PATCH/DELETE /api/rooms/:id
- GET/POST /api/rooms/:id/messages
- GET history với ?before=messageId; cursor bắt buộc cùng phòng.

Mọi endpoint kiểm session và membership; mutation kiểm Origin và JSON có trần.
Message content render text qua React, không đưa HTML vào DOM.
Schema không đổi; dùng 24 bảng hiện có, không seed dữ liệu hosted.
Giới hạn hiện tại: tối đa 100 server trong danh sách, 200 kênh/server,
100 thành viên đầu danh sách. Chưa có search/member pagination.

Kiểm tra: 16 Database tests + 13 backend/render tests, typecheck, build,
check:lines. Test gồm ACL, invite hết lượt/hạn, retry, history và DOM 50 hàng.
Kiểm Chrome trực tiếp bị công cụ dừng do không nhận diện được URL Windows.
Chưa xác nhận QA trực quan trên Chrome hoặc iPhone 7 thật.

“Chạy trên Google” được hiểu là truy cập bằng Chrome qua URL HTTPS.
Site giữ quyền riêng tư hiện có, chưa yêu cầu Google lập chỉ mục.
Không chuyển hosting hoặc auth sang dịch vụ Google.
