# Đăng nhập và đăng ký tự chủ

[Danh mục kiến trúc](index.md) · [Danh sách đường dẫn](../../architecture/06-auth-ui.txt)

`[H]`: tệp hiện có ở bước nền; `[P]`: dự kiến, chưa tạo.
Chỉ tạo module khi triển khai cụm tương ứng; không tạo file rỗng.

```text
tram-chat/
└── src/
    ├── components/
    │   └── auth/
    │       ├── AuthPage.tsx [H]
    │       ├── AuthCard.tsx [P]
    │       ├── AuthHeader.tsx [P]
    │       ├── AuthTabs.tsx [P]
    │       ├── LoginForm.tsx [P]
    │       ├── RegisterForm.tsx [P]
    │       ├── IdentityField.tsx [H]
    │       ├── UsernameField.tsx [P]
    │       ├── EmailField.tsx [H]
    │       ├── PasswordField.tsx [H]
    │       ├── ConfirmPasswordField.tsx [H]
    │       ├── AuthSubmitButton.tsx [P]
    │       ├── SessionExpiredNotice.tsx [P]
    │       └── AuthForm.module.css [P]
    └── hooks/
        └── auth/
            ├── useLogin.ts [P]
            ├── useRegister.ts [P]
            ├── useSession.ts [H]
            └── useLogout.ts [P]
```

