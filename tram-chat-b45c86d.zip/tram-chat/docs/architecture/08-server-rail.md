# Danh sách server

[Danh mục kiến trúc](index.md) · [Danh sách đường dẫn](../../architecture/08-server-rail.txt)

`[H]`: tệp hiện có ở bước nền; `[P]`: dự kiến, chưa tạo.
Chỉ tạo module khi triển khai cụm tương ứng; không tạo file rỗng.

```text
tram-chat/
└── src/
    ├── components/
    │   └── discord/
    │       └── server-rail/
    │           ├── ServerRail.tsx [H]
    │           ├── HomeButton.tsx [P]
    │           ├── ServerList.tsx [P]
    │           ├── ServerButton.tsx [P]
    │           ├── ServerAvatar.tsx [P]
    │           ├── ServerSelectionMark.tsx [P]
    │           ├── ServerUnreadMark.tsx [P]
    │           ├── ServerRailDivider.tsx [P]
    │           ├── CreateServerButton.tsx [P]
    │           ├── JoinServerButton.tsx [P]
    │           └── ServerRail.module.css [P]
    └── hooks/
        └── servers/
            ├── useServers.ts [P]
            ├── useCreateServer.ts [P]
            ├── useJoinServer.ts [P]
            └── useLeaveServer.ts [P]
```

