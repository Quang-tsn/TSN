# Transport và event cursor

## Khả năng đã xác định

- Sites hiện cung cấp binding D1/R2 cho dự án này.
- Chưa xác minh Durable Objects, shared pubsub hay điều phối WebSocket.
- WebSocket không được giả lập bằng cờ online hoặc dùng memory Worker làm broker.
- Phase 1 chỉ DB/health; chưa có transport chat hoạt động.
- Transport đầu tiên dự kiến là incremental polling foreground mỗi 1–2 giây.
- Điều này có độ trễ polling; chưa thể gọi là WebSocket real-time.
- Transport interface tách khỏi hook/UI để thay bằng push khi runtime hỗ trợ.

## Event bền vững

- room_events.sequence là cursor tăng đơn điệu, phạm vi đọc được lọc theo room.
- Mỗi mutation message/reaction/pin/preview ghi event trong cùng batch nguyên tử.
- Kiểu event hiện có: message.created, message.updated, message.deleted,
  reaction.changed, pin.changed, preview.changed.
- Event chứa tham chiếu; server dựng view hiện tại và tombstone khi đọc.
- Client apply theo sequence, dedupe event, dùng client_nonce cho retry gửi tin.
- Tải snapshot phải trả watermark nhất quán để đóng khoảng trống snapshot/events.
- GET /api/rooms/:roomId/events?after=:sequence trả batch có giới hạn.
- nextCursor chỉ tiến tới event cuối đã giao, không nhảy đến MAX khi còn backlog.
- hasMore cho biết cần đọc ngay batch sau; không render quá 50 message.
- Không dùng timestamp client làm cursor và không OFFSET khi phân trang lịch sử.
- Cursor quá cũ sau retention trả resetRequired/resync và snapshot watermark mới.
- Room bị mất quyền trả 403; hủy subscription, dọn cache và nội dung room.

## Vòng đời kết nối

- Một request đang chạy mỗi room; AbortController khi đổi room/unmount.
- Khi document.hidden, dừng polling và heartbeat chủ động.
- Khi hiện lại hoặc mạng trở lại, tiếp tục từ cursor; resync nếu quá hạn.
- Lỗi mạng dùng backoff có trần và jitter, không tạo vòng retry vô hạn tức thì.
- Chỉ hiển thị “Đã mất kết nối” khi có tín hiệu thật từ transport.
- Presence/typing đọc dưới dạng snapshot TTL trong response poll, không event bền.
- Room_presence có device_id để nhiều tab/thiết bị không ghi đè nhau.
- Typing throttle khoảng 3 giây, TTL khoảng 6 giây; gửi stop khi gửi tin/blur.
- Heartbeat khoảng 30 giây, online TTL khoảng 75 giây; invisible luôn ẩn online.
- Server bỏ qua hàng hết TTL khi đọc, kể cả chưa được GC vật lý.

## Điều kiện chuyển sang WebSocket

- Xác minh binding coordination và triển khai được nhiều Worker isolate.
- Kiểm fanout hai client, reconnect, duplicate delivery, ACL revoke và idle timeout.
- Giữ event cursor D1 để bù dữ liệu mất trong lúc disconnect.
- Chỉ đổi createTransport sau khi các kiểm chứng này qua.

