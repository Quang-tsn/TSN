"""Minimal deterministic records for integrity checks, never production seeds."""
import sqlite3
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "scripts"))
from migration_store import apply_migrations


def create_database():
    database = sqlite3.connect(":memory:")
    apply_migrations(database, ROOT / "drizzle")
    for user in ("a", "b", "c"):
        database.execute(
            "INSERT INTO users(id, username, display_name, created_at, updated_at) "
            "VALUES (?, ?, ?, 1, 1)", (user, user * 3, user),
        )
    database.execute(
        "INSERT INTO servers(id, owner_id, name, created_at) VALUES ('s','a','Tram',1)"
    )
    database.executemany(
        "INSERT INTO server_members(server_id,user_id,joined_at) VALUES ('s',?,1)",
        [("a",), ("b",)],
    )
    for room in ("r1", "r2"):
        database.execute(
            "INSERT INTO rooms(id,kind,server_id,name,created_at) "
            "VALUES (?, 'channel', 's', ?, 1)", (room, room),
        )
    database.execute(
        "INSERT INTO messages(id,room_id,author_id,client_nonce,content,created_at) "
        "VALUES ('m1','r1','a','nonce001','hello',1)"
    )
    database.commit()
    return database
