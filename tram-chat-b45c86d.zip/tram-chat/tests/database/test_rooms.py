import sqlite3
import unittest

from fixtures import create_database


class RoomTests(unittest.TestCase):
    def setUp(self):
        self.database = create_database()
        self.addCleanup(self.database.close)

    def test_canonical_direct_pair_is_unique(self):
        sql = ("INSERT INTO rooms(id,kind,direct_user_low,direct_user_high,created_at) "
               "VALUES (?, 'direct', ?, ?, 1)")
        self.database.execute(sql, ("dm1", "a", "b"))
        for record in (("dm2", "a", "b"), ("dm3", "b", "a"), ("dm4", "a", "a")):
            with self.assertRaises(sqlite3.IntegrityError):
                self.database.execute(sql, record)

    def test_channel_cannot_use_another_server_category(self):
        self.database.execute(
            "INSERT INTO servers(id,owner_id,name,created_at) VALUES ('t','b','Other',1)"
        )
        self.database.execute(
            "INSERT INTO channel_categories(id,server_id,name) VALUES ('ct','t','cat')"
        )
        with self.assertRaises(sqlite3.IntegrityError):
            self.database.execute("UPDATE rooms SET category_id='ct' WHERE id='r1'")

    def test_friend_request_reverse_is_duplicate(self):
        self.database.execute(
            "INSERT INTO friend_requests VALUES ('q1','a','b',1)"
        )
        with self.assertRaises(sqlite3.IntegrityError):
            self.database.execute("INSERT INTO friend_requests VALUES ('q2','b','a',1)")

    def test_unknown_author_rejected(self):
        with self.assertRaises(sqlite3.IntegrityError):
            self.database.execute(
                "INSERT INTO messages(id,room_id,author_id,client_nonce,created_at) "
                "VALUES ('bad','r1','unknown','nonce002',1)"
            )

    def test_username_cannot_conflict_with_email_login(self):
        with self.assertRaises(sqlite3.IntegrityError):
            self.database.execute(
                "INSERT INTO users(id,username,display_name,created_at,updated_at) "
                "VALUES ('bad','a@example.com','Name',1,1)"
            )

    def test_email_requires_at_with_local_and_domain_parts(self):
        for email in ("someusername", "@example.com", "abc@"):
            with self.assertRaises(sqlite3.IntegrityError):
                self.database.execute(
                    "INSERT INTO users(id,username,email,display_name,created_at,updated_at) "
                    "VALUES ('bad','newuser',?,'Name',1,1)", (email,),
                )
