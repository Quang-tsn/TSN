import sqlite3
import unittest

from fixtures import create_database


class MessageTests(unittest.TestCase):
    def setUp(self):
        self.database = create_database()
        self.addCleanup(self.database.close)

    def test_reply_cannot_cross_room(self):
        self.database.execute(
            "INSERT INTO messages(id,room_id,author_id,client_nonce,reply_to_id,created_at) "
            "VALUES ('bad','r2','b','nonce002','m1',2)"
        )
        with self.assertRaises(sqlite3.IntegrityError):
            self.database.commit()
        self.database.rollback()

    def test_pin_cannot_cross_room(self):
        with self.assertRaises(sqlite3.IntegrityError):
            self.database.execute("INSERT INTO message_pins VALUES ('m1','r2','a',2)")

    def test_read_cursor_cannot_cross_room(self):
        self.database.execute(
            "INSERT INTO room_reads(room_id,user_id,last_message_id,updated_at) "
            "VALUES ('r2','b','m1',2)"
        )
        with self.assertRaises(sqlite3.IntegrityError):
            self.database.commit()
        self.database.rollback()

    def test_nonce_and_reaction_are_idempotent_keys(self):
        with self.assertRaises(sqlite3.IntegrityError):
            self.database.execute(
                "INSERT INTO messages(id,room_id,author_id,client_nonce,created_at) "
                "VALUES ('m2','r1','a','nonce001',2)"
            )
        self.database.execute("INSERT INTO message_reactions VALUES ('m1','b','heart',2)")
        with self.assertRaises(sqlite3.IntegrityError):
            self.database.execute("INSERT INTO message_reactions VALUES ('m1','b','heart',2)")

    def test_room_delete_cascades_linked_messages(self):
        self.database.execute(
            "INSERT INTO messages(id,room_id,author_id,client_nonce,reply_to_id,created_at) "
            "VALUES ('m2','r1','b','nonce002','m1',2)"
        )
        self.database.execute("INSERT INTO message_pins VALUES ('m1','r1','a',2)")
        self.database.execute("INSERT INTO message_reactions VALUES ('m1','b','heart',2)")
        self.database.execute("DELETE FROM rooms WHERE id='r1'")
        self.database.commit()
        for table in ("messages", "message_pins", "message_reactions"):
            self.assertEqual(self.database.execute(f"SELECT count(*) FROM {table}").fetchone()[0], 0)

    def test_server_delete_with_category_and_reply(self):
        self.database.execute(
            "INSERT INTO channel_categories(id,server_id,name) VALUES ('cat','s','Text')"
        )
        self.database.execute("UPDATE rooms SET category_id='cat' WHERE id='r1'")
        self.database.execute(
            "INSERT INTO messages(id,room_id,author_id,client_nonce,reply_to_id,created_at) "
            "VALUES ('m2','r1','b','nonce002','m1',2)"
        )
        self.database.execute("DELETE FROM servers WHERE id='s'")
        self.database.commit()
        self.assertEqual(self.database.execute("SELECT count(*) FROM rooms WHERE server_id='s'").fetchone()[0], 0)
        self.assertEqual(self.database.execute("PRAGMA foreign_key_check").fetchall(), [])
