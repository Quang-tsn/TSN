import sqlite3
import tempfile
import unittest
from pathlib import Path
from shutil import copytree

from fixtures import ROOT, apply_migrations, create_database


class MigrationTests(unittest.TestCase):
    def test_all_tables_and_second_pass(self):
        with create_database() as database:
            count = database.execute(
                "SELECT count(*) FROM sqlite_master WHERE type='table' "
                "AND name NOT LIKE 'sqlite_%' AND name <> '__drizzle_migrations'"
            ).fetchone()[0]
            self.assertEqual(count, 37)
            self.assertEqual(apply_migrations(database, ROOT / "drizzle"), 0)
            self.assertEqual(database.execute("PRAGMA foreign_key_check").fetchall(), [])

    def test_mutated_applied_migration_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            copied = Path(directory) / "drizzle"
            copytree(ROOT / "drizzle", copied)
            with sqlite3.connect(":memory:") as database:
                apply_migrations(database, copied)
                file = copied / "0000_accounts.sql"
                file.write_text(file.read_text() + "\n-- changed\n")
                with self.assertRaisesRegex(ValueError, "Applied migration changed"):
                    apply_migrations(database, copied)

    def test_schema_sources_stay_small(self):
        for file in (ROOT / "drizzle").rglob("*"):
            if file.is_file():
                self.assertLessEqual(len(file.read_text().splitlines()), 80, file.name)

    def test_failed_migration_rolls_back_ddl_and_journal(self):
        with tempfile.TemporaryDirectory() as directory:
            copied = Path(directory) / "drizzle"
            copytree(ROOT / "drizzle", copied)
            file = copied / "0001_social.sql"
            file.write_text(file.read_text() + "\n--> statement-breakpoint\nBROKEN SQL;")
            with sqlite3.connect(":memory:") as database:
                with self.assertRaises(sqlite3.OperationalError):
                    apply_migrations(database, copied)
                self.assertIsNone(database.execute(
                    "SELECT name FROM sqlite_master WHERE name='friend_requests'"
                ).fetchone())
                self.assertEqual(database.execute(
                    "SELECT count(*) FROM __drizzle_migrations"
                ).fetchone()[0], 1)


if __name__ == "__main__":
    unittest.main()
