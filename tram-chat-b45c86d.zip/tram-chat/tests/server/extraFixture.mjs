import worker from "../../dist/server/index.js";
import { authFixture } from "./authFixture.mjs";
export async function extraFixture(config = {}) {
  const { DB, request } = authFixture();
  const identities = {};
  for (const name of ["vipowner","vipother"]) {
    const response = await request("register",{ username:name,password:"local vip passphrase" });
    identities[name] = { ...(await response.json()).user, cookie:response.headers.get("set-cookie").split(";")[0] };
  }
  const objects = new Map();
  const env = { DB, BUCKET: {
    async put(key,bytes) { objects.set(key,bytes); },
    async get(key) { return objects.has(key) ? new Response(objects.get(key)) : null; },
    async delete(key) { objects.delete(key); }
  }, ...config };
  function send(path, data, identity = identities.vipowner.cookie) {
    const headers = { Cookie:identity, Origin:"https://test","X-Tram-Request":"1" };
    if (!(data instanceof FormData)) headers["Content-Type"]="application/json";
    return worker.fetch(new Request("https://test/api/"+path,{
      method:data===undefined?"GET":"POST",headers,
      body:data instanceof FormData ? data : data===undefined ? undefined : JSON.stringify(data)
    }),env);
  }
  function grant(tier,identity=identities.vipowner) {
    const now=Date.now();
    DB.raw.prepare("INSERT INTO extra_grants VALUES (?,?,?,?,?)").run(crypto.randomUUID(),identity.id,tier,now,now+360000);
  }
  return { DB,send,grant,identities,objects };
}
