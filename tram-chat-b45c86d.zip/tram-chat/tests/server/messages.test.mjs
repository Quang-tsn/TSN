import { test } from "node:test";
import assert from "node:assert/strict";
import { communityFixture } from "./communityFixture.mjs";
test("messages check membership, deduplicate retry, record events and cap history at 50", async () => {
  const { DB, users, call } = await communityFixture();
  try {
    const server = await (await call("owner", "servers", { name: "Chat" })).json();
    const detail = await (await call("owner", "servers/" + server.id)).json();
    const path = "rooms/" + detail.channels[0].id + "/messages";
    const body = { content: "Xin chào <script>alert(1)</script>", nonce: "retry-nonce-123" };
    assert.equal((await call("outsider", path, body)).status, 403);
    const first = await (await call("owner", path, body)).json();
    const second = await (await call("owner", path, body)).json();
    assert.equal(first.id, second.id);
    assert.equal(DB.raw.prepare("SELECT count(*) n FROM room_events").get().n, 1);
    assert.equal((await call("owner", path, { ...body, content: "" })).status, 400);
    assert.equal((await call("owner", path, { ...body, content: "x".repeat(4001) })).status, 400);
    const other = "rooms/" + detail.channels[1].id + "/messages";
    assert.equal((await call("owner", other, body)).status, 409);
    const now = Date.now();
    for (let n = 0; n < 60; n++) DB.raw.prepare(
      "INSERT INTO messages(id,room_id,author_id,client_nonce,content,created_at) VALUES (?,?,?,?,?,?)"
    ).run("message-" + n, detail.channels[0].id, users.owner.id, "unique-nonce-" + n, "Tin " + n, now + n);
    const page = await (await call("owner", path)).json();
    assert.equal(page.messages.length, 50);
    assert.equal(page.hasMore, true);
    const older = await (await call("owner", path + "?before=" + page.messages[0].id)).json();
    assert.equal(older.messages.length, 11);
    assert.equal(older.hasMore, false);
    const ids = new Set(page.messages.map((m) => m.id));
    assert.ok(older.messages.every((m) => !ids.has(m.id)));
    DB.raw.prepare("DELETE FROM server_members WHERE user_id=?").run(users.owner.id);
    assert.equal((await call("owner", path)).status, 403);
    assert.equal((await call("owner", path, { ...body, nonce: "another-nonce" })).status, 403);
  } finally { DB.raw.close(); }
});
