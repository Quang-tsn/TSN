import { test } from "node:test";
import assert from "node:assert/strict";
import worker from "../../dist/server/index.js";
import { authFixture } from "./authFixture.mjs";

test("settings reads private account details and only revokes another session of the current user",async()=>{
  const {DB,request} = authFixture();
  const origin = "https://test";
  const cookieOf = response => response.headers.get("set-cookie").split(";")[0];
  function call(path,cookie,data) {
    return worker.fetch(new Request(origin + "/api/" + path,{
      method:data ? "POST" : "GET",
      headers:{Cookie:cookie,Origin:origin,"X-Tram-Request":"1","Content-Type":"application/json",
        "User-Agent":"Mozilla/5.0 (Windows NT 10.0) Chrome/145.0"},
      body:data ? JSON.stringify(data) : undefined,
    }),{DB});
  }
  try {
    const credentials = {username:"settings_user",email:"settings@example.test",password:"local settings phrase"};
    const first = cookieOf(await request("register",credentials));
    const second = cookieOf(await request("login",{identity:credentials.email,password:credentials.password}));
    const outsider = cookieOf(await request("register",{username:"somebody_else",password:credentials.password}));
    assert.equal((await call("settings","")).status,401);
    const server = await (await call("servers",first,{name:"Settings QA"})).json();
    const {channels} = await (await call("servers/"+server.id,first)).json();
    await call(`rooms/${channels[0].id}/messages`,first,{content:"Phép thử",nonce:"settings-test"});
    const settings = await (await call("settings",first)).json();
    assert.equal(settings.email,credentials.email);
    assert.equal(settings.passwordSet,true);
    assert.equal(settings.sessions.length,2);
    assert.equal(settings.sessions[0].current,true);
    assert.equal(settings.sessions[0].device,"Chrome trên Windows");
    assert.equal(settings.activity[0].count,1);
    assert.deepEqual(settings.redemptions,[]);
    assert.equal((await call("settings/revoke-session",first,{id:settings.sessions[0].id})).status,400);
    await call("settings/revoke-session",outsider,{id:settings.sessions[1].id});
    assert.equal((await call("settings",second)).status,200);
    await call("settings/revoke-session",first,{id:settings.sessions[1].id});
    assert.equal((await call("settings",second)).status,401);
    assert.equal((await call("settings/profile",first,{displayName:"\n"})).status,400);
    assert.equal((await call("settings/profile",first,{displayName:"Bạn của Trạm"})).status,200);
    assert.equal((await (await request("me",null,first)).json()).user.display_name,"Bạn của Trạm");
  } finally { DB.raw.close(); }
});
