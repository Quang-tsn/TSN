import { test } from "node:test";
import assert from "node:assert/strict";
import { extraFixture } from "./extraFixture.mjs";
test("active grants gate animated posts, badges, uploads and private saved messages",async()=>{
  const {DB,send,grant,identities}=await extraFixture();
  try {
    const server=await(await send("servers",{name:"VIP QA"})).json();
    const {channels}=await(await send("servers/"+server.id)).json();
    const path="rooms/"+channels[0].id+"/messages";
    const animated={nonce:"vip-gif-9876",animation:{id:"3o7TKDkDbIDJieKbVm",kind:"gif"}};
    assert.equal((await send(path,animated)).status,403);
    grant("Bvip");
    const clip=await send(path,animated);
    assert.equal(clip.status,201);
    const sent=await(await send(path,{nonce:"vip-text-9876",content:"Xin chào"})).json();
    const base="extra/profile/"+identities.vipowner.id;
    const data=new FormData();
    data.set("image",new Blob([Buffer.from("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jRuoAAAAASUVORK5CYII=","base64")],{type:"image/png"}),"demo.png");
    assert.equal((await send(base+"/avatar",data)).status,200);
    assert.equal((await send(base+"/background",data)).status,403);
    assert.equal((await send(base+"/background",undefined,identities.vipother.cookie)).status,404);
    const {messages}=await(await send(path)).json();
    const row=messages.find(item=>item.giphy_id);
    assert.equal(row.giphy_id,animated.animation.id);
    assert.equal(row.tier,"Bvip");
    assert.equal(row.has_avatar,1);
    assert.equal((await send("extra/save",{id:sent.id})).status,200);
    assert.equal((await send("extra/save",{id:sent.id})).status,200);
    assert.equal((await(await send("extra/saved")).json()).used,Buffer.byteLength("Xin chào"));
    assert.equal((await send("extra/saved",undefined,identities.vipother.cookie)).status,403);
    assert.equal((await send("extra/unsave",{id:sent.id})).status,200);
    assert.equal((await(await send("extra/saved")).json()).used,0);
    DB.raw.exec("UPDATE extra_grants SET starts_at=1,expires_at=2");
    assert.equal((await(await send(path)).json()).messages[0].tier,null);
    assert.equal((await send(base+"/avatar")).status,404);
  } finally {DB.raw.close();}
});

test("saved history pages use a stable cursor for equal timestamps", async () => {
  const {DB,send,grant,identities}=await extraFixture();
  try {
    grant("Svip");
    const server=await (await send("servers",{name:"Kho tin QA"})).json();
    const {channels}=await (await send("servers/"+server.id)).json();
    const user=identities.vipowner.id;
    const time=Date.now();
    const write=DB.raw.prepare("INSERT INTO messages(id,room_id,author_id,client_nonce,content,created_at) VALUES (?,?,?,?,?,?)");
    const bookmark=DB.raw.prepare("INSERT INTO extra_saved(user_id,owner_id,message_id,saved_at) VALUES (?,?,?,?)");
    for (let i=0;i<82;i++) {
      const id="saved-"+String(i).padStart(3,"0");
      write.run(id,channels[0].id,user,id,"Tin thử",time);
      bookmark.run(user,user,id,time);
    }
    const first=await (await send("extra/saved")).json();
    assert.equal(first.saved.length,40);
    const second=await (await send("extra/saved?before="+encodeURIComponent(first.next))).json();
    assert.equal(second.saved.length,40);
    const last=await (await send("extra/saved?before="+encodeURIComponent(second.next))).json();
    assert.equal(last.saved.length,2);
    assert.equal(last.next,null);
    assert.equal(new Set([...first.saved,...second.saved,...last.saved].map(row=>row.id)).size,82);
    for (const sort of ["az","za","oldest"]) {
      const a = await (await send("extra/saved?sort="+sort)).json();
      const b = await (await send("extra/saved?sort="+sort+"&before="+encodeURIComponent(a.next))).json();
      assert.equal(new Set([...a.saved,...b.saved].map(row=>row.id)).size,80);
      assert.equal(a.saved[0].id,sort==="za" ? "saved-081" : "saved-000");
    }
  } finally {DB.raw.close();}
});
