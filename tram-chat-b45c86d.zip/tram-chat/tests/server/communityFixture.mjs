import worker from "../../dist/server/index.js";
import { authFixture } from "./authFixture.mjs";
export async function communityFixture(BUCKET) {
  const fixture = authFixture();
  const users = {};
  for (const username of ["owner", "member", "outsider"]) {
    const response = await fixture.request("register", { username, password: "test phrase only 123" });
    users[username] = { ...(await response.json()).user, cookie: response.headers.get("set-cookie") };
  }
  return { DB: fixture.DB, users, async call(user, path, data, method = "POST") {
    return worker.fetch(new Request("https://test/api/" + path, {
      method: data === undefined ? "GET" : method,
      headers: { Cookie: users[user]?.cookie || "", Origin: "https://test",
        ...(data instanceof FormData ? {} : { "Content-Type": "application/json" }),
        "X-Tram-Request": "1" },
      body: data instanceof FormData ? data : data === undefined ? undefined : JSON.stringify(data),
    }), { DB: fixture.DB, BUCKET });
  } };
}
