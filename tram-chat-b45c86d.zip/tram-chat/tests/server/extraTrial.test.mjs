import { test } from "node:test";
import assert from "node:assert/strict";
import { extraFixture } from "./extraFixture.mjs";
test("Bvip uses a server 90-second challenge and absolute 12-hour expiry",async()=>{
  const {DB,send,identities}=await extraFixture();
  try {
    assert.equal((await send("extra/trial-claim",{})).status,409);
    const start=await send("extra/trial-open",{});
    assert.equal(start.status,303);
    assert.equal(start.headers.get("location"),"https://lunor.wtf/");
    const state=await (await send("extra")).json();
    assert.equal(state.trialReadyAt-DB.raw.prepare("SELECT started_at FROM extra_trials").get().started_at,90000);
    assert.equal((await send("extra/trial-claim",{})).status,409);
    assert.equal((await send("extra/trial-claim",{},identities.vipother.cookie)).status,409);
    DB.raw.prepare("UPDATE extra_trials SET started_at=?").run(Date.now()-91000);
    assert.equal((await send("extra/trial-claim",{})).status,200);
    assert.equal((await send("extra/trial-claim",{})).status,409);
    const record=DB.raw.prepare("SELECT * FROM extra_grants").get();
    assert.equal(record.expires_at-record.starts_at,12*3600000);
    assert.equal((await (await send("extra")).json()).status.storage,2500000);
    assert.equal((await send("extra/create",{username:"with_trial"})).status,403);
    DB.raw.exec("UPDATE extra_grants SET starts_at=1,expires_at=2");
    assert.equal((await (await send("extra")).json()).status.tier,null);
    assert.equal((await send("extra/trial-open",{})).status,303);
  } finally {DB.raw.close();}
});
test("paid limits count the root, switch isolates identities and expired alts lose chat access",async()=>{
  const {DB,send,grant,identities}=await extraFixture();
  try {
    grant("Avip");
    for(let i=0;i<2;i++) assert.equal((await send("extra/create",{username:"extra_"+i})).status,201);
    assert.equal((await send("extra/create",{username:"extra_2"})).status,409);
    assert.equal((await send("extra/switch",{target:identities.vipother.id})).status,403);
    const state=await(await send("extra")).json();
    assert.equal(state.accounts.length,3);
    const switched=await send("extra/switch",{target:state.accounts[1].id});
    const cookie=switched.headers.get("set-cookie").split(";")[0];
    assert.equal((await(await send("auth/me",undefined,cookie)).json()).user.id,state.accounts[1].id);
    grant("Svip");
    for(let i=2;i<9;i++) assert.equal((await send("extra/create",{username:"extra_"+i},cookie)).status,201);
    assert.equal((await send("extra/create",{username:"extra_9"},cookie)).status,409);
    DB.raw.exec("UPDATE extra_grants SET starts_at=1,expires_at=2");
    assert.equal((await(await send("auth/me",undefined,cookie)).json()).user,null);
    assert.equal((await send("extra/switch",{target:identities.vipowner.id},cookie)).status,200);
  } finally {DB.raw.close();}
});
