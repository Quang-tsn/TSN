import { test } from "node:test";
import assert from "node:assert/strict";
import { authFixture } from "./authFixture.mjs";
const account = { username: "tester", email: "test@example.com", password: "secret phrase 1234" };

test("register, restore session, login by email and logout use real SQL", async () => {
  const { DB, request } = authFixture();
  try {
    const registered = await request("register", account);
    assert.equal(registered.status, 201);
    const cookie = registered.headers.get("set-cookie");
    assert.match(cookie, /HttpOnly; Secure; SameSite=Lax/);
    const user = (await registered.json()).user;
    assert.deepEqual(Object.keys(user).sort(), ["display_name", "id", "username"]);
    const stored = DB.raw.prepare("SELECT * FROM password_credentials").get();
    assert.notEqual(stored.password_hash, account.password);
    assert.equal(stored.salt.length, 32);
    const token = cookie.split(";")[0].split("=")[1];
    assert.notEqual(DB.raw.prepare("SELECT token_hash FROM sessions").get().token_hash, token);
    assert.equal((await (await request("me", null, cookie)).json()).user.id, user.id);
    const login = await request("login", { identity: account.email, password: account.password });
    assert.equal(login.status, 200);
    assert.equal((await request("logout", {}, cookie)).status, 200);
    assert.equal((await (await request("me", null, cookie)).json()).user, null);
    const active = login.headers.get("set-cookie");
    DB.raw.exec("UPDATE sessions SET expires_at=created_at+1");
    assert.equal((await (await request("me", null, active)).json()).user, null);
  } finally { DB.raw.close(); }
});

test("duplicates roll back and bad passwords cannot authenticate", async () => {
  const { DB, request } = authFixture();
  try {
    await request("register", account);
    assert.equal((await request("register", { ...account, username: "TESTER" })).status, 409);
    assert.equal(DB.raw.prepare("SELECT count(*) n FROM users WHERE id<>'tram-system-public'").get().n, 1);
    for (const identity of ["tester", "unknown-user"]) {
      const response = await request("login", { identity, password: "wrong password 123" });
      assert.equal(response.status, 401);
      assert.equal((await response.json()).error, "Tên đăng nhập hoặc mật khẩu chưa đúng.");
    }
    const another = await request("register", { username: "another", password: account.password });
    assert.equal(another.status, 201);
    const salts = DB.raw.prepare("SELECT salt FROM password_credentials").all();
    assert.notEqual(salts[0].salt, salts[1].salt);
  } finally { DB.raw.close(); }
});
