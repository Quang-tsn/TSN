import { test } from "node:test";
import assert from "node:assert/strict";
import { communityFixture } from "./communityFixture.mjs";

test("image-only and reply messages persist, deduplicate and respect channel access", async () => {
  const objects = new Map();
  const bucket = {
    async put(key, bytes) { objects.set(key, bytes); },
    async get(key) { return objects.has(key) ? new Response(objects.get(key)) : null; },
    async delete(key) { objects.delete(key); },
  };
  const { DB, call } = await communityFixture(bucket);
  try {
    const server = await (await call("owner", "servers", { name: "Hội ảnh" })).json();
    const { channels } = await (await call("owner", "servers/" + server.id)).json();
    const room = "rooms/" + channels[0].id;
    const path = room + "/messages";
    const form = new FormData();
    const png = Buffer.from("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jRuoAAAAASUVORK5CYII=", "base64");
    form.set("image", new Blob([png], { type: "image/png" }), "photo.png");
    form.set("nonce", "photo-test-123");
    assert.equal((await call("outsider", path, form)).status, 403);
    const sent = await call("owner", path, form);
    assert.equal(sent.status, 201);
    const original = await sent.json();
    assert.equal((await (await call("owner", path, form)).json()).id, original.id);
    assert.equal(objects.size, 1);
    assert.equal((await call("owner", path, {
      content: "Ảnh đẹp!", nonce: "reply-test-123", replyTo: original.id,
    })).status, 201);
    assert.equal((await call("owner", "rooms/" + channels[1].id + "/messages", {
      content: "Nhầm kênh", nonce: "cross-room-123", replyTo: original.id,
    })).status, 400);
    const { messages } = await (await call("owner", path)).json();
    const photo = messages.find((message) => message.id === original.id);
    const photoPath = room + "/images/" + photo.image_id;
    const attachment = await call("owner", photoPath);
    assert.equal(attachment.headers.get("content-type"), "image/png");
    assert.deepEqual(Buffer.from(await attachment.arrayBuffer()), png);
    assert.equal((await call("outsider", photoPath)).status, 404);
    assert.equal(messages.find((message) => message.id !== original.id).reply_author, "owner");
    form.set("image", new Blob(["not a PNG"], { type: "image/png" }), "fake.png");
    form.set("nonce", "fake-test-123");
    assert.equal((await call("owner", path, form)).status, 400);
    assert.equal(objects.size, 1);
  } finally { DB.raw.close(); }
});

test("only active ExtraAccount users get the higher chat photo limits",async()=>{
  const {DB,call,users} = await communityFixture({put:async()=>{}});
  try {
    const server = await (await call("owner","servers",{name:"Ảnh nét"})).json();
    const {channels:[room]} = await (await call("owner","servers/"+server.id)).json();
    const path = "rooms/"+room.id+"/messages";
    const png = Buffer.from("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jRuoAAAAASUVORK5CYII=","base64");
    png.writeUInt32BE(4800,16);png.writeUInt32BE(3200,20);
    const form = new FormData();
    form.set("image",new Blob([png],{type:"image/png"}),"premium.png");
    form.set("nonce","premium-image-test");
    assert.equal((await call("owner",path,form)).status,400);
    const now = Date.now();
    DB.raw.prepare("INSERT INTO extra_grants VALUES (?,?,?,?,?)").run("photo-access",users.owner.id,"Bvip",now-1,now+60000);
    assert.equal((await call("owner",path,form)).status,201);
    png.writeUInt32BE(8000,16);
    form.set("image",new Blob([png],{type:"image/png"}),"oversized.png");
    form.set("nonce","over-limit-image-test");
    assert.equal((await call("owner",path,form)).status,400);
  } finally {DB.raw.close();}
});
