import { test } from "node:test";
import assert from "node:assert/strict";
import { build } from "esbuild";
import { mkdir, writeFile } from "node:fs/promises";
import { pathToFileURL } from "node:url";
import path from "node:path";
import { createElement } from "react";
import { renderToStaticMarkup } from "react-dom/server";
test("message DOM stays at 50 rows and renders user HTML as text", async () => {
  const output = path.resolve(".data/message-window-test.mjs");
  const result = await build({ entryPoints: ["src/components/discord/chat-area/MessageList.tsx"],
    bundle: true, platform: "node", format: "esm", packages: "external", write: false });
  await mkdir(".data", { recursive: true });
  await writeFile(output, result.outputFiles[0].contents);
  const { MessageList } = await import(pathToFileURL(output).href);
  const messages = Array.from({ length: 75 }, (_, n) => ({
    id: "m" + n, author_id: "u1", username: "tester", display_name: "Tester",
    content: "<script>alert(1)</script>", created_at: 1700000000000 + n,
    client_nonce: "nonce-" + n,
  }));
  const html = renderToStaticMarkup(createElement(MessageList, {
    messages, name: "general", hasMore: true, history: false, loading: false,
    onOlder() {}, onLatest() {},
  }));
  assert.equal((html.match(/class="message-row"/g) || []).length, 50);
  assert.ok(html.includes("&lt;script&gt;"));
  assert.ok(!html.includes("<script>"));
});
