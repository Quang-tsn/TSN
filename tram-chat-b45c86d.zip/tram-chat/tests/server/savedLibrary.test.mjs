import { test } from "node:test";
import assert from "node:assert/strict";
import { extraFixture } from "./extraFixture.mjs";

test("saved folders keep private ownership and search and filter across the complete library",async()=>{
  const {DB,send,grant,identities} = await extraFixture();
  try {
    grant("Svip");grant("Avip",identities.vipother);
    const other = identities.vipother.cookie;
    const folder = await (await send("extra/saved-folders",{name:"Kỷ niệm"})).json();
    assert.equal((await send("extra/saved-folders",{name:"kỷ NIỆM"})).status,409);
    assert.deepEqual(await (await send("extra/saved-folders",undefined,other)).json(),{folders:[]});
    const server = await (await send("servers",{name:"Hội chơi",isPublic:true})).json();
    const secondary = await (await send("servers",{name:"Nhóm khác"})).json();
    await send(`servers/${server.id}/join-public`,{},other);
    const room = async id => "rooms/"+(await(await send(`servers/${id}`)).json()).channels[0].id+"/messages";
    const path = await room(server.id), another = await room(secondary.id);
    const photo = await (await send(path,{content:"Ảnh Việt Nam",nonce:"bookmark-a"},other)).json();
    const text = await (await send(path,{content:"Trò chuyện",nonce:"bookmark-b"})).json();
    const last = await (await send(another,{content:"Zebra [2]",nonce:"bookmark-c"})).json();
    assert.equal((await send("extra/save",{id:photo.id,folderId:folder.id},other)).status,404);
    await send("extra/save",{id:photo.id,folderId:folder.id});
    await send("extra/save",{id:text.id});await send("extra/save",{id:last.id});
    const page = async params => (await (await send("extra/saved?"+new URLSearchParams(params))).json()).saved;
    assert.deepEqual((await page({q:"anh viet",author:identities.vipother.id,server:server.id,folder:folder.id})).map(x=>x.id),[photo.id]);
    assert.deepEqual((await page({q:"[2]"})).map(x=>x.id),[last.id]);
    assert.equal((await page({server:secondary.id})).length,1);
    assert.deepEqual((await page({sort:"az"})).map(x=>x.id),[photo.id,text.id,last.id]);
    assert.deepEqual((await page({sort:"za"})).map(x=>x.id),[last.id,text.id,photo.id]);
    assert.equal((await send("extra/saved-move",{id:photo.id,folderId:null},other)).status,404);
    assert.equal((await send("extra/saved-move",{id:photo.id,folderId:null})).status,200);
    assert.equal((await page({folder:"unfiled"})).length,3);
    const catalog = await (await send("extra/saved-catalog")).json();
    assert.equal(catalog.authors.length,2);assert.equal(catalog.servers.length,2);
    assert.equal(catalog.folders[0].name,"Kỷ niệm");
    const row = (await (await send(path)).json()).messages.find(m=>m.id===photo.id);
    assert.equal(row.is_saved,1);assert.equal(row.saved_folder_id,null);
    const otherRow = (await (await send(path,undefined,other)).json()).messages.find(m=>m.id===photo.id);
    assert.equal(otherRow.is_saved,0);
    const prefix = "Q".repeat(90);
    const later = await (await send(path,{content:prefix+" zebra",nonce:"bookmark-long-z"})).json();
    const earlier = await (await send(path,{content:prefix+" alpha",nonce:"bookmark-long-a"})).json();
    await send("extra/save",{id:later.id});await send("extra/save",{id:earlier.id});
    assert.deepEqual((await page({q:prefix,sort:"az"})).map(x=>x.id),[earlier.id,later.id]);
  } finally {DB.raw.close();}
});
