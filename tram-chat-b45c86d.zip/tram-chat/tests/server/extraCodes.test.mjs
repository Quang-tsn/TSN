import test from "node:test";
import assert from "node:assert/strict";
import worker from "../../dist/server/index.js";
import { extraFixture } from "./extraFixture.mjs";

const key = "local-issuer-credential";
function issue(DB, tier, period, auth) {
  return worker.fetch(new Request("https://test/api/extra/issue-code",{
    method:"POST",headers:{ "Content-Type":"application/json",Origin:"https://test",
      "X-Tram-Request":"1",Authorization:"Bearer " + auth },body:JSON.stringify({tier,period}),
  }),{ DB,EXTRA_CODE_ADMIN_KEY:key });
}

test("an authorized issuer creates one-use codes with the selected tier and duration",async()=>{
  const { DB,send,identities } = await extraFixture();
  try {
    assert.equal((await issue(DB,"Svip","month","wrong")).status,403);
    assert.equal((await issue(DB,"Bvip","week",key)).status,400);
    assert.equal((await send("extra/redeem",{code:"not-a-code"})).status,400);
    assert.equal((await send("extra/redeem",{code:"NOTISSUED123"})).status,404);
    assert.equal((await send("extra/checkout",{tier:"Svip"})).status,404);
    const issued = await issue(DB,"Svip","month",key);
    assert.equal(issued.status,201);
    const {code} = await issued.json();
    assert.match(code,/^(?=.*[A-Z])(?=.*\d)[A-Z0-9]{12}$/);
    const wrongPlan = await send("extra/redeem",{code,tier:"Avip"});
    assert.equal(wrongPlan.status,400);
    assert.equal((await wrongPlan.json()).error,"Mã này dùng cho gói Svip.");
    const stored = DB.raw.prepare("SELECT digest FROM extra_codes").get();
    assert.match(stored.digest,/^[a-f0-9]{64}$/);
    const started = Date.now();
    const responses = await Promise.all([
      send("extra/redeem",{tier:"Svip",code:`\t${code.slice(0,6).toLowerCase()}-\u200B${code.slice(6)}\n`},identities.vipowner.cookie),
      send("extra/redeem",{code},identities.vipother.cookie),
    ]);
    assert.deepEqual(responses.map(response=>response.status).sort(),[200,409]);
    const winner = responses[0].ok ? identities.vipowner : identities.vipother;
    const grant = await responses.find(response=>response.ok).json();
    assert.equal(grant.tier,"Svip");
    assert.ok(grant.expiresAt >= started + 2592000000 && grant.expiresAt <= Date.now() + 2592000000);
    const retry = await send("extra/redeem",{code},winner.cookie);
    assert.deepEqual(await retry.json(),grant);
    const { code: renewal } = await (await issue(DB,"Svip","week",key)).json();
    const renewed = await (await send("extra/redeem",{code:`\t${renewal}`},winner.cookie)).json();
    assert.equal(renewed.expiresAt,grant.expiresAt + 604800000);
    const {status} = await (await send("extra",undefined,winner.cookie)).json();
    assert.equal(status.slots,10);
    assert.equal(status.storage,10000000);
    assert.equal(status.expiresAt,renewed.expiresAt);
    const settings = await (await send("settings",undefined,winner.cookie)).json();
    assert.equal(settings.redemptions.length,2);
    assert.equal(settings.redemptions[0].tier,"Svip");
  } finally { DB.raw.close(); }
});
