import { test } from "node:test";
import { createHash } from "node:crypto";
import assert from "node:assert/strict";
import { extraFixture } from "./extraFixture.mjs";

test("switching accounts preserves the group but applies badges and quotas only to the subscribing account",async()=>{
  const {DB,send,grant,identities} = await extraFixture();
  try {
    grant("Svip");
    const main = identities.vipowner;
    const {id: linked} = await (await send("extra/create",{username:"linked_profile"})).json();
    const switched = await send("extra/switch",{target:linked});
    const cookie = switched.headers.get("set-cookie").split(";")[0];
    const {status,user} = await (await send("extra",undefined,cookie)).json();
    assert.equal(user.id,linked);
    assert.deepEqual(status,{owner:main.id,allowed:true,tier:null,expiresAt:null,slots:10,storage:0});
    assert.equal((await send("extra/saved",undefined,cookie)).status,403);
    await send("servers/tram-server-test/join-public",{},cookie);
    const room = "rooms/tram-test-general/messages";
    const sent = await send(room,{content:"Tin tài khoản phụ",nonce:"alt-message-1"},cookie);
    assert.equal(sent.status,201);
    const animation = {id:"3o7TKDkDbIDJieKbVm",kind:"gif"};
    assert.equal((await send(room,{animation,nonce:"alt-message-2"},cookie)).status,403);
    assert.equal((await (await send(room,undefined,cookie)).json()).messages[0].tier,null);
    const code = "AVIP40OWN123";
    DB.raw.prepare("INSERT INTO extra_codes(digest,tier,period,created_at) VALUES (?,'Avip','week',?)")
      .run(createHash("sha256").update(code).digest("hex"),Date.now());
    const result = await (await send("extra/redeem",{code,tier:"Avip"},cookie)).json();
    assert.equal(result.status.tier,"Avip");
    assert.equal(result.status.storage,5000000);
    assert.equal((await (await send(room,undefined,cookie)).json()).messages[0].tier,"Avip");
    DB.raw.exec("UPDATE extra_grants SET starts_at=1,expires_at=2 WHERE tier='Svip'");
    assert.equal((await send(room,undefined,cookie)).status,200);
    const returned = await send("extra/switch",{target:main.id},cookie);
    const rootCookie = returned.headers.get("set-cookie").split(";")[0];
    const rootStatus = await (await send("extra",undefined,rootCookie)).json();
    assert.equal(rootStatus.status.tier,null);
    assert.equal(rootStatus.accounts.find(account=>account.id===linked).selectable,1);
    assert.equal((await send("extra/switch",{target:linked},rootCookie)).status,200);
  } finally { DB.raw.close(); }
});
