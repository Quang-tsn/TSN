import { test } from "node:test";
import assert from "node:assert/strict";
import worker from "../../dist/server/index.js";
import { extraFixture } from "./extraFixture.mjs";

test("Tamper Coins are single-use, atomic, and isolated to the signed-in account",async()=>{
  const {DB,send,identities} = await extraFixture();
  const peer = identities.vipother.cookie;
  try {
    const json = async (path,data,cookie)=>(await send("coins"+path,data,cookie)).json();
    assert.deepEqual(await json(""),{balance:0});
    const {code} = await json("/daily-code",{});
    assert.equal((await send("coins/daily",{code},peer)).status,404);
    const [daily,duplicate] = await Promise.all([json("/daily",{code}),json("/daily",{code})]);
    assert.ok(daily.amount>=1 && daily.amount<=5);
    assert.deepEqual(daily,duplicate);
    const issued = await worker.fetch(new Request("https://test/api/coins/issue-code",{
      method:"POST",headers:{Authorization:"Bearer unit-test-key",Origin:"https://test",
        "Content-Type":"application/json","X-Tram-Request":"1"},body:JSON.stringify({amount:500}),
    }),{DB,COIN_CODE_ADMIN_KEY:"unit-test-key",EXTRA_CODE_ADMIN_KEY:"separate-key"});
    assert.equal(issued.status,201);
    const pack = await issued.json();
    assert.equal((await send("coins/issue-code",{amount:500})).status,403);
    assert.equal((await json("/redeem",{code:pack.code})).balance,500+daily.amount);
    assert.equal((await send("coins/redeem",{code:pack.code},peer)).status,409);
    const gift = {username:"@VIPOTHER",amount:100,nonce:crypto.randomUUID()};
    await Promise.all([json("/gift",gift),json("/gift",gift)]);
    assert.equal((await json("",undefined,peer)).balance,100);
    assert.equal((await json("")).balance,400+daily.amount);
    assert.equal((await json("/history?q=vipother")).items[0].sent,1);
    assert.equal((await json("/history?q=vipowner",undefined,peer)).items[0].sent,0);
    assert.deepEqual((await json("/history?q=unknown")).items,[]);
    const spends = await Promise.all([
      send("coins/exchange",{tier:"Bvip",days:1,nonce:crypto.randomUUID()},peer),
      send("coins/gift",{username:"vipowner",amount:100,nonce:crypto.randomUUID()},peer),
    ]);
    assert.deepEqual(spends.map(res=>res.status).sort(),[200,409]);
    if (spends[0].ok) {
      const state = await (await send("extra",undefined,peer)).json();
      assert.equal(state.status.tier,"Bvip");
    }
    const before = (await json("")).balance;
    assert.equal((await send("coins/exchange",{tier:"Svip",days:30,nonce:crypto.randomUUID()})).status,409);
    DB.raw.prepare("INSERT INTO coin_entries(id,kind,recipient_id,amount,created_at) VALUES (?,?,?,?,?)")
      .run("fixture-pack","purchase",identities.vipowner.id,500,Date.now());
    const exchange = {tier:"Avip",days:30,nonce:crypto.randomUUID()};
    assert.equal((await send("coins/exchange",{...exchange,days:300})).status,400);
    assert.equal((await send("coins/exchange",exchange)).status,200);
    assert.equal((await send("coins/exchange",exchange)).status,200);
    const grant = DB.raw.prepare("SELECT expires_at-starts_at span FROM extra_grants WHERE owner_id=?")
      .get(identities.vipowner.id);
    assert.equal(grant.span,30*86400000);
    assert.equal((await json("")).balance,before+1);
    for (const amount of [100,101]) {
      assert.equal((await send("coins/gift",{username:"vipother",amount,nonce:crypto.randomUUID()})).status,200);
    }
    const notices = await json("/gift-notices",undefined,peer);
    assert.deepEqual(notices.items.map(({amount,username})=>({amount,username})),[{amount:101,username:"vipowner"}]);
    assert.deepEqual(await json("/gift-notices"),{items:[]});
  } finally {DB.raw.close();}
});
