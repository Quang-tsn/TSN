import { test } from "node:test";
import assert from "node:assert/strict";
import worker from "../../dist/server/index.js";

const tables = [
  "users", "password_credentials", "sessions", "servers",
  "server_members", "rooms", "messages", "room_events", "message_mentions",
];
const database = (names, success = true) => ({
  prepare: () => ({ all: async () => ({
    results: names.map((name) => ({ name })), success,
  }) }),
});

test("health requires every essential schema table", async () => {
  for (const name of tables) {
    const DB = database(tables.filter((table) => table !== name));
    const response = await worker.fetch(new Request("https://test/api/health"), { DB });
    assert.equal(response.status, 503);
  }
});

test("initialized database returns ready without claiming chat works", async () => {
  const response = await worker.fetch(new Request("https://test/api/health"), {
    DB: database(tables),
  });
  assert.equal(response.status, 200);
  assert.equal(response.headers.get("Cache-Control"), "no-store");
  assert.deepEqual(await response.json(), {
    app: "Trạm", phase: "community-chat", database: "ready",
    chat: "text-polling",
  });
});

test("database failure is safe and does not leak internals", async () => {
  const DB = { prepare() { throw new Error("private database details"); } };
  const response = await worker.fetch(new Request("https://test/api/health"), { DB });
  assert.equal(response.status, 503);
  assert.doesNotMatch(await response.text(), /private database details/);
});

test("unknown paths and write methods expose no mutations", async () => {
  for (const request of [
    new Request("https://test/api/messages"),
    new Request("https://test/api/health", { method: "POST" }),
  ]) {
    const response = await worker.fetch(request, { DB: database(tables) });
    assert.equal(response.status, 404);
  }
});
