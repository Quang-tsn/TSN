import { test } from "node:test";
import assert from "node:assert/strict";
import { extraFixture } from "./extraFixture.mjs";

test("switch auth adds registered and existing accounts without sharing the owner session with independent logins",async()=>{
  const {DB,send,grant,identities} = await extraFixture();
  try {
    const owner = identities.vipowner;
    const newProfile = {username:"second_profile",password:"local alt passphrase",addAccount:true};
    assert.equal((await send("auth/register",newProfile)).status,403);
    grant("Avip");
    const added = await send("auth/register",newProfile);
    assert.equal(added.status,201);
    const cookie = added.headers.get("set-cookie").split(";")[0];
    const alt = (await added.json()).user;
    assert.equal((await (await send("auth/me",undefined,owner.cookie)).json()).user.id,owner.id);
    assert.equal((await (await send("auth/me",undefined,cookie)).json()).user.id,alt.id);
    const login = {identity:"vipother",password:"local vip passphrase"};
    const attached = await send("auth/login",{...login,addAccount:true},cookie);
    assert.equal(attached.status,200);
    assert.equal((await (await send("extra")).json()).accounts.length,3);
    assert.equal((await send("auth/register",{...newProfile,username:"extra_over_limit"})).status,409);
    assert.equal(DB.raw.prepare("SELECT id FROM users WHERE username='extra_over_limit'").get(),undefined);
    assert.equal((await send("extra/switch",{target:owner.id},identities.vipother.cookie)).status,403);
    const regular = await send("auth/login",login,identities.vipother.cookie);
    const independent = regular.headers.get("set-cookie").split(";")[0];
    assert.equal((await (await send("extra",undefined,independent)).json()).accounts,null);
    assert.equal((await send("extra/switch",{target:owner.id},independent)).status,403);
    const returned = await send("extra/switch",{target:owner.id},attached.headers.get("set-cookie").split(";")[0]);
    assert.equal(returned.status,200);
    const returnedCookie = returned.headers.get("set-cookie").split(";")[0];
    assert.equal((await (await send("auth/me",undefined,returnedCookie)).json()).user.id,owner.id);
  } finally { DB.raw.close(); }
});
