import { test } from "node:test";
import assert from "node:assert/strict";
import { extraFixture } from "./extraFixture.mjs";

test("Svip profile GIFs show in chat and are only delivered to the owner and shared server members",async()=>{
  const {DB,send,grant,identities} = await extraFixture();
  try {
    const owner = identities.vipowner, viewer = identities.vipother.cookie;
    const base = "extra/profile/" + owner.id;
    const gif = Buffer.from("R0lGODlhCAAIAIEAAL5aKAAAAAAAAAAAACH/C05FVFNDQVBFMi4wAwEAAAAh+QQAMgAAACwAAAAACAAIAAAIDwABCBxIsKDBgwgTKkwYEAAh+QQBMgABACwAAAAACAAIAIEeaaAAAAAAAAAAAAAIDwABCBxIsKDBgwgTKkwYEAA7","base64");
    const upload = new FormData();
    upload.set("image",new Blob([gif],{type:"image/gif"}),"animated.gif");
    grant("Avip");
    assert.equal((await send(base+"/avatar",upload)).status,403);
    assert.equal((await send(base+"/background",upload)).status,403);
    grant("Svip");
    for (const kind of ["avatar","background"]) assert.equal((await send(base+"/"+kind,upload)).status,200);
    assert.equal((await send(base+"/background",undefined,viewer)).status,404);
    const {id} = await (await send("servers",{name:"GIF QA",isPublic:true})).json();
    await send("servers/"+id+"/join-public",{},viewer);
    const {channels} = await (await send("servers/"+id)).json();
    const path = "rooms/"+channels[0].id+"/messages";
    const sent = await send(path,{content:"GIF QA",nonce:"profile-gif-test"});
    assert.equal(sent.status,201);
    const {messages:[message]} = await (await send(path,undefined,viewer)).json();
    assert.equal(message.tier,"Svip");
    assert.equal(message.has_background,1);
    assert.equal(message.avatar_mime,"image/gif");
    for (const kind of ["avatar","background"]) {
      const asset = await send(base+"/"+kind,undefined,viewer);
      assert.equal(asset.headers.get("content-type"),"image/gif");
      assert.deepEqual(Buffer.from(await asset.arrayBuffer()),gif);
    }
    DB.raw.exec("UPDATE extra_grants SET starts_at=1,expires_at=2 WHERE tier='Svip'");
    assert.equal((await send(base+"/avatar")).status,404);
    assert.equal((await send(base+"/background",undefined,viewer)).status,404);
  } finally { DB.raw.close(); }
});
