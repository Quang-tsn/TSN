import { readFileSync } from "node:fs";
import { localDatabase } from "../../scripts/localDatabase.mjs";
import worker from "../../dist/server/index.js";
export function authFixture() {
  const DB = localDatabase(":memory:");
  const journal = JSON.parse(readFileSync("drizzle/meta/_journal.json", "utf8"));
  for (const entry of journal.entries) {
    DB.raw.exec(readFileSync("drizzle/" + entry.tag + ".sql", "utf8"));
  }
  return { DB, request(path, data, cookie, origin = "https://test") {
    return worker.fetch(new Request("https://test/api/auth/" + path, {
      method: data ? "POST" : "GET",
      headers: { "Content-Type": "application/json", Origin: origin,
        "X-Tram-Request": "1", ...(cookie ? { Cookie: cookie } : {}) },
      body: data ? JSON.stringify(data) : undefined,
    }), { DB });
  } };
}
