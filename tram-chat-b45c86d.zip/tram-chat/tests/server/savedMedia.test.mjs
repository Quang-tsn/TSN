import { test } from "node:test";
import assert from "node:assert/strict";
import { extraFixture } from "./extraFixture.mjs";

test("bookmarking account stores text, uploaded images and GIPHY with one enforced quota",async()=>{
  const {DB,send,grant,identities} = await extraFixture();
  try {
    grant("Bvip");
    const {id} = await (await send("servers",{name:"Saved QA",isPublic:true})).json();
    const {channels} = await (await send("servers/"+id)).json();
    const path = "rooms/"+channels[0].id+"/messages";
    const image = Buffer.from("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jRuoAAAAASUVORK5CYII=","base64");
    const photo = new FormData();
    photo.set("image",new Blob([image],{type:"image/png"}),"upload.png");
    photo.set("nonce","save-photo");
    const animation = {id:"3o7TKDkDbIDJieKbVm",kind:"gif"};
    const text = "Ảnh và GIF";
    const textId = (await (await send(path,{content:text,nonce:"save-text"})).json()).id;
    const imageId = (await (await send(path,photo)).json()).id;
    const gifId = (await (await send(path,{animation,nonce:"save-giphy"})).json()).id;
    assert.ok(textId && imageId && gifId);
    const save = id => send("extra/save",{id});
    assert.equal((await save(imageId)).status,200);
    DB.raw.prepare("UPDATE files SET byte_size=?").run(2500000);
    assert.equal((await save(gifId)).status,409);
    assert.equal((await save(imageId)).status,200);
    DB.raw.prepare("UPDATE files SET byte_size=?").run(image.length);
    assert.equal((await save(gifId)).status,200);
    assert.equal((await save(textId)).status,200);
    const {saved,used,limit} = await (await send("extra/saved")).json();
    assert.equal(limit,2500000);
    assert.equal(used,Buffer.byteLength(text)+image.length+Buffer.byteLength(animation.id+animation.kind));
    const item = saved.find(row=>row.id===imageId);
    assert.equal(item.room_id,channels[0].id);
    assert.equal((await send(`rooms/${item.room_id}/images/${item.image_id}`)).status,200);
    assert.equal(saved.find(row=>row.id===gifId).giphy_id,animation.id);
    DB.raw.prepare("DELETE FROM server_members WHERE server_id=? AND user_id=?").run(id,identities.vipowner.id);
    assert.deepEqual(await (await send("extra/saved")).json(),{saved:[],next:null,used:0,limit:2500000});
  } finally { DB.raw.close(); }
});
