import { test } from "node:test";
import assert from "node:assert/strict";
import { communityFixture } from "./communityFixture.mjs";

test("chat alerts prioritize real mentions and keep broadcasts inside the server",async()=>{
  const {DB,users,call} = await communityFixture();
  try {
    const read = async (actor,path,data)=>{
      const res = await call(actor,path,data);
      assert.ok(res.ok,path+" returned "+res.status);
      return res.json();
    };
    const server = await read("owner","servers",{name:"Nhóm hai người",isPublic:true});
    await read("member","servers/"+server.id+"/join-public",{});
    const {channels:[main,other]} = await read("owner","servers/"+server.id);
    const message = (content,nonce=crypto.randomUUID())=>read("owner","rooms/"+main.id+"/messages",{content,nonce});
    const alerts = (actor,room,after)=>read(actor,"chat-alerts?"+new URLSearchParams({
      room:room.id,...(after===undefined ? {} : {after}),
    }));
    await message("@all Tin đã có trước khi mở chat");
    const baseline = await alerts("member",main);
    assert.equal(baseline.priority,0);
    const ordinary = await message("Gửi qa@member.com và https://example.com/@all");
    assert.equal(DB.raw.prepare("SELECT mention_all FROM messages WHERE id=?").get(ordinary.id).mention_all,0);
    const active = await alerts("member",main,baseline.cursor);
    assert.equal(active.priority,1);
    assert.equal((await alerts("member",other,baseline.cursor)).priority,0);
    assert.equal((await alerts("member",main,active.cursor)).priority,0);
    const nonce = crypto.randomUUID();
    const tagged = await message("Chào (@MEMBER) @member @outsider",nonce);
    assert.equal((await message("@all",nonce)).id,tagged.id);
    assert.deepEqual(DB.raw.prepare("SELECT user_id FROM message_mentions WHERE message_id=?").all(tagged.id)
      .map(row=>row.user_id),[users.member.id]);
    const direct = await alerts("member",other,active.cursor);
    assert.equal(direct.priority,2);
    assert.equal((await alerts("owner",main,active.cursor)).priority,0);
    assert.equal((await alerts("outsider",main,0)).priority,0);
    await message("@all Họp ở kênh chung");
    assert.equal((await alerts("member",other,direct.cursor)).priority,2);
    assert.equal((await alerts("outsider",main,0)).cursor,0);
    assert.equal((await call("missing","chat-alerts")).status,401);
    assert.equal((await call("member","chat-alerts?after=-1")).status,400);
  } finally {DB.raw.close();}
});
