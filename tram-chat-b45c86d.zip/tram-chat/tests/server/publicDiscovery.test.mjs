import { test } from "node:test";
import assert from "node:assert/strict";
import { communityFixture } from "./communityFixture.mjs";

test("public discovery suggests Server Test, matches names without accents, and joins immediately",async()=>{
  const {DB,call} = await communityFixture();
  try {
    const lookup = async q => (await (await call("member","servers/discover?q=" + q)).json()).servers;
    const suggested = await lookup("");
    assert.equal(suggested[0].name,"Server Test");
    assert.equal(suggested[0].verified,1);
    const created = await (await call("owner","servers",{name:"Hội Đánh Đêm",verified:true})).json();
    const joinPath = "servers/" + created.id + "/join-public";
    const visibility = "servers/" + created.id + "/visibility";
    assert.deepEqual(await lookup("hoi+danh"),[]);
    assert.equal((await call("member",joinPath,{})).status,404);
    assert.equal((await call("outsider",visibility,{isPublic:true})).status,403);
    assert.equal((await call("owner",visibility,{isPublic:true})).status,200);
    const [result] = await lookup("HOI+DANH");
    assert.equal(result.verified,0);
    assert.equal(result.joined,0);
    const joins = await Promise.all([call("member",joinPath,{}),call("member",joinPath,{})]);
    assert.deepEqual(joins.map(response=>response.status),[200,200]);
    assert.equal((await call("member","servers/" + created.id)).status,200);
    assert.equal((await lookup("hoi+danh"))[0].joined,1);
    await call("owner",visibility,{isPublic:false});
    assert.equal((await call("outsider",joinPath,{})).status,404);
    assert.equal((await call("member","servers/tram-server-test/join-public",{})).status,200);
    assert.equal((await call("member","rooms/tram-test-general/messages")).status,200);
  } finally { DB.raw.close(); }
});
