import { test } from "node:test";
import assert from "node:assert/strict";
import { authFixture } from "./authFixture.mjs";

test("cross-origin writes fail before SQL mutations", async () => {
  const { DB, request } = authFixture();
  try {
    const response = await request("register", {
      username: "tester", password: "secret phrase 1234",
    }, null, "https://attacker.test");
    assert.equal(response.status, 403);
    assert.equal(DB.raw.prepare("SELECT count(*) n FROM users WHERE id<>'tram-system-public'").get().n, 0);
  } finally { DB.raw.close(); }
});

test("rate limit uses atomic counters and expires", async () => {
  const { DB, request } = authFixture();
  try {
    for (let i = 0; i < 12; i++) {
      assert.equal((await request("login", {
        identity: "missing", password: "long enough password",
      })).status, 401);
    }
    assert.equal((await request("login", {
      identity: "missing", password: "long enough password",
    })).status, 429);
    DB.raw.exec("UPDATE auth_rate_limits SET expires_at=window_start+1");
    assert.equal((await request("login", {
      identity: "missing", password: "long enough password",
    })).status, 401);
  } finally { DB.raw.close(); }
});

test("bounded body and input validation reject invalid accounts", async () => {
  const { DB, request } = authFixture();
  try {
    assert.equal((await request("register", {
      username: "tester", password: "short",
    })).status, 400);
    assert.equal((await request("register", {
      username: "tester", password: "x".repeat(9000),
    })).status, 413);
    assert.equal((await request("register", {
      username: "tester", email: "username-only", password: "long enough password",
    })).status, 400);
    assert.equal(DB.raw.prepare("SELECT count(*) n FROM users WHERE id<>'tram-system-public'").get().n, 0);
    assert.equal((await request("login", {
      identity: "' OR 1=1 --", password: "long enough password",
    })).status, 400);
    assert.equal((await (await request("me", null, "__Host-tram_session=invalid")).json()).user, null);
  } finally { DB.raw.close(); }
});
