import { test } from "node:test";
import assert from "node:assert/strict";
import { communityFixture } from "./communityFixture.mjs";
test("server creation is atomic, channels stay private and management checks role", async () => {
  const { DB, users, call } = await communityFixture();
  try {
    assert.equal((await call("unknown", "servers")).status, 401);
    const created = await call("owner", "servers", { name: "Hội chơi game" });
    assert.equal(created.status, 201);
    const server = await created.json();
    const detail = await (await call("owner", "servers/" + server.id)).json();
    assert.equal(detail.channels.length, 3);
    assert.equal(detail.members[0].role, "owner");
    assert.equal(detail.members[0].id, users.owner.id);
    assert.equal((await call("outsider", "servers/" + server.id)).status, 403);
    const channel = detail.channels[0];
    assert.equal((await call("outsider", "rooms/" + channel.id + "/messages")).status, 403);
    const invite = await (await call("owner", "servers/" + server.id + "/invites", {})).json();
    assert.equal(invite.code.length, 32);
    const joined = await call("member", "servers/join", { code: invite.code });
    assert.equal(joined.status, 200);
    await call("member", "servers/join", { code: invite.code });
    assert.equal(DB.raw.prepare("SELECT use_count FROM server_invites").get().use_count, 1);
    assert.equal((await call("member", "servers/" + server.id + "/channels", { name: "hack" })).status, 403);
    const extra = await call("owner", "servers/" + server.id + "/channels", { name: "Kèo tối" });
    assert.equal(extra.status, 201);
    const room = await extra.json();
    assert.equal(room.name, "kèo-tối");
    assert.equal((await call("owner", "servers/" + server.id + "/channels", { name: "Kèo tối" })).status, 409);
    assert.equal((await call("member", "rooms/" + room.id, {}, "DELETE")).status, 403);
    const rename = await call("owner", "rooms/" + room.id, { name: "doi-ten", topic: "Lịch chơi" }, "PATCH");
    assert.equal((await rename.json()).topic, "Lịch chơi");
    assert.equal((await call("owner", "rooms/" + room.id, {}, "DELETE")).status, 200);
    for (const room of detail.channels.slice(1)) await call("owner", "rooms/" + room.id, {}, "DELETE");
    assert.equal((await call("owner", "rooms/" + channel.id, {}, "DELETE")).status, 409);
    assert.equal(DB.raw.prepare("PRAGMA foreign_key_check").all().length, 0);
  } finally { DB.raw.close(); }
});
test("expired and depleted invites cannot grant membership", async () => {
  const { DB, call } = await communityFixture();
  try {
    const server = await (await call("owner", "servers", { name: "Private" })).json();
    const invite = await (await call("owner", "servers/" + server.id + "/invites", {})).json();
    DB.raw.exec("UPDATE server_invites SET max_uses=1");
    assert.equal((await call("member", "servers/join", { code: invite.code })).status, 200);
    assert.equal((await call("outsider", "servers/join", { code: invite.code })).status, 409);
    assert.equal(DB.raw.prepare("SELECT count(*) n FROM server_members WHERE server_id=?").get(server.id).n, 2);
    DB.raw.exec("DELETE FROM server_members WHERE role='member'");
    assert.equal((await call("member", "servers/join", { code: invite.code })).status, 409);
    assert.equal(DB.raw.prepare("SELECT count(*) n FROM server_members WHERE server_id=?").get(server.id).n, 1);
    DB.raw.exec("UPDATE server_invites SET expires_at=created_at+1");
    assert.equal((await call("outsider", "servers/join", { code: invite.code })).status, 404);
  } finally { DB.raw.close(); }
});
